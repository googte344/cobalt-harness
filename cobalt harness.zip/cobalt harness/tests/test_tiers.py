import unittest

from cobalt.providers.google import classify, normalize, pretty, static_models

FREE = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3.8-flash-tts",
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemma-4",
]

PAID = ["gemini-4-argon", "gemini-3.1-pro-preview"]


class ClassifyTests(unittest.TestCase):
    def test_free_tier_models(self):
        for model in FREE:
            self.assertEqual(classify(model)[0], "free", model)

    def test_paid_tier_models(self):
        for model in PAID:
            self.assertEqual(classify(model)[0], "paid", model)

    def test_lite_checked_before_flash(self):
        # "gemini-3.5-flash-lite" must not be mistaken for the plain Flash entry,
        # and both are free, so the real check is that neither is "unknown".
        self.assertEqual(classify("gemini-3.5-flash-lite")[0], "free")
        self.assertEqual(classify("gemini-3.5-flash")[0], "free")

    def test_preview_pro_is_paid(self):
        self.assertEqual(classify("gemini-3.1-pro-preview")[0], "paid")
        self.assertEqual(classify("gemini-3.1-pro-preview-11-2025")[0], "paid")

    def test_unknown_model_is_not_guessed(self):
        self.assertEqual(classify("gemini-9-ultra")[0], "unknown")

    def test_api_prefix_and_case_are_normalised(self):
        self.assertEqual(normalize("models/Gemini-2.5-Flash"), "gemini-2.5-flash")
        self.assertEqual(classify("models/Gemini-2.5-Flash")[0], "free")

    def test_25_pro_is_flagged_as_both_tiers(self):
        tier, note = classify("gemini-2.5-pro")
        self.assertEqual(tier, "free")
        self.assertIn("paid tier", note)

    def test_pretty_names(self):
        self.assertEqual(pretty("gemini-3.8-flash-tts"), "Gemini 3.8 Flash TTS")
        self.assertEqual(pretty("gemma-4"), "Gemma 4")
        self.assertEqual(pretty("gemini-4-argon"), "Gemini 4 Argon")


class StaticCatalogueTests(unittest.TestCase):
    def test_catalogue_covers_every_configured_model(self):
        ids = {model.id for model in static_models()}
        self.assertEqual(ids, set(FREE) | set(PAID))

    def test_free_models_sort_first(self):
        models = static_models()
        tiers = [model.tier for model in models]
        self.assertEqual(tiers, sorted(tiers, key=lambda t: {"free": 0, "paid": 1}[t]))

    def test_badges(self):
        self.assertEqual(static_models()[0].badge, "FREE")
        self.assertEqual([m for m in static_models() if m.tier == "paid"][0].badge, "PAID")


if __name__ == "__main__":
    unittest.main()

import tempfile
import unittest
from pathlib import Path

from cobalt.agent import Agent, format_call
from cobalt.providers.base import Provider, ToolCall, Turn


class ScriptedProvider(Provider):
    def __init__(self, turns):
        self.turns = list(turns)
        self.seen = []

    def list_models(self):
        return []

    def chat(self, model, system, messages, tools):
        self.seen.append({"model": model, "system": system, "messages": list(messages), "tools": tools})
        if self.turns:
            return self.turns.pop(0)
        return Turn(text="nothing left to do")


class AgentTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_tool_loop_creates_a_file(self):
        provider = ScriptedProvider(
            [
                Turn(
                    text="Creating the file.",
                    tool_calls=[
                        ToolCall("1", "write_file", {"path": "hello.py", "content": "print('hi')\n"})
                    ],
                ),
                Turn(text="Done."),
            ]
        )
        agent = Agent(provider, "test-model", self.root)
        events = list(agent.run_turn("make hello.py"))

        kinds = [event[0] for event in events]
        self.assertEqual(kinds, ["text", "tool_call", "tool_result", "text"])
        self.assertEqual((self.root / "hello.py").read_text(), "print('hi')\n")
        self.assertIn("created", events[2][2])

    def test_messages_are_recorded_for_follow_up_turns(self):
        provider = ScriptedProvider([Turn(text="first answer")])
        agent = Agent(provider, "test-model", self.root)
        list(agent.run_turn("question one"))
        self.assertEqual([m["role"] for m in agent.messages], ["user", "assistant"])
        self.assertEqual(agent.messages[-1]["text"], "first answer")
        self.assertTrue(provider.seen[0]["system"])

    def test_tool_schemas_are_sent_to_the_provider(self):
        provider = ScriptedProvider([Turn(text="ok")])
        agent = Agent(provider, "test-model", self.root)
        list(agent.run_turn("hi"))
        names = {tool["name"] for tool in provider.seen[0]["tools"]}
        self.assertEqual(
            names,
            {"list_files", "read_file", "write_file", "edit_file", "search_files", "run_command"},
        )

    def test_step_limit_emits_notice(self):
        provider = ScriptedProvider([Turn(tool_calls=[ToolCall(str(i), "list_files", {})]) for i in range(5)])
        agent = Agent(provider, "test-model", self.root, max_steps=2)
        events = list(agent.run_turn("loop forever"))
        self.assertEqual(events[-1][0], "notice")
        self.assertIn("2 steps", events[-1][1])

    def test_provider_error_becomes_an_event(self):
        from cobalt.providers.base import ProviderError

        class Broken(Provider):
            def list_models(self):
                return []

            def chat(self, model, system, messages, tools):
                raise ProviderError("HTTP 401: bad key")

        agent = Agent(Broken(), "m", self.root)
        events = list(agent.run_turn("hi"))
        self.assertEqual(events[0][0], "error")
        self.assertIn("401", events[0][1])

    def test_empty_prompt_is_ignored(self):
        provider = ScriptedProvider([])
        agent = Agent(provider, "m", self.root)
        self.assertEqual(list(agent.run_turn("   ")), [])
        self.assertEqual(provider.seen, [])

    def test_raw_parts_are_kept_for_the_next_request(self):
        provider = ScriptedProvider([Turn(text="hi", raw_parts=[{"text": "hi", "thoughtSignature": "S"}])])
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("x"))
        self.assertEqual(agent.messages[-1]["raw_parts"], [{"text": "hi", "thoughtSignature": "S"}])

    def test_reset_clears_history(self):
        provider = ScriptedProvider([Turn(text="a")])
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("hi"))
        agent.reset()
        self.assertEqual(agent.messages, [])

    def test_format_call_is_compact(self):
        rendered = format_call("write_file", {"path": "a" * 200})
        self.assertTrue(rendered.startswith("write_file "))
        self.assertLessEqual(len(rendered), 135)

    def test_usage_is_accumulated_and_reset(self):
        provider = ScriptedProvider(
            [
                Turn(text="a", usage={"input": 10, "output": 5}),
                Turn(text="b", usage={"input": 3, "output": 2}),
            ]
        )
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("one"))
        self.assertEqual(agent.usage, {"input": 10, "output": 5, "turns": 1})
        list(agent.run_turn("two"))
        self.assertEqual(agent.usage, {"input": 13, "output": 7, "turns": 2})
        agent.reset()
        self.assertEqual(agent.usage, {"input": 0, "output": 0, "turns": 0})

    def test_effort_changes_prompt_and_step_budget(self):
        agent = Agent(ScriptedProvider([]), "m", self.root)
        self.assertEqual(agent.effort, "medium")
        self.assertEqual(agent.max_steps, 40)
        self.assertTrue(agent.set_effort("extra"))
        self.assertEqual(agent.effort, "extra")
        self.assertEqual(agent.max_steps, 90)
        prompt = agent.system_prompt()
        self.assertIn("Effort: extra", prompt)
        self.assertIn("maximum effort", prompt.lower())
        self.assertFalse(agent.set_effort("ultra"))
        self.assertEqual(agent.effort, "extra")

    def test_explicit_max_steps_survives_effort_change(self):
        agent = Agent(ScriptedProvider([]), "m", self.root, max_steps=2)
        agent.set_effort("low")
        self.assertEqual(agent.max_steps, 2)


if __name__ == "__main__":
    unittest.main()

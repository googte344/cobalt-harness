import tempfile
import unittest
from pathlib import Path

from cobalt.agent import Agent, _turn_groups, format_call
from cobalt.config import parse_context_window
from cobalt.providers.base import Provider, ToolCall, Turn


class ScriptedProvider(Provider):
    def __init__(self, turns):
        self.turns = list(turns)
        self.seen = []

    def list_models(self):
        return []

    def chat(self, model, system, messages, tools):
        self.seen.append({"model": model, "system": system, "messages": list(messages), "tools": tools})
        if self.turns:
            return self.turns.pop(0)
        return Turn(text="nothing left to do")


class AgentTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_tool_loop_creates_a_file(self):
        provider = ScriptedProvider(
            [
                Turn(
                    text="Creating the file.",
                    tool_calls=[
                        ToolCall("1", "write_file", {"path": "hello.py", "content": "print('hi')\n"})
                    ],
                ),
                Turn(text="Done."),
            ]
        )
        agent = Agent(provider, "test-model", self.root)
        events = list(agent.run_turn("make hello.py"))

        kinds = [event[0] for event in events]
        self.assertEqual(kinds, ["text", "tool_call", "tool_result", "text"])
        self.assertEqual((self.root / "hello.py").read_text(), "print('hi')\n")
        self.assertIn("created", events[2][2])

    def test_messages_are_recorded_for_follow_up_turns(self):
        provider = ScriptedProvider([Turn(text="first answer")])
        agent = Agent(provider, "test-model", self.root)
        list(agent.run_turn("question one"))
        self.assertEqual([m["role"] for m in agent.messages], ["user", "assistant"])
        self.assertEqual(agent.messages[-1]["text"], "first answer")
        self.assertTrue(provider.seen[0]["system"])

    def test_tool_schemas_are_sent_to_the_provider(self):
        provider = ScriptedProvider([Turn(text="ok")])
        agent = Agent(provider, "test-model", self.root)
        list(agent.run_turn("hi"))
        names = {tool["name"] for tool in provider.seen[0]["tools"]}
        self.assertEqual(
            names,
            {"list_files", "read_file", "write_file", "edit_file", "search_files", "run_command"},
        )

    def test_step_limit_emits_notice(self):
        provider = ScriptedProvider([Turn(tool_calls=[ToolCall(str(i), "list_files", {})]) for i in range(5)])
        agent = Agent(provider, "test-model", self.root, max_steps=2)
        events = list(agent.run_turn("loop forever"))
        self.assertEqual(events[-1][0], "notice")
        self.assertIn("2 steps", events[-1][1])

    def test_provider_error_becomes_an_event(self):
        from cobalt.providers.base import ProviderError

        class Broken(Provider):
            def list_models(self):
                return []

            def chat(self, model, system, messages, tools):
                raise ProviderError("HTTP 401: bad key")

        agent = Agent(Broken(), "m", self.root)
        events = list(agent.run_turn("hi"))
        self.assertEqual(events[0][0], "error")
        self.assertIn("401", events[0][1])

    def test_empty_prompt_is_ignored(self):
        provider = ScriptedProvider([])
        agent = Agent(provider, "m", self.root)
        self.assertEqual(list(agent.run_turn("   ")), [])
        self.assertEqual(provider.seen, [])

    def test_raw_parts_are_kept_for_the_next_request(self):
        provider = ScriptedProvider([Turn(text="hi", raw_parts=[{"text": "hi", "thoughtSignature": "S"}])])
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("x"))
        self.assertEqual(agent.messages[-1]["raw_parts"], [{"text": "hi", "thoughtSignature": "S"}])

    def test_reset_clears_history(self):
        provider = ScriptedProvider([Turn(text="a")])
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("hi"))
        agent.reset()
        self.assertEqual(agent.messages, [])

    def test_format_call_is_compact(self):
        rendered = format_call("write_file", {"path": "a" * 200})
        self.assertTrue(rendered.startswith("write_file "))
        self.assertLessEqual(len(rendered), 135)

    def test_usage_is_accumulated_and_reset(self):
        provider = ScriptedProvider(
            [
                Turn(text="a", usage={"input": 10, "output": 5}),
                Turn(text="b", usage={"input": 3, "output": 2}),
            ]
        )
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("one"))
        self.assertEqual(agent.usage, {"input": 10, "output": 5, "turns": 1})
        list(agent.run_turn("two"))
        self.assertEqual(agent.usage, {"input": 13, "output": 7, "turns": 2})
        agent.reset()
        self.assertEqual(agent.usage, {"input": 0, "output": 0, "turns": 0})

    def test_effort_changes_prompt_and_step_budget(self):
        agent = Agent(ScriptedProvider([]), "m", self.root)
        self.assertEqual(agent.effort, "medium")
        self.assertEqual(agent.max_steps, 40)
        self.assertTrue(agent.set_effort("extra"))
        self.assertEqual(agent.effort, "extra")
        self.assertEqual(agent.max_steps, 90)
        prompt = agent.system_prompt()
        self.assertIn("Effort: extra", prompt)
        self.assertIn("maximum effort", prompt.lower())
        self.assertFalse(agent.set_effort("ultra"))
        self.assertEqual(agent.effort, "extra")

    def test_explicit_max_steps_survives_effort_change(self):
        agent = Agent(ScriptedProvider([]), "m", self.root, max_steps=2)
        agent.set_effort("low")
        self.assertEqual(agent.max_steps, 2)

    def test_yolo_off_asks_before_creating_a_file(self):
        provider = ScriptedProvider(
            [
                Turn(tool_calls=[ToolCall("1", "write_file", {"path": "x.py", "content": "x"})]),
                Turn(text="ok"),
            ]
        )
        asked = []
        agent = Agent(
            provider,
            "m",
            self.root,
            yolo=False,
            approve=lambda name, args: asked.append((name, args["path"])) or False,
        )
        events = list(agent.run_turn("write it"))
        self.assertEqual(asked, [("write_file", "x.py")])
        self.assertFalse((self.root / "x.py").exists())
        results = [event for event in events if event[0] == "tool_result"]
        self.assertIn("declined", results[0][2])
        self.assertTrue(any(event[0] == "notice" and "declined" in event[1] for event in events))

    def test_yolo_off_applies_an_approved_file(self):
        provider = ScriptedProvider(
            [
                Turn(tool_calls=[ToolCall("1", "write_file", {"path": "x.py", "content": "hi\n"})]),
                Turn(text="done"),
            ]
        )
        agent = Agent(provider, "m", self.root, yolo=False, approve=lambda name, args: True)
        list(agent.run_turn("write it"))
        self.assertEqual((self.root / "x.py").read_text(), "hi\n")

    def test_yolo_on_never_asks(self):
        provider = ScriptedProvider(
            [Turn(tool_calls=[ToolCall("1", "write_file", {"path": "x.py", "content": "hi"})]), Turn(text="done")]
        )
        asked = []
        agent = Agent(provider, "m", self.root, approve=lambda name, args: asked.append(name) or True)
        list(agent.run_turn("write it"))
        self.assertEqual(asked, [])
        self.assertTrue((self.root / "x.py").exists())

    def test_cancel_stops_before_tools_run(self):
        class CancellingProvider(ScriptedProvider):
            def chat(self, model, system, messages, tools):
                turn = super().chat(model, system, messages, tools)
                self.agent.cancel()
                return turn

        provider = CancellingProvider(
            [Turn(tool_calls=[ToolCall("1", "write_file", {"path": "x.py", "content": "x"})])]
        )
        agent = Agent(provider, "m", self.root)
        provider.agent = agent
        events = list(agent.run_turn("write it"))
        self.assertEqual(events[-1], ("notice", "cancelled"))
        self.assertFalse((self.root / "x.py").exists())

    def test_context_window_parsing(self):
        self.assertEqual(parse_context_window("8192"), 8192)
        self.assertEqual(parse_context_window("128k"), 128_000)
        self.assertEqual(parse_context_window("1.5m"), 1_500_000)
        self.assertEqual(parse_context_window("8,192 tokens"), 8192)
        self.assertIsNone(parse_context_window("off"))
        self.assertIsNone(parse_context_window(0))
        with self.assertRaises(ValueError):
            parse_context_window("banana")
        with self.assertRaises(ValueError):
            parse_context_window(-5)

    def test_turn_groups_keep_tool_calls_with_their_results(self):
        messages = [
            {"role": "user", "text": "go"},
            {"role": "assistant", "text": "", "tool_calls": [ToolCall("1", "list_files", {})]},
            {"role": "tool", "tool_call_id": "1", "name": "list_files", "text": "a.py"},
            {"role": "user", "text": "again"},
            {"role": "assistant", "text": "done"},
        ]
        self.assertEqual(
            [[message["role"] for message in group] for group in _turn_groups(messages)],
            [["user", "assistant", "tool"], ["user", "assistant"]],
        )

    def test_context_window_trims_old_turns_from_requests_only(self):
        provider = ScriptedProvider(
            [
                Turn(text="first " + "x" * 4000),
                Turn(text="second " + "y" * 4000),
                Turn(text="third"),
            ]
        )
        agent = Agent(provider, "m", self.root, context_window=2000)
        list(agent.run_turn("first question"))
        list(agent.run_turn("second question"))
        events = list(agent.run_turn("third question"))
        sent = provider.seen[-1]["messages"]
        texts = [message.get("text", "") for message in sent]
        self.assertIn("third question", texts)
        self.assertNotIn("first question", texts)
        self.assertEqual(len(agent.messages), 6)  # the app keeps the full transcript
        self.assertTrue(any(event[0] == "notice" and "context window" in event[1] for event in events))

    def test_context_window_always_keeps_the_current_turn(self):
        provider = ScriptedProvider([Turn(text="ok")])
        agent = Agent(provider, "m", self.root, context_window=1000)
        list(agent.run_turn("only question"))
        sent = provider.seen[0]["messages"]
        self.assertEqual(sent[0]["role"], "user")
        self.assertEqual(sent[0]["text"], "only question")

    def test_context_used_comes_from_the_last_request(self):
        provider = ScriptedProvider([Turn(text="a", usage={"input": 321, "output": 5})])
        agent = Agent(provider, "m", self.root)
        list(agent.run_turn("hi"))
        self.assertEqual(agent.context_used, 321)
        self.assertIsNone(agent.context_window)
        self.assertTrue(agent.set_context_window("8k"))
        self.assertEqual(agent.context_window, 8000)
        self.assertFalse(agent.set_context_window("nope"))
        self.assertEqual(agent.context_window, 8000)


if __name__ == "__main__":
    unittest.main()

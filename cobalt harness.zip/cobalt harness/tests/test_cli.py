import unittest
from unittest import mock

import cobalt.cli as cli
from cobalt.config import Config
from cobalt.providers.base import ModelInfo, ProviderError, explain_error
from cobalt.theme import Theme


class ExplainErrorTests(unittest.TestCase):
    def test_invalid_key_gets_a_hint(self):
        detail = explain_error("HTTP 400: API key not valid. Please pass a valid API key.")
        self.assertIn("rejected this key", detail)
        self.assertIn("Copy it again", detail)

    def test_quota_gets_a_hint(self):
        self.assertIn("rate limit", explain_error("HTTP 429: quota exceeded"))

    def test_network_error_gets_a_hint(self):
        self.assertIn("connection", explain_error("network error: [Errno -2] getaddrinfo failed"))

    def test_timeout_gets_a_hint(self):
        self.assertIn("in time", explain_error("request timed out after 180.0s"))

    def test_unknown_error_is_passed_through(self):
        self.assertEqual(explain_error("something odd"), "something odd")


class FormatWarningTests(unittest.TestCase):
    def test_google_key_prefix(self):
        self.assertEqual(cli._format_warning("google", "AIzaSyABC"), "")
        self.assertIn("AIza", cli._format_warning("google", "sk-or-v1-abc"))

    def test_openrouter_key_prefix(self):
        self.assertEqual(cli._format_warning("openrouter", "sk-or-v1-abc"), "")
        self.assertIn("sk-or-", cli._format_warning("openrouter", "AIzaSyABC"))


class VerifyKeyTests(unittest.TestCase):
    def test_success_reports_model_counts(self):
        models = [
            ModelInfo("a", "A", "google", "free"),
            ModelInfo("b", "B", "google", "paid"),
        ]
        with mock.patch.object(cli, "GoogleProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = models
            ok, detail = cli._verify_key("google", "AIzaSyABC")
        self.assertTrue(ok)
        self.assertIn("2 models", detail)
        self.assertIn("1 free", detail)
        provider_cls.assert_called_once_with("AIzaSyABC")

    def test_key_is_cleaned_before_use(self):
        models = [ModelInfo("a", "A", "google", "free")]
        with mock.patch.object(cli, "GoogleProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = models
            cli._verify_key("google", '  "AIzaSyABC"  ')
        provider_cls.assert_called_once_with("AIzaSyABC")

    def test_rejection_is_explained(self):
        with mock.patch.object(cli, "GoogleProvider") as provider_cls:
            provider_cls.return_value.list_models.side_effect = ProviderError(
                "HTTP 400: API key not valid. Please pass a valid API key."
            )
            ok, detail = cli._verify_key("google", "AIzaSyABC")
        self.assertFalse(ok)
        self.assertIn("rejected this key", detail)

    def test_empty_models_is_a_failure(self):
        with mock.patch.object(cli, "GoogleProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = []
            ok, detail = cli._verify_key("google", "AIzaSyABC")
        self.assertFalse(ok)
        self.assertIn("no usable models", detail)

    def test_openrouter_uses_its_own_provider(self):
        with mock.patch.object(cli, "OpenRouterProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = [ModelInfo("x/y:free", "Y", "openrouter", "free")]
            ok, _ = cli._verify_key("openrouter", "sk-or-v1-abc")
        self.assertTrue(ok)
        provider_cls.assert_called_once_with("sk-or-v1-abc")

    def test_openrouter_validates_the_key_not_just_the_model_list(self):
        with mock.patch.object(cli, "OpenRouterProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = [ModelInfo("x/y:free", "Y", "openrouter", "free")]
            cli._verify_key("openrouter", "sk-or-v1-abc")
        provider_cls.return_value.check_key.assert_called_once_with()

    def test_openrouter_rejects_a_fake_key_even_though_models_are_public(self):
        with mock.patch.object(cli, "OpenRouterProvider") as provider_cls:
            provider_cls.return_value.check_key.side_effect = ProviderError("HTTP 401: No auth credentials found")
            provider_cls.return_value.list_models.return_value = [ModelInfo("x/y:free", "Y", "openrouter", "free")]
            ok, detail = cli._verify_key("openrouter", "sk-or-v1-fake")
        self.assertFalse(ok)
        self.assertIn("rejected this key", detail)

    def test_google_does_not_call_the_openrouter_check(self):
        with mock.patch.object(cli, "GoogleProvider") as provider_cls:
            provider_cls.return_value.list_models.return_value = [ModelInfo("a", "A", "google", "free")]
            ok, _ = cli._verify_key("google", "AIzaSyABC")
        self.assertTrue(ok)
        self.assertFalse(hasattr(provider_cls.return_value, "check_key") and provider_cls.return_value.check_key.called)


class CatalogueTests(unittest.TestCase):
    def _fake_load(self, cfg, name=None):
        if name == "ollama":
            raise ProviderError("could not reach Ollama at http://localhost:11434")
        return [ModelInfo("a", "A", name or "google", "free")]

    def test_unreachable_ollama_is_skipped_silently(self):
        cfg = Config(provider="google")
        cfg.set_key("google", "AIza")
        with mock.patch.object(cli, "load_models", side_effect=self._fake_load):
            models, warnings = cli._catalogue(cfg, Theme(color=False))
        self.assertEqual([model.id for model in models], ["a"])
        self.assertEqual(warnings, [])

    def test_unreachable_ollama_is_reported_when_it_is_selected(self):
        cfg = Config(provider="ollama")
        cfg.set_key("google", "AIza")
        with mock.patch.object(cli, "load_models", side_effect=self._fake_load):
            models, warnings = cli._catalogue(cfg, Theme(color=False))
        self.assertTrue(models)
        self.assertTrue(any("Ollama" in warning for warning in warnings))


if __name__ == "__main__":
    unittest.main()

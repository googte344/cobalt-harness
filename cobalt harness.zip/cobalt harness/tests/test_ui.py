import threading
import time
import unittest
from pathlib import Path

from cobalt.providers.base import ModelInfo
from cobalt.theme import Theme, visible_width, wrap
from cobalt.ui import CobaltUI, Entry

MODELS = [
    ModelInfo("gemini-3.8-flash", "Gemini 3.8 Flash", "google", "free"),
    ModelInfo("gemini-4-argon", "Gemini 4 Argon", "google", "paid"),
    ModelInfo("vendor/free:free", "Vendor Free", "openrouter", "free"),
]


class DummyAgent:
    def __init__(self):
        self.messages = []
        self.usage = {"input": 0, "output": 0, "turns": 0}
        self.effort = "medium"
        self.yolo = True
        self.cancelled = False
        self.context_window = None
        self.context_used = 0

    def run_turn(self, text):
        yield ("text", "ok")

    def reset(self):
        self.messages = []

    def set_effort(self, level):
        self.effort = level
        return True

    def set_yolo(self, enabled):
        self.yolo = enabled

    def cancel(self):
        self.cancelled = True

    def set_context_window(self, value):
        self.context_window = value


def build(
    theme=None,
    models=None,
    selected=0,
    on_model=None,
    on_provider=None,
    provider_status=None,
    on_folder=None,
    on_effort=None,
    effort="",
):
    return CobaltUI(
        agent=DummyAgent(),
        models=list(models or MODELS),
        project=Path("/tmp/project"),
        theme=theme or Theme(color=False, unicode=True),
        provider_label="Google AI Studio",
        on_model=on_model,
        selected=selected,
        on_provider=on_provider,
        provider_status=provider_status,
        on_folder=on_folder,
        on_effort=on_effort,
        effort=effort,
    )


class WrapTests(unittest.TestCase):
    def test_wrap_keeps_lines_within_width(self):
        text = "the quick brown fox jumps over the lazy dog " * 3
        for line in wrap(text, 20):
            self.assertLessEqual(visible_width(line), 20)

    def test_wrap_respects_explicit_newlines(self):
        self.assertEqual(wrap("a\nb", 20), ["a", "b"])

    def test_wrap_hard_breaks_long_words(self):
        lines = wrap("x" * 50, 10)
        self.assertEqual(len(lines), 5)
        self.assertTrue(all(len(line) == 10 for line in lines))

    def test_wide_characters_count_as_two_columns(self):
        self.assertEqual(visible_width("\u4f60\u597d"), 4)


class FrameTests(unittest.TestCase):
    def test_every_row_is_exactly_the_terminal_width(self):
        ui = build()
        for cols, rows in ((80, 24), (100, 30), (140, 40), (60, 18)):
            frame = ui.compose(cols, rows)
            self.assertEqual(len(frame), rows, (cols, rows))
            for line in frame:
                self.assertEqual(visible_width(line), cols, (cols, rows, line))

    def test_frame_without_colour_has_no_escapes(self):
        frame = build(Theme(color=False)).compose(100, 30)
        self.assertFalse(any("\x1b" in line for line in frame))

    def test_frame_with_colour_uses_blue_and_white(self):
        frame = build(Theme(color=True)).compose(100, 30)
        joined = "\n".join(frame)
        self.assertIn("\x1b[", joined)
        self.assertIn("38;5;39", joined)  # blue
        self.assertIn("38;5;231", joined)  # white

    def test_ascii_mode_uses_plus_borders(self):
        frame = build(Theme(color=False, unicode=False)).compose(100, 30)
        self.assertIn("+", frame[1])
        self.assertNotIn("\u256d", "\n".join(frame))

    def test_sidebar_lists_models_and_tiers(self):
        joined = "\n".join(build().compose(100, 30))
        self.assertIn("Gemini 3.8 Flash", joined)
        self.assertIn("FREE", joined)
        self.assertIn("PAID", joined)
        self.assertIn("GOOGLE AI STUDIO", joined)
        self.assertNotIn("Vendor Free", joined)

    def test_top_bar_shows_effort_and_token_usage(self):
        ui = build()
        ui.agent.usage = {"input": 1200, "output": 340, "turns": 2}
        top = ui.compose(120, 30)[0]
        self.assertIn("medium", top)
        self.assertIn("1.5k tok", top)
        self.assertIn("Google AI Studio", top)

    def test_bottom_bar_lists_commands_then_hotkeys(self):
        bottom = build().compose(100, 30)[-1]
        for command in (
            "/api",
            "/folder",
            "/effort",
            "/context",
            "/yolo",
            "/cancel",
            "/clear",
            "/help",
            "/exit",
        ):
            self.assertIn(command, bottom)
        # At 100 columns the obvious "enter send" hint makes way first.
        self.assertIn("tab models", bottom)
        self.assertIn("ctrl+c quit", bottom)
        wide = build().compose(140, 30)[-1]
        for hotkey in ("tab models", "enter send", "ctrl+c quit"):
            self.assertIn(hotkey, wide)
        self.assertNotIn("/model", bottom)
        self.assertNotIn("/tab", bottom)

    def test_welcome_text_before_first_message(self):
        joined = "\n".join(build().compose(100, 30))
        self.assertIn("Tell Cobalt what to build", joined)

    def test_user_message_appears_in_transcript(self):
        ui = build()
        ui.entries.append(Entry("user", "hello there"))
        joined = "\n".join(ui.compose(100, 30))
        self.assertIn("YOU", joined)
        self.assertIn("hello there", joined)

    def test_long_transcript_scrolls(self):
        ui = build()
        for index in range(60):
            ui.entries.append(Entry("user", "message %d" % index))
        bottom = "\n".join(ui.compose(100, 30))
        self.assertIn("message 59", bottom)
        self.assertNotIn("message 0", bottom)
        ui.scroll = 40
        scrolled = "\n".join(ui.compose(100, 30))
        self.assertNotIn("message 59", scrolled)


class KeyTests(unittest.TestCase):
    def test_typing_builds_the_input_buffer(self):
        ui = build()
        for char in "hi":
            ui.handle_key(char)
        self.assertEqual(ui.input, "hi")
        ui.handle_key("backspace")
        self.assertEqual(ui.input, "h")

    def test_tab_toggles_focus(self):
        ui = build()
        self.assertEqual(ui.focus, "input")
        ui.handle_key("tab")
        self.assertEqual(ui.focus, "models")
        ui.handle_key("tab")
        self.assertEqual(ui.focus, "input")

    def test_arrow_keys_move_model_selection(self):
        ui = build()
        ui.handle_key("tab")
        ui.handle_key("down")
        self.assertEqual(ui.selected, 1)
        ui.handle_key("up")
        self.assertEqual(ui.selected, 0)
        ui.handle_key("up")
        self.assertEqual(ui.selected, 0)

    def test_enter_applies_selection_without_switching_provider(self):
        switched = []

        def on_model(model):
            switched.append(model.id)
            return None

        ui = build(on_model=on_model)
        ui.handle_key("tab")
        ui.handle_key("down")
        ui.handle_key("down")
        ui.handle_key("enter")
        self.assertEqual(switched, ["gemini-4-argon"])
        self.assertEqual(ui.focus, "input")
        self.assertEqual(ui.provider_label, "Google AI Studio")

    def test_selection_is_confined_to_the_active_provider(self):
        ui = build(selected=2)
        self.assertEqual(ui.provider_filter, "google")
        self.assertEqual(ui.current.id, "gemini-3.8-flash")

    def test_slash_exit_stops_the_ui(self):
        ui = build()
        for char in "/exit":
            ui.handle_key(char)
        ui.handle_key("enter")
        self.assertFalse(ui.running)

    def test_ctrl_c_stops_the_ui(self):
        ui = build()
        ui.handle_key("ctrl-c")
        self.assertFalse(ui.running)

    def test_empty_submit_does_nothing(self):
        ui = build()
        ui.handle_key("enter")
        self.assertEqual(ui.entries, [])
        self.assertFalse(ui.busy)

    def test_model_switch_failure_is_shown(self):
        ui = build(on_model=lambda model: "could not switch provider: bad key")
        ui.handle_key("tab")
        ui.handle_key("enter")
        self.assertTrue(any("could not switch" in entry.text for entry in ui.entries))


class ApiCommandTests(unittest.TestCase):
    def type_command(self, ui, text):
        for char in text:
            ui.handle_key(char)
        ui.handle_key("enter")

    def test_api_google_filters_the_sidebar(self):
        ui = build(provider_status=lambda: [("google", "Google AI Studio", True), ("openrouter", "OpenRouter", True)])
        self.type_command(ui, "/api google")
        self.assertEqual(ui.provider_filter, "google")
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("Gemini 3.8 Flash", frame)
        self.assertNotIn("Vendor Free", frame)

    def test_other_providers_stay_hidden_until_api_switches(self):
        ui = build(
            provider_status=lambda: [
                ("google", "Google AI Studio", True),
                ("openrouter", "OpenRouter", True),
                ("ollama", "Ollama (local)", True),
            ]
        )
        self.assertEqual(ui.provider_filter, "google")
        self.type_command(ui, "/api openrouter")
        self.assertEqual(ui.provider_filter, "openrouter")
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("Vendor Free", frame)
        self.assertNotIn("Gemini 3.8 Flash", frame)

    def test_api_all_no_longer_mixes_providers(self):
        ui = build()
        self.type_command(ui, "/api all")
        self.assertEqual(ui.provider_filter, "google")
        self.assertTrue(any("usage: /api" in entry.text for entry in ui.entries))

    def test_api_prompts_for_a_key_when_provider_has_none(self):
        ui = build(provider_status=lambda: [("google", "Google AI Studio", True), ("openrouter", "OpenRouter", False)])
        self.type_command(ui, "/api openrouter")
        self.assertEqual(ui.key_for, "openrouter")
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("API KEY", frame)

    def test_typed_key_is_masked_and_never_shown(self):
        ui = build(provider_status=lambda: [("google", "Google AI Studio", True), ("openrouter", "OpenRouter", False)])
        self.type_command(ui, "/api openrouter")
        for char in "sk-or-v1-secret":
            ui.handle_key(char)
        frame = "\n".join(ui.compose(100, 30))
        self.assertNotIn("sk-or-v1-secret", frame)
        self.assertIn("*" * len("sk-or-v1-secret"), frame)

    def test_entering_a_key_connects_and_merges_models(self):
        seen = {}

        def on_provider(provider, key):
            seen["provider"] = provider
            seen["key"] = key
            return [ModelInfo("vendor/new:free", "Vendor New", "openrouter", "free")], None

        ui = build(
            on_provider=on_provider,
            provider_status=lambda: [("google", "Google AI Studio", True), ("openrouter", "OpenRouter", False)],
        )
        self.type_command(ui, "/api openrouter")
        for char in "sk-or-v1-secret":
            ui.handle_key(char)
        ui.handle_key("enter")
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.busy:
            ui.pump()
            time.sleep(0.02)
        ui.pump()
        self.assertEqual(seen, {"provider": "openrouter", "key": "sk-or-v1-secret"})
        self.assertIn("vendor/new:free", [model.id for model in ui.models])
        self.assertEqual(ui.provider_filter, "openrouter")
        self.assertTrue(any("connected to OpenRouter" in entry.text for entry in ui.entries))

    def test_failed_connection_is_reported(self):
        ui = build(
            on_provider=lambda provider, key: ([], "HTTP 400: API key not valid"),
            provider_status=lambda: [("google", "Google AI Studio", True), ("openrouter", "OpenRouter", False)],
        )
        self.type_command(ui, "/api openrouter")
        ui.key_buffer = "bad"
        ui.handle_key("enter")
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.busy:
            ui.pump()
            time.sleep(0.02)
        ui.pump()
        self.assertTrue(any("API key not valid" in entry.text for entry in ui.entries))

    def test_api_picker_lists_providers(self):
        ui = build()
        self.type_command(ui, "/api")
        self.assertEqual(ui.picker, "providers")
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("PROVIDERS", frame)
        self.assertIn("OpenRouter", frame)
        ui.handle_key("down")
        self.assertEqual(ui.provider_index, 1)

    def test_api_ollama_connects_without_a_key(self):
        ui = build(
            on_provider=lambda provider, key: (
                [ModelInfo("llama3.2:latest", "llama3.2", "ollama", "free")],
                None,
            ),
            provider_status=lambda: [
                ("google", "Google AI Studio", True),
                ("openrouter", "OpenRouter", False),
                ("ollama", "Ollama (local)", True),
            ],
        )
        self.type_command(ui, "/api ollama")
        self.assertIsNone(ui.key_for)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.busy:
            ui.pump()
            time.sleep(0.02)
        ui.pump()
        self.assertEqual(ui.provider_filter, "ollama")
        self.assertIn("llama3.2:latest", [model.id for model in ui.models])
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("OLLAMA (LOCAL)", frame)

    def test_api_key_is_refused_for_ollama(self):
        ui = build(models=[ModelInfo("llama3.2:latest", "llama3.2", "ollama", "free")])
        self.type_command(ui, "/api key")
        self.assertIsNone(ui.key_for)
        self.assertTrue(any("needs no API key" in entry.text for entry in ui.entries))

    def test_api_llamacpp_connects_without_a_key(self):
        ui = build(
            on_provider=lambda provider, key: (
                [ModelInfo("qwen2.5-coder-7b.gguf", "qwen2.5-coder-7b", "llamacpp", "free")],
                None,
            ),
            provider_status=[
                ("google", "Google AI Studio", True),
                ("openrouter", "OpenRouter", False),
                ("ollama", "Ollama (local)", True),
                ("llamacpp", "llama.cpp (local)", True),
            ],
        )
        self.type_command(ui, "/api llamacpp")
        self.assertIsNone(ui.key_for)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.busy:
            ui.pump()
            time.sleep(0.02)
        ui.pump()
        self.assertEqual(ui.provider_filter, "llamacpp")
        self.assertIn("qwen2.5-coder-7b.gguf", [model.id for model in ui.models])
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("LLAMA.CPP (LOCAL)", frame)

    def test_api_accepts_llama_cpp_spelling(self):
        ui = build(
            on_provider=lambda provider, key: (
                [ModelInfo("qwen.gguf", "qwen", "llamacpp", "free")],
                None,
            ),
            provider_status=[
                ("google", "Google AI Studio", True),
                ("llamacpp", "llama.cpp (local)", True),
            ],
        )
        self.type_command(ui, "/api llama.cpp")
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.busy:
            ui.pump()
            time.sleep(0.02)
        ui.pump()
        self.assertEqual(ui.provider_filter, "llamacpp")

    def test_api_key_is_refused_for_llamacpp(self):
        ui = build(
            models=[ModelInfo("qwen.gguf", "qwen", "llamacpp", "free")],
            provider_status=[("llamacpp", "llama.cpp (local)", True)],
        )
        self.type_command(ui, "/api key")
        self.assertIsNone(ui.key_for)
        self.assertTrue(any("needs no API key" in entry.text for entry in ui.entries))

    def test_folder_command_shows_the_current_folder(self):
        ui = build()
        self.type_command(ui, "/folder")
        self.assertTrue(any("project folder: /tmp/project" in entry.text for entry in ui.entries))

    def test_folder_command_changes_the_folder_and_clears_the_conversation(self):
        seen = {}

        def on_folder(raw):
            seen["raw"] = raw
            return Path("/tmp/other project"), None

        ui = build(on_folder=on_folder)
        ui.agent.messages = [{"role": "user", "text": "old project task"}]
        self.type_command(ui, "/folder /tmp/other project")
        self.assertEqual(seen["raw"], "/tmp/other project")
        self.assertEqual(ui.project, Path("/tmp/other project"))
        self.assertEqual(ui.agent.messages, [])
        self.assertTrue(any("project folder is now /tmp/other project" in entry.text for entry in ui.entries))

    def test_folder_error_is_reported(self):
        ui = build(on_folder=lambda raw: (None, "/tmp/x is a file, not a folder"))
        self.type_command(ui, "/folder /tmp/x")
        self.assertEqual(ui.project, Path("/tmp/project"))
        self.assertTrue(any("is a file, not a folder" in entry.text for entry in ui.entries))

    def test_model_slash_command_is_gone_and_tab_opens_models(self):
        ui = build()
        self.type_command(ui, "/model")
        self.assertTrue(any("unknown command /model" in entry.text for entry in ui.entries))
        self.assertEqual(ui.focus, "input")
        ui.handle_key("tab")
        self.assertEqual(ui.focus, "models")

    def test_unknown_api_argument_is_explained(self):
        ui = build()
        self.type_command(ui, "/api bogus")
        self.assertTrue(any("usage: /api" in entry.text for entry in ui.entries))


class EffortTests(unittest.TestCase):
    def type_command(self, ui, text):
        for char in text:
            ui.handle_key(char)
        ui.handle_key("enter")

    def test_effort_command_sets_the_level(self):
        ui = build()
        self.type_command(ui, "/effort high")
        self.assertEqual(ui.effort, "high")
        self.assertEqual(ui.agent.effort, "high")
        self.assertTrue(any("effort set to high" in entry.text for entry in ui.entries))

    def test_effort_without_argument_shows_the_current_level(self):
        ui = build()
        self.type_command(ui, "/effort")
        self.assertTrue(any("effort: medium" in entry.text for entry in ui.entries))

    def test_unknown_effort_lists_the_levels(self):
        ui = build()
        self.type_command(ui, "/effort turbo")
        self.assertEqual(ui.effort, "medium")
        self.assertTrue(any("usage: /effort low|medium|high|extra" in entry.text for entry in ui.entries))

    def test_effort_alias_and_persistence_callback(self):
        seen = []
        ui = build(on_effort=lambda level: seen.append(level))
        self.type_command(ui, "/effort max")
        self.assertEqual(seen, ["extra"])
        self.assertEqual(ui.effort, "extra")
        self.assertEqual(ui.agent.effort, "extra")


class YoloCancelTests(unittest.TestCase):
    def type_command(self, ui, text):
        for char in text:
            ui.handle_key(char)
        ui.handle_key("enter")

    def test_yolo_toggles_and_is_shared_with_the_agent(self):
        ui = build()
        self.assertTrue(ui.yolo)
        self.type_command(ui, "/yolo")
        self.assertFalse(ui.yolo)
        self.assertFalse(ui.agent.yolo)
        self.assertTrue(any("YOLO off" in entry.text for entry in ui.entries))
        self.type_command(ui, "/yolo on")
        self.assertTrue(ui.yolo)
        self.assertTrue(ui.agent.yolo)

    def test_yolo_off_asks_before_a_file_change(self):
        ui = build()
        self.type_command(ui, "/yolo off")
        answers = []
        worker = threading.Thread(
            target=lambda: answers.append(ui.request_approval("write_file", {"path": "app.py"}))
        )
        worker.start()
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.pending_approval is None:
            time.sleep(0.01)
        self.assertIsNotNone(ui.pending_approval)
        frame = "\n".join(ui.compose(100, 30))
        self.assertIn("CONFIRM", frame)
        self.assertIn("create app.py", frame)
        ui.handle_key("y")
        worker.join(5)
        self.assertEqual(answers, [True])
        self.assertIsNone(ui.pending_approval)

    def test_declining_a_file_change_unblocks_the_agent(self):
        ui = build()
        self.type_command(ui, "/yolo off")
        answers = []
        worker = threading.Thread(target=lambda: answers.append(ui.request_approval("edit_file", {"path": "a.py"})))
        worker.start()
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and ui.pending_approval is None:
            time.sleep(0.01)
        ui.handle_key("n")
        worker.join(5)
        self.assertEqual(answers, [False])

    def test_cancel_while_busy_reaches_the_agent(self):
        ui = build()
        ui.busy = True
        self.type_command(ui, "/cancel")
        self.assertTrue(ui.agent.cancelled)
        self.assertTrue(ui.cancel_requested)
        self.assertTrue(any("cancelling" in entry.text for entry in ui.entries))
        self.assertEqual(ui.input, "")

    def test_cancel_when_idle_says_nothing_is_running(self):
        ui = build()
        self.type_command(ui, "/cancel")
        self.assertTrue(any("nothing is running" in entry.text for entry in ui.entries))


class ContextWindowTests(unittest.TestCase):
    def type_command(self, ui, text):
        for char in text:
            ui.handle_key(char)
        ui.handle_key("enter")

    def test_context_command_sets_any_number_on_the_agent(self):
        ui = build()
        self.type_command(ui, "/context 8192")
        self.assertEqual(ui.context_window, 8192)
        self.assertEqual(ui.agent.context_window, 8192)
        self.assertTrue(any("8,192" in entry.text for entry in ui.entries))

    def test_context_command_accepts_short_units(self):
        ui = build()
        self.type_command(ui, "/context 128k")
        self.assertEqual(ui.context_window, 128_000)
        self.type_command(ui, "/context 1.5m")
        self.assertEqual(ui.context_window, 1_500_000)

    def test_context_command_can_be_cleared(self):
        ui = build()
        self.type_command(ui, "/context 4000")
        self.type_command(ui, "/context off")
        self.assertIsNone(ui.context_window)
        self.assertIsNone(ui.agent.context_window)
        self.assertTrue(any("cleared" in entry.text for entry in ui.entries))

    def test_context_without_argument_shows_the_current_window(self):
        ui = build()
        self.type_command(ui, "/context")
        self.assertTrue(any("not set" in entry.text for entry in ui.entries))
        ui.agent.context_used = 1234
        self.type_command(ui, "/context 8000")
        self.type_command(ui, "/context")
        self.assertTrue(any("1,234" in entry.text for entry in ui.entries))

    def test_invalid_context_number_is_rejected(self):
        ui = build()
        self.type_command(ui, "/context banana")
        self.assertIsNone(ui.context_window)
        self.assertTrue(any("usage: /context" in entry.text for entry in ui.entries))

    def test_original_spelling_still_works_as_an_alias(self):
        ui = build()
        self.type_command(ui, "/conteext 16k")
        self.assertEqual(ui.context_window, 16_000)


if __name__ == "__main__":
    unittest.main()

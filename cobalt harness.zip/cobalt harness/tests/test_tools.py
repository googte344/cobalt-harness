import tempfile
import unittest
from pathlib import Path

from cobalt import tools


class ToolTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def test_write_creates_folders_and_file(self):
        result = tools.dispatch(
            "write_file", {"path": "src/app.py", "content": "print('hi')\n"}, self.root
        )
        self.assertIn("created", result)
        self.assertEqual((self.root / "src/app.py").read_text(), "print('hi')\n")

    def test_write_then_read_roundtrip(self):
        tools.dispatch("write_file", {"path": "a.txt", "content": "one\ntwo\nthree\n"}, self.root)
        result = tools.dispatch("read_file", {"path": "a.txt"}, self.root)
        self.assertIn("3 lines total", result)
        self.assertIn("two", result)

    def test_read_line_range(self):
        tools.dispatch("write_file", {"path": "a.txt", "content": "1\n2\n3\n4\n"}, self.root)
        result = tools.dispatch("read_file", {"path": "a.txt", "start_line": 2, "end_line": 3}, self.root)
        self.assertIn("showing 2-3", result)
        self.assertIn("2", result)
        self.assertNotIn("4", result.split("\n")[-1])

    def test_edit_replaces_exactly_one_occurrence(self):
        tools.dispatch("write_file", {"path": "a.py", "content": "value = 1\n"}, self.root)
        result = tools.dispatch(
            "edit_file", {"path": "a.py", "old_string": "value = 1", "new_string": "value = 2"}, self.root
        )
        self.assertIn("edited", result)
        self.assertEqual((self.root / "a.py").read_text(), "value = 2\n")

    def test_edit_refuses_ambiguous_match(self):
        tools.dispatch("write_file", {"path": "a.py", "content": "x = 1\ny = 1\n"}, self.root)
        result = tools.dispatch(
            "edit_file", {"path": "a.py", "old_string": "1", "new_string": "2"}, self.root
        )
        self.assertTrue(result.startswith("error:"))
        self.assertIn("2 times", result)
        self.assertEqual((self.root / "a.py").read_text(), "x = 1\ny = 1\n")

    def test_edit_replace_all(self):
        tools.dispatch("write_file", {"path": "a.py", "content": "x = 1\ny = 1\n"}, self.root)
        tools.dispatch(
            "edit_file",
            {"path": "a.py", "old_string": "1", "new_string": "2", "replace_all": True},
            self.root,
        )
        self.assertEqual((self.root / "a.py").read_text(), "x = 2\ny = 2\n")

    def test_edit_missing_file_is_reported_to_model(self):
        result = tools.dispatch(
            "edit_file", {"path": "nope.py", "old_string": "a", "new_string": "b"}, self.root
        )
        self.assertTrue(result.startswith("error:"))
        self.assertIn("no such file", result)

    def test_list_files_marks_folders(self):
        tools.dispatch("write_file", {"path": "pkg/mod.py", "content": ""}, self.root)
        result = tools.dispatch("list_files", {"path": "."}, self.root)
        self.assertIn("pkg/", result)

    def test_search_files_reports_line_numbers(self):
        tools.dispatch("write_file", {"path": "a.py", "content": "import os\nprint('needle')\n"}, self.root)
        result = tools.dispatch("search_files", {"pattern": "needle"}, self.root)
        self.assertIn("a.py:2", result)

    def test_search_rejects_invalid_regex(self):
        result = tools.dispatch("search_files", {"pattern": "("}, self.root)
        self.assertIn("invalid regex", result)

    def test_path_escape_is_blocked(self):
        result = tools.dispatch("read_file", {"path": "../outside.txt"}, self.root)
        self.assertTrue(result.startswith("error:"))
        self.assertIn("escapes the project folder", result)

    def test_absolute_path_outside_root_is_blocked(self):
        result = tools.dispatch("write_file", {"path": "/tmp/cobalt-escape.txt", "content": "x"}, self.root)
        self.assertTrue(result.startswith("error:"))
        self.assertFalse(Path("/tmp/cobalt-escape.txt").exists())

    def test_run_command_returns_output(self):
        result = tools.dispatch("run_command", {"command": "echo cobalt"}, self.root)
        self.assertIn("exit code: 0", result)
        self.assertIn("cobalt", result)

    def test_run_command_uses_project_root(self):
        tools.dispatch("write_file", {"path": "marker.txt", "content": "here"}, self.root)
        result = tools.dispatch("run_command", {"command": "cat marker.txt"}, self.root)
        self.assertIn("here", result)

    def test_destructive_command_is_refused(self):
        result = tools.dispatch("run_command", {"command": "rm -rf /"}, self.root)
        self.assertIn("refused", result)

    def test_unknown_tool_is_reported(self):
        result = tools.dispatch("nope", {}, self.root)
        self.assertIn("unknown tool", result)

    def test_bad_arguments_are_reported(self):
        result = tools.dispatch("read_file", {"nope": 1}, self.root)
        self.assertTrue(result.startswith("error:"))


if __name__ == "__main__":
    unittest.main()

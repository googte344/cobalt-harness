import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from cobalt.config import Config, clean_key, config_path, key_conflicts, load, mask, save


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.home = Path(self._tmp.name)
        self.env = mock.patch.dict(os.environ, {"COBALT_HOME": str(self.home)}, clear=False)
        self.env.start()
        for name in (
            "COBALT_GOOGLE_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
            "COBALT_OPENROUTER_KEY",
            "OPENROUTER_API_KEY",
            "COBALT_OLLAMA_URL",
            "COBALT_LLAMACPP_URL",
            "COBALT_LLAMACPP_KEY",
        ):
            os.environ.pop(name, None)

    def tearDown(self):
        self.env.stop()
        self._tmp.cleanup()

    def test_missing_file_returns_defaults(self):
        cfg = load()
        self.assertEqual(cfg.provider, "google")
        self.assertEqual(cfg.stored_keys, {})

    def test_roundtrip(self):
        cfg = Config(project_dir="/tmp/app", provider="openrouter", model="vendor/model")
        cfg.set_key("openrouter", "sk-test-123")
        save(cfg)
        self.assertTrue(config_path().exists())
        again = load()
        self.assertEqual(again.project_dir, "/tmp/app")
        self.assertEqual(again.provider, "openrouter")
        self.assertEqual(again.model, "vendor/model")
        self.assertEqual(again.key("openrouter"), "sk-test-123")

    def test_env_key_beats_stored_key(self):
        cfg = Config()
        cfg.set_key("google", "from-file")
        with mock.patch.dict(os.environ, {"GOOGLE_API_KEY": "from-env"}, clear=False):
            self.assertEqual(cfg.key("google"), "from-env")
            self.assertEqual(cfg.key_source("google"), "env:GOOGLE_API_KEY")

    def test_stored_key_used_without_env(self):
        cfg = Config()
        cfg.set_key("google", "from-file")
        self.assertEqual(cfg.key("google"), "from-file")
        self.assertEqual(cfg.key_source("google"), "config")

    def test_clear_key(self):
        cfg = Config()
        cfg.set_key("google", "abc")
        cfg.set_key("google", "")
        self.assertIsNone(cfg.key("google"))

    def test_corrupt_file_is_ignored(self):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("{not json", encoding="utf-8")
        self.assertEqual(load().stored_keys, {})

    def test_unicode_setting_persists(self):
        save(Config(unicode=False))
        self.assertIs(load().unicode, False)

    def test_providers_with_keys(self):
        cfg = Config()
        cfg.set_key("google", "g")
        self.assertEqual(cfg.providers_with_keys(), ["google"])
        cfg.set_key("openrouter", "o")
        self.assertEqual(cfg.providers_with_keys(), ["google", "openrouter"])

    def test_clean_key_strips_quotes_and_whitespace(self):
        self.assertEqual(clean_key('  "AIzaSy123"  '), "AIzaSy123")
        self.assertEqual(clean_key("'sk-or-v1-abc'"), "sk-or-v1-abc")
        self.assertEqual(clean_key("AIzaSy 123\n"), "AIzaSy123")
        self.assertEqual(clean_key("Bearer sk-or-v1-abc"), "sk-or-v1-abc")
        self.assertEqual(clean_key(None), "")

    def test_set_key_cleans_input(self):
        cfg = Config()
        cfg.set_key("google", '  "AIzaSy123" ')
        self.assertEqual(cfg.key("google"), "AIzaSy123")

    def test_key_conflicts_flags_env_override(self):
        cfg = Config()
        cfg.set_key("google", "AIzaSaved")
        with mock.patch.dict(os.environ, {"GOOGLE_API_KEY": "AIzaDifferent"}, clear=False):
            problems = key_conflicts(cfg)
        self.assertEqual(len(problems), 1)
        self.assertIn("GOOGLE_API_KEY", problems[0])
        self.assertIn("overrides", problems[0])

    def test_key_conflicts_silent_when_env_matches(self):
        cfg = Config()
        cfg.set_key("google", "AIzaSame")
        with mock.patch.dict(os.environ, {"GOOGLE_API_KEY": " \"AIzaSame\" "}, clear=False):
            self.assertEqual(key_conflicts(cfg), [])

    def test_key_conflicts_silent_without_stored_key(self):
        cfg = Config()
        with mock.patch.dict(os.environ, {"GOOGLE_API_KEY": "AIzaEnv"}, clear=False):
            self.assertEqual(key_conflicts(cfg), [])

    def test_local_providers_need_no_key(self):
        cfg = Config()
        self.assertTrue(cfg.has_key("ollama"))
        self.assertTrue(cfg.has_key("llamacpp"))
        self.assertEqual(cfg.providers_with_keys(), [])
        self.assertEqual(cfg.catalogue_providers(), ["ollama", "llamacpp"])

    def test_ollama_base_default_config_and_env(self):
        cfg = Config()
        self.assertEqual(cfg.ollama_base(), "http://localhost:11434")
        cfg.ollama_url = "http://box:11434"
        self.assertEqual(cfg.ollama_base(), "http://box:11434")
        with mock.patch.dict(os.environ, {"COBALT_OLLAMA_URL": "http://remote:11434"}, clear=False):
            self.assertEqual(cfg.ollama_base(), "http://remote:11434")

    def test_ollama_url_persists(self):
        save(Config(ollama_url="http://box:11434"))
        self.assertEqual(load().ollama_url, "http://box:11434")

    def test_llamacpp_base_default_config_and_env(self):
        cfg = Config()
        self.assertEqual(cfg.llamacpp_base(), "http://localhost:8080")
        cfg.llamacpp_url = "http://box:8080"
        self.assertEqual(cfg.llamacpp_base(), "http://box:8080")
        with mock.patch.dict(os.environ, {"COBALT_LLAMACPP_URL": "http://remote:8080"}, clear=False):
            self.assertEqual(cfg.llamacpp_base(), "http://remote:8080")
            self.assertEqual(cfg.local_base("llamacpp"), "http://remote:8080")
            self.assertEqual(cfg.local_base("ollama"), "http://localhost:11434")

    def test_llamacpp_url_persists(self):
        save(Config(llamacpp_url="http://box:8080"))
        self.assertEqual(load().llamacpp_url, "http://box:8080")

    def test_llamacpp_optional_api_key_from_env(self):
        cfg = Config()
        with mock.patch.dict(os.environ, {"COBALT_LLAMACPP_KEY": "secret"}, clear=False):
            self.assertEqual(cfg.key("llamacpp"), "secret")

    def test_effort_defaults_and_persists(self):
        self.assertEqual(Config().effort, "medium")
        save(Config(effort="high"))
        self.assertEqual(load().effort, "high")

    def test_invalid_saved_effort_falls_back_to_medium(self):
        save(Config(effort="turbo"))
        self.assertEqual(load().effort, "medium")

    def test_mask(self):
        self.assertEqual(mask(None), "not set")
        self.assertEqual(mask("short"), "sh\u2026")
        self.assertTrue(mask("sk-or-v1-abcdefgh").startswith("sk-o"))


if __name__ == "__main__":
    unittest.main()

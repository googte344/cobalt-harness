import unittest
from unittest import mock

import cobalt.providers.google as google_mod
import cobalt.providers.ollama as ollama_mod
import cobalt.providers.openrouter as openrouter_mod
from cobalt.providers.base import ProviderError, ToolCall
from cobalt.providers.google import GoogleProvider
from cobalt.providers.ollama import OllamaProvider, clean_path, normalize_base
from cobalt.providers.openrouter import OpenRouterProvider

TOOLS = [
    {
        "name": "read_file",
        "description": "read",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "p"}},
            "required": ["path"],
        },
    }
]


WRITE_TOOLS = [
    {
        "name": "write_file",
        "description": "write",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"],
        },
    }
]


class GoogleProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = GoogleProvider("key-123")

    def test_list_models_filters_embeddings_and_assigns_tiers(self):
        payload = {
            "models": [
                {"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-4-argon", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/embedding-001", "supportedGenerationMethods": ["embedContent"]},
                {"name": "models/text-embedding-004", "supportedGenerationMethods": ["embedContent"]},
            ]
        }
        with mock.patch.object(google_mod, "http_json", return_value=payload) as http:
            models = self.provider.list_models()
        self.assertEqual([m.id for m in models], ["gemini-2.5-flash", "gemini-4-argon"])
        self.assertEqual(models[0].tier, "free")
        self.assertEqual(models[1].tier, "paid")
        self.assertIn("/models?", http.call_args[0][0])

    def test_list_models_falls_back_to_static_table_when_empty(self):
        with mock.patch.object(google_mod, "http_json", return_value={"models": []}):
            models = self.provider.list_models()
        self.assertTrue(models)
        self.assertTrue(all(m.provider == "google" for m in models))

    def test_chat_parses_text_and_function_call(self):
        payload = {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {"text": "Checking the file."},
                            {"functionCall": {"name": "read_file", "args": {"path": "a.py"}}},
                        ]
                    },
                    "finishReason": "STOP",
                }
            ]
        }
        with mock.patch.object(google_mod, "http_json", return_value=payload):
            turn = self.provider.chat("gemini-2.5-flash", "system text", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.text, "Checking the file.")
        self.assertEqual(len(turn.tool_calls), 1)
        self.assertEqual(turn.tool_calls[0].name, "read_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "a.py"})

    def test_chat_request_shape(self):
        payload = {"candidates": [{"content": {"parts": [{"text": "ok"}]}}]}
        with mock.patch.object(google_mod, "http_json", return_value=payload) as http:
            self.provider.chat("models/gemini-2.5-flash", "sys", [{"role": "user", "text": "hi"}], TOOLS)
        url = http.call_args[0][0]
        body = http.call_args[0][1]
        self.assertTrue(url.endswith("models/gemini-2.5-flash:generateContent"))
        self.assertEqual(body["systemInstruction"]["parts"][0]["text"], "sys")
        self.assertEqual(body["contents"][0]["parts"][0]["text"], "hi")
        declaration = body["tools"][0]["functionDeclarations"][0]
        self.assertEqual(declaration["name"], "read_file")
        self.assertEqual(declaration["parameters"]["type"], "OBJECT")
        self.assertEqual(declaration["parameters"]["properties"]["path"]["type"], "STRING")

    def test_chat_converts_tool_results_to_function_response(self):
        payload = {"candidates": [{"content": {"parts": [{"text": "ok"}]}}]}
        messages = [
            {"role": "user", "text": "hi"},
            {
                "role": "assistant",
                "text": "",
                "tool_calls": [],
            },
            {"role": "tool", "name": "read_file", "tool_call_id": "1", "text": "contents"},
        ]
        with mock.patch.object(google_mod, "http_json", return_value=payload) as http:
            self.provider.chat("gemini-2.5-flash", "", messages, TOOLS)
        contents = http.call_args[0][1]["contents"]
        self.assertEqual(contents[-1]["parts"][0]["functionResponse"]["name"], "read_file")
        self.assertEqual(contents[-1]["parts"][0]["functionResponse"]["response"]["result"], "contents")

    def test_chat_without_candidates_raises(self):
        with mock.patch.object(google_mod, "http_json", return_value={"promptFeedback": {"blockReason": "SAFETY"}}):
            with self.assertRaises(ProviderError) as caught:
                self.provider.chat("gemini-2.5-flash", "", [{"role": "user", "text": "x"}], TOOLS)
        self.assertIn("SAFETY", str(caught.exception))

    def test_missing_key_is_rejected(self):
        with self.assertRaises(ProviderError):
            GoogleProvider("")

    def test_thought_signature_is_kept_on_function_calls(self):
        payload = {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {
                                "functionCall": {"name": "run_command", "args": {"command": "ls"}},
                                "thoughtSignature": "SIG-123",
                            }
                        ]
                    }
                }
            ]
        }
        with mock.patch.object(google_mod, "http_json", return_value=payload):
            turn = self.provider.chat("gemini-3.6-flash", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.tool_calls[0].raw.get("thoughtSignature"), "SIG-123")
        self.assertEqual(turn.raw_parts[0]["thoughtSignature"], "SIG-123")

    def test_history_replays_raw_parts_with_signatures(self):
        messages = [
            {"role": "user", "text": "hi"},
            {
                "role": "assistant",
                "text": "",
                "tool_calls": [ToolCall("1", "run_command", {"command": "ls"})],
                "raw_parts": [
                    {
                        "functionCall": {"name": "run_command", "args": {"command": "ls"}},
                        "thoughtSignature": "SIG-123",
                    }
                ],
            },
            {"role": "tool", "name": "run_command", "tool_call_id": "1", "text": "ok"},
        ]
        payload = {"candidates": [{"content": {"parts": [{"text": "done"}]}}]}
        with mock.patch.object(google_mod, "http_json", return_value=payload) as http:
            self.provider.chat("gemini-3.6-flash", "", messages, TOOLS)
        contents = http.call_args[0][1]["contents"]
        self.assertEqual(contents[1]["parts"][0]["thoughtSignature"], "SIG-123")

    def test_history_rebuilt_without_raw_parts_keeps_signature_from_tool_call(self):
        messages = [
            {"role": "user", "text": "hi"},
            {
                "role": "assistant",
                "text": "",
                "tool_calls": [
                    ToolCall("1", "run_command", {"command": "ls"}, raw={"thoughtSignature": "SIG-9"})
                ],
            },
        ]
        payload = {"candidates": [{"content": {"parts": [{"text": "done"}]}}]}
        with mock.patch.object(google_mod, "http_json", return_value=payload) as http:
            self.provider.chat("gemini-3.6-flash", "", messages, TOOLS)
        contents = http.call_args[0][1]["contents"]
        self.assertEqual(contents[1]["parts"][0]["thoughtSignature"], "SIG-9")

    def test_missing_signature_error_retries_without_tool_parts(self):
        messages = [
            {"role": "user", "text": "hi"},
            {
                "role": "assistant",
                "text": "",
                "tool_calls": [ToolCall("1", "run_command", {"command": "ls"})],
                "raw_parts": [{"functionCall": {"name": "run_command", "args": {"command": "ls"}}}],
            },
            {"role": "tool", "name": "run_command", "tool_call_id": "1", "text": "ok"},
        ]
        payload = {"candidates": [{"content": {"parts": [{"text": "recovered"}]}}]}
        error = ProviderError(
            "HTTP 400: Function call is missing a thought_signature in functionCall parts. "
            "This is required for tools to work correctly."
        )
        with mock.patch.object(google_mod, "http_json", side_effect=[error, payload]) as http:
            turn = self.provider.chat("gemini-3.6-flash", "", messages, TOOLS)
        self.assertEqual(turn.text, "recovered")
        self.assertEqual(http.call_count, 2)
        retry_body = http.call_args_list[1][0][1]
        parts = [part for content in retry_body["contents"] for part in content["parts"]]
        self.assertTrue(all("functionCall" not in part for part in parts))
        self.assertTrue(any("called run_command" in part.get("text", "") for part in parts))

    def test_other_errors_are_not_retried(self):
        with mock.patch.object(google_mod, "http_json", side_effect=ProviderError("HTTP 429: quota")) as http:
            with self.assertRaises(ProviderError):
                self.provider.chat("gemini-3.6-flash", "", [{"role": "user", "text": "x"}], TOOLS)
        self.assertEqual(http.call_count, 1)

    def test_thought_parts_are_not_shown_as_answer_text(self):
        payload = {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {"text": "internal reasoning", "thought": True, "thoughtSignature": "S"},
                            {"text": "final answer"},
                        ]
                    }
                }
            ]
        }
        with mock.patch.object(google_mod, "http_json", return_value=payload):
            turn = self.provider.chat("gemini-3.6-flash", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.text, "final answer")
        self.assertEqual(len(turn.raw_parts), 2)

    def test_tier_hint_after_discovery(self):
        payload = {"models": [{"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]}]}
        with mock.patch.object(google_mod, "http_json", return_value=payload):
            self.provider.list_models()
        self.assertEqual(self.provider.tier_hint("gemini-4-argon"), "not listed for this key")
        self.assertEqual(self.provider.tier_hint("gemini-2.5-flash"), "")

    def test_chat_records_token_usage(self):
        payload = {
            "candidates": [{"content": {"parts": [{"text": "ok"}]}}],
            "usageMetadata": {"promptTokenCount": 120, "candidatesTokenCount": 45},
        }
        with mock.patch.object(google_mod, "http_json", return_value=payload):
            turn = self.provider.chat("gemini-2.5-flash", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.usage, {"input": 120, "output": 45})


class OpenRouterProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = OpenRouterProvider("or-key")

    def test_list_models_marks_zero_price_as_free(self):
        payload = {
            "data": [
                {"id": "vendor/free-model:free", "name": "Free Model", "pricing": {"prompt": "0", "completion": "0"}},
                {
                    "id": "vendor/paid-model",
                    "name": "Paid Model",
                    "pricing": {"prompt": "0.000003", "completion": "0.000015"},
                },
            ]
        }
        with mock.patch.object(openrouter_mod, "http_json", return_value=payload) as http:
            models = self.provider.list_models()
        self.assertEqual([m.id for m in models], ["vendor/free-model:free", "vendor/paid-model"])
        self.assertEqual(models[0].tier, "free")
        self.assertEqual(models[1].tier, "paid")
        headers = http.call_args.kwargs["headers"]
        self.assertEqual(headers["Authorization"], "Bearer or-key")

    def test_chat_parses_tool_calls_with_json_arguments(self):
        payload = {
            "choices": [
                {
                    "message": {
                        "content": "Let me look.",
                        "tool_calls": [
                            {
                                "id": "call_1",
                                "type": "function",
                                "function": {
                                    "name": "read_file",
                                    "arguments": '{"path": "a.py"}',
                                },
                            }
                        ],
                    }
                }
            ]
        }
        with mock.patch.object(openrouter_mod, "http_json", return_value=payload):
            turn = self.provider.chat("vendor/model", "sys", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.text, "Let me look.")
        self.assertEqual(turn.tool_calls[0].name, "read_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "a.py"})
        self.assertEqual(turn.tool_calls[0].id, "call_1")

    def test_chat_request_shape(self):
        payload = {"choices": [{"message": {"content": "ok"}}]}
        with mock.patch.object(openrouter_mod, "http_json", return_value=payload) as http:
            self.provider.chat("vendor/model", "sys", [{"role": "user", "text": "hi"}], TOOLS)
        body = http.call_args[0][1]
        self.assertEqual(body["model"], "vendor/model")
        self.assertEqual(body["messages"][0], {"role": "system", "content": "sys"})
        self.assertEqual(body["messages"][1], {"role": "user", "content": "hi"})
        self.assertEqual(body["tools"][0]["function"]["name"], "read_file")

    def test_check_key_calls_the_key_endpoint(self):
        with mock.patch.object(openrouter_mod, "http_json", return_value={"data": {"label": "sk-or-...1234"}}) as http:
            detail = self.provider.check_key()
        self.assertTrue(http.call_args[0][0].endswith("/key"))
        self.assertIn("sk-or-...1234", detail)

    def test_malformed_tool_arguments_raise(self):
        payload = {
            "choices": [
                {
                    "message": {
                        "tool_calls": [
                            {"id": "1", "function": {"name": "read_file", "arguments": "{not json"}}
                        ]
                    }
                }
            ]
        }
        with mock.patch.object(openrouter_mod, "http_json", return_value=payload):
            with self.assertRaises(ProviderError):
                self.provider.chat("vendor/model", "", [{"role": "user", "text": "x"}], TOOLS)

    def test_empty_choices_raise(self):
        with mock.patch.object(openrouter_mod, "http_json", return_value={"choices": []}):
            with self.assertRaises(ProviderError):
                self.provider.chat("vendor/model", "", [{"role": "user", "text": "x"}], TOOLS)

    def test_chat_records_token_usage(self):
        payload = {
            "choices": [{"message": {"content": "ok"}}],
            "usage": {"prompt_tokens": 33, "completion_tokens": 12},
        }
        with mock.patch.object(openrouter_mod, "http_json", return_value=payload):
            turn = self.provider.chat("vendor/model", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.usage, {"input": 33, "output": 12})


class OllamaProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = OllamaProvider("localhost:11434")

    def test_base_url_is_normalized(self):
        self.assertEqual(self.provider.base, "http://localhost:11434")
        self.assertEqual(normalize_base("http://box:11434/"), "http://box:11434")
        self.assertEqual(normalize_base(""), "http://localhost:11434")

    def test_list_models_uses_only_installed_models(self):
        payload = {
            "models": [
                {"name": "llama3.2:latest", "model": "llama3.2:latest", "size": 2019393189},
                {"name": "qwen2.5-coder:7b", "model": "qwen2.5-coder:7b", "size": 4683087332},
            ]
        }
        with mock.patch.object(ollama_mod, "http_json", return_value=payload) as http:
            models = self.provider.list_models()
        self.assertEqual([m.id for m in models], ["llama3.2:latest", "qwen2.5-coder:7b"])
        self.assertEqual(models[0].name, "llama3.2")
        self.assertEqual(models[0].provider, "ollama")
        self.assertEqual(models[0].tier, "free")
        self.assertIn("installed", models[0].note)
        self.assertTrue(http.call_args[0][0].endswith("/api/tags"))

    def test_no_installed_models_is_explained(self):
        with mock.patch.object(ollama_mod, "http_json", return_value={"models": []}):
            with self.assertRaises(ProviderError) as caught:
                self.provider.list_models()
        self.assertIn("ollama pull", str(caught.exception))

    def test_connection_failure_mentions_serve(self):
        refused = ProviderError("network error: [Errno 111] Connection refused")
        with mock.patch.object(ollama_mod, "http_json", side_effect=refused):
            with self.assertRaises(ProviderError) as caught:
                self.provider.list_models()
        self.assertIn("ollama serve", str(caught.exception))

    def test_chat_request_shape(self):
        payload = {"message": {"role": "assistant", "content": "ok"}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload) as http:
            turn = self.provider.chat("llama3.2", "sys", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertTrue(http.call_args[0][0].endswith("/api/chat"))
        body = http.call_args[0][1]
        self.assertFalse(body["stream"])
        self.assertEqual(body["model"], "llama3.2")
        self.assertEqual(body["messages"][0], {"role": "system", "content": "sys"})
        self.assertEqual(body["messages"][1], {"role": "user", "content": "hi"})
        self.assertEqual(body["tools"][0]["function"]["name"], "read_file")
        self.assertEqual(turn.text, "ok")

    def test_chat_parses_tool_calls(self):
        payload = {
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {"function": {"name": "read_file", "arguments": {"path": "a.py"}}},
                    {"function": {"name": "run_command", "arguments": '{"command": "ls"}'}},
                ],
            }
        }
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual([call.name for call in turn.tool_calls], ["read_file", "run_command"])
        self.assertEqual(turn.tool_calls[1].arguments, {"command": "ls"})

    def test_history_keeps_tool_calls_and_results(self):
        messages = [
            {"role": "user", "text": "hi"},
            {"role": "assistant", "text": "", "tool_calls": [ToolCall("1", "read_file", {"path": "a.py"})]},
            {"role": "tool", "name": "read_file", "tool_call_id": "1", "text": "contents"},
        ]
        with mock.patch.object(ollama_mod, "http_json", return_value={"message": {"content": "done"}}) as http:
            self.provider.chat("llama3.2", "", messages, TOOLS)
        body = http.call_args[0][1]
        self.assertEqual(body["messages"][1]["tool_calls"][0]["function"]["arguments"], {"path": "a.py"})
        self.assertEqual(
            body["messages"][2], {"role": "tool", "content": "contents", "tool_name": "read_file"}
        )

    def test_malformed_tool_arguments_raise(self):
        payload = {"message": {"tool_calls": [{"function": {"name": "read_file", "arguments": "{not json"}}]}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            with self.assertRaises(ProviderError):
                self.provider.chat("llama3.2", "", [{"role": "user", "text": "x"}], TOOLS)

    def test_text_encoded_tool_call_is_recovered(self):
        payload = {
            "message": {
                "content": '```json\n{"name": "write_file", "arguments": {"path": "a.txt", "content": "hi"}}\n```\n\nI created the file.'
            }
        }
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "make a.txt"}], WRITE_TOOLS)
        self.assertEqual(len(turn.tool_calls), 1)
        self.assertEqual(turn.tool_calls[0].name, "write_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "a.txt", "content": "hi"})
        self.assertNotIn("```", turn.text)
        self.assertIn("I created the file.", turn.text)

    def test_bare_json_tool_call_is_recovered(self):
        payload = {
            "message": {
                "content": '{"function": {"name": "read_file", "arguments": {"path": "a.py"}}}'
            }
        }
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "read a.py"}], TOOLS)
        self.assertEqual(turn.tool_calls[0].name, "read_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "a.py"})
        self.assertEqual(turn.text, "")

    def test_prose_mentioning_json_is_not_a_tool_call(self):
        content = 'The shape is {"name": "write_file", "arguments": {"path": "x"}} in this API.'
        payload = {"message": {"content": content}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "explain"}], TOOLS)
        self.assertEqual(turn.tool_calls, [])
        self.assertEqual(turn.text, content)

    def test_unknown_tool_in_text_is_ignored(self):
        payload = {"message": {"content": '```json\n{"name": "delete_repo", "arguments": {}}\n```'}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "x"}], TOOLS)
        self.assertEqual(turn.tool_calls, [])

    def test_chat_records_token_usage(self):
        payload = {"message": {"content": "ok"}, "prompt_eval_count": 64, "eval_count": 8}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "hi"}], TOOLS)
        self.assertEqual(turn.usage, {"input": 64, "output": 8})

    def test_alias_tool_name_and_argument_spellings_are_normalized(self):
        content = (
            '{"tool": "writeFile", "arguments": '
            '{"file": "`./hello.py`", "code": "```python\\nprint(1)\\n```"}}'
        )
        payload = {"message": {"content": content}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "make hello.py"}], WRITE_TOOLS)
        self.assertEqual(turn.tool_calls[0].name, "write_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "hello.py", "content": "print(1)"})

    def test_native_tool_call_is_normalized(self):
        payload = {
            "message": {
                "tool_calls": [
                    {
                        "function": {
                            "name": "write file",
                            "arguments": {"filename": "notes.md", "text": "# hi"},
                        }
                    }
                ]
            }
        }
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "x"}], WRITE_TOOLS)
        self.assertEqual(turn.tool_calls[0].name, "write_file")
        self.assertEqual(turn.tool_calls[0].arguments, {"path": "notes.md", "content": "# hi"})

    def test_json_on_its_own_line_after_prose_is_recovered(self):
        content = (
            "I will create it now.\n"
            '{"name": "write_file", "arguments": {"path": "a.txt", "content": "hi"}}\n'
        )
        payload = {"message": {"content": content}}
        with mock.patch.object(ollama_mod, "http_json", return_value=payload):
            turn = self.provider.chat("llama3.2", "", [{"role": "user", "text": "x"}], WRITE_TOOLS)
        self.assertEqual(len(turn.tool_calls), 1)
        self.assertEqual(turn.text, "I will create it now.")

    def test_clean_path_strips_decoration(self):
        self.assertEqual(clean_path("  `./hello.py` "), "hello.py")
        self.assertEqual(clean_path("File: hello.py"), "hello.py")
        self.assertEqual(clean_path("filename: notes.md"), "notes.md")
        self.assertEqual(clean_path("C:\\tmp\\x.py"), "C:\\tmp\\x.py")

    def test_empty_response_raises(self):
        with mock.patch.object(ollama_mod, "http_json", return_value={"message": {"content": "  "}}):
            with self.assertRaises(ProviderError):
                self.provider.chat("llama3.2", "", [{"role": "user", "text": "x"}], TOOLS)


if __name__ == "__main__":
    unittest.main()

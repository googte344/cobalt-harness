# Cobalt

A free, dependency-free terminal AI coding agent for **OpenRouter**, **Google AI Studio** and
**Ollama** (local models).
Point it at a folder, tell it what to build, and it reads the project, writes and edits files
and runs commands until the work is done.

Runs on Windows and any Linux with Python 3.9+ and nothing else to install.

```
  ██████╗ ██████╗ ██████╗  █████╗ ██╗     ████████╗
 ██╔════╝██╔═══██╗██╔══██╗██╔══██╗██║     ╚══██╔══╝
 ██║     ██║   ██║██████╔╝███████║██║        ██║
 ██║     ██║   ██║██╔══██╗██╔══██║██║        ██║
 ╚██████╗╚██████╔╝██████╔╝██║  ██║███████╗   ██║
  ╚═════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝
```

## Quick start

```bash
python -m cobalt            # or: ./run.sh   /   run.bat
```

First run asks three things: provider, API key, project folder. After that it launches straight
into the full-screen UI with your last project and model.

Options if you would rather not answer prompts:

```bash
python -m cobalt --provider google --key AIza... --project ~/code/my-app
COBALT_GOOGLE_KEY=... python -m cobalt --project .
python -m cobalt --provider ollama --project .    # local models, no key
```

Optional install (gives you a `cobalt` command):

```bash
pip install -e .
cobalt
```

## The UI

```
 ◆ COBALT  v0.1  ~/code/my-app            Google AI Studio · medium · 1.5k tok
╭─ MODELS ──────────────────╮  COBALT
│ GOOGLE AI STUDIO          │  I'll read the folder and add the tests first.
│ › Gemini 3.8 Flash   FREE │
│   Gemini 4 Argon     PAID │    › list_files {"./"}
│                           │    › write_file {"path": "tests/test_app.py", ...}
│                           │
╰───────────────────────────╯
                             ╭─ MESSAGE ───────────────────────────────────╮
                             │ › _                                         │
                             ╰─────────────────────────────────────────────╯
 /api /folder /effort /clear /help /exit   tab models   enter send   ctrl+c quit
```

The bottom bar lists every slash command (marked with `/`) followed by the plain hotkeys that do
not use a slash: `tab models`, `enter send`, `ctrl+c quit`. The active model sits on the right when
there is room; on narrow terminals it gives way, since the sidebar already highlights it.

Keys:

| Key | Action |
| --- | --- |
| `enter` | send the message (or pick a model in the sidebar) |
| `↑` `↓` / `j` `k` | move through the model list |
| `tab` | switch focus between the message box and the sidebar |
| `esc` | leave the sidebar |
| `pgup` / `pgdn` | scroll the transcript |
| `ctrl+u` | clear the message |
| `ctrl+c` | quit |

Slash commands:

| Command | What it does |
| --- | --- |
| `/api` | open the provider picker in the sidebar (`↑`/`↓` + `enter`) |
| `/api google` / `/api openrouter` / `/api ollama` | switch straight to a provider |
| `/api key` | paste a new key for the current provider (input is hidden) |
| `/folder` / `/folder <path>` | show or change the project folder (creates it and clears the conversation) |
| `/effort` / `/effort low\|medium\|high\|extra` | show or set how hard the model tries |
| `/clear` | reset the conversation |
| `/help` | command list |
| `/exit` | quit |

`/api` is the only way to change provider. Switching loads that provider's models, saves it as
the default for next launch, and asks for a key if one is not configured yet. The key is not
echoed and is tested before it is saved. Ollama needs no key: it connects to the local server and
lists the models installed there. Until you switch, the sidebar lists only the active provider's
models, so picking a model never changes backend. Use `--provider` to start on a different one.

The top-right corner is a usage monitor: tokens spent in this conversation, counted from the
provider's own usage figures (input + output) plus the current effort level. `/clear` and
`/folder` reset the counters along with the conversation.

`/effort` sets how much the model should try, and it is remembered in the config:

| Level | Steps | What it asks for |
| --- | --- | --- |
| `low` | 15 | the smallest answer or change that works, no extra checks |
| `medium` | 40 | read what you touch, make a complete change, run the obvious check (default) |
| `high` | 60 | inspect related files, cover edge cases, run the tests and fix failures |
| `extra` | 90 | plan, weigh alternatives, re-run checks, verify behaviour, report what is unverified |

The level is written into the system prompt, so the model is told how much to attempt rather than
just being cut off sooner; the step budget is the hard limit behind it. `/effort max` is accepted
as a shorthand for `extra`.

## Models and tiers

The sidebar shows a `FREE` or `PAID` badge for every model.

**Google AI Studio** tiers are detected from the table below and cross-checked against the
models your key can actually use:

| Tier | Models |
| --- | --- |
| free | Gemini 3.8 / 3.7 / 3.6 / 3.5 Flash, 3.5 & 3.1 Flash-Lite, 3.8 Flash TTS, 2.5 Pro, 2.5 Flash / Flash-Lite, Gemma 4 |
| paid | Gemini 4 Argon, Gemini 3.1 Pro Preview |

Gemini 2.5 Pro appears on both lists, so Cobalt treats it as free and notes that it is also
sold on the paid tier. Any model not in the table is labelled `?` instead of being guessed, and
`--check` warns when a model is not listed for your key.

**OpenRouter** tiers come from the live catalogue: zero input and output price means `FREE`.

**Ollama** has no catalogue to fetch: the list is exactly what the local server reports for
`/api/tags`, i.e. the models you have pulled. Those are badged `FREE` because they run on your
own machine, and the picker can never offer a model that is not installed.

If the Gemini API cannot be reached, Cobalt falls back to the built-in table above so the
picker is never empty; the warning tells you it is using the offline list.

## Tools the model gets

| Tool | What it does |
| --- | --- |
| `list_files` | list a folder (skips `.git`, `node_modules`, venvs, build output) |
| `read_file` | read text with optional `start_line` / `end_line` |
| `write_file` | create or replace a file, making parent folders |
| `edit_file` | exact-snippet replacement, refuses ambiguous matches |
| `search_files` | regex search returning `path:line: text` |
| `run_command` | shell command in the project root, output capped |

Gemini 3 models attach a `thoughtSignature` to every function call and reject a request whose
history has lost it. Cobalt keeps the raw response parts and replays them verbatim, so multi-step
tool loops keep working; if a conversation started on another model still trips the check, the
request is retried once with the tool traffic flattened to plain text instead of failing.

Every path is resolved inside the project folder; anything that escapes it is rejected. A short
denylist blocks obviously destructive commands (`rm -rf /`, `mkfs`, `diskpart`, `shutdown`, …).
Reads, writes and command output are capped so a huge file or noisy build cannot flood the
context window.

Local models are unreliable about tool syntax, so the Ollama backend normalises what they send
before the agent runs it: `writeFile`, `create_file`, `Write File` and similar spellings map onto
`write_file`; `file`, `filename`, `filepath` map onto `path`; `text`, `code`, `contents` map onto
`content`; stray quotes, backticks, a leading `./` or `file:` are trimmed from filenames; and a
code fence wrapping the whole `content` is removed. A call the model printed as JSON instead of
calling (bare, fenced, or on its own line after prose) is recovered and executed, so it can no
longer announce a file it never wrote.

## Configuration

Stored at `~/.cobalt/config.json` (override the folder with `COBALT_HOME`, the file with
`COBALT_CONFIG`). Keys typed into the app are saved there with `0600` permissions on Linux;
environment variables always take precedence and keep keys off disk entirely:

| Provider | Environment variables |
| --- | --- |
| Google AI Studio | `COBALT_GOOGLE_KEY`, `GOOGLE_API_KEY`, `GEMINI_API_KEY` |
| OpenRouter | `COBALT_OPENROUTER_KEY`, `OPENROUTER_API_KEY` |
| Ollama | no key; `COBALT_OLLAMA_URL` changes the server (default `http://localhost:11434`) |

`--reset-config` deletes the saved file. `--check` prints the resolved project, the masked key
and source, and how many free/paid models each provider offers. The `/effort` level is stored
here as `effort` (`low`, `medium`, `high`, `extra`).

## Troubleshooting

**"I pasted a key and nothing works."** Cobalt now tests the key before saving it and prints the
provider's actual reason (`key works: 23 models available (11 free)` or the rejection plus a
suggested fix). If a key was already saved, run:

```bash
python -m cobalt --check
```

That shows the masked key, where it came from, whether the provider accepts it, and how many
free/paid models it can see. Common causes, in order of likelihood:

1. **An environment variable is overriding your saved key.** `GOOGLE_API_KEY`, `GEMINI_API_KEY`,
   `OPENROUTER_API_KEY` (and the `COBALT_*` forms) win over anything stored in the config file,
   so a stale value from another tool silently wins. `--check` and startup both warn when this
   happens. Unset it, or use that variable as your key instead.
2. **Partial paste or stray quotes.** Keys are cleaned of surrounding quotes, spaces and a
   `Bearer ` prefix, but a key that is missing characters still fails. Copy it again from
   [AI Studio](https://aistudio.google.com/apikey) / [OpenRouter](https://openrouter.ai/keys).
3. **Wrong key type.** Google AI Studio keys start with `AIza`, OpenRouter keys with `sk-or-`.
   An OpenRouter key pasted into the Google flow fails with HTTP 400.
4. **Quota.** Free tiers rate-limit per minute; HTTP 429 means wait or pick a lighter model.
5. **Model not available to your key.** HTTP 404 means the key is fine but that model is not —
   choose another in the sidebar. Paid Gemini models need billing enabled on the project.

**"Ollama is not showing up."** Cobalt only offers models that are installed, so it probes the
daemon at startup and stays quiet when nothing is listening. Start it with `ollama serve`, pull a
model (`ollama pull llama3.2`), and run `python -m cobalt --check` to see what it finds. A server
on another host or port needs `--ollama-url` (or `COBALT_OLLAMA_URL`).

Errors from a request now appear in the transcript with the model name and a next step, instead of
disappearing behind the alt screen.

## Flags

| Flag | Meaning |
| --- | --- |
| `--project PATH` | project folder |
| `--provider google\|openrouter\|ollama` | which backend to use |
| `--model ID` | preselect a model |
| `--key KEY` | save a key for the chosen provider |
| `--ollama-url URL` | Ollama server, saved to the config (default `http://localhost:11434`) |
| `--check` | verify config, test each key and list model counts |
| `--list-models` | print the whole catalogue with tiers |
| `--ascii` | ASCII borders instead of box drawing |
| `--no-color` | disable colour (also honours `NO_COLOR`) |
| `--quiet` | skip the banner |
| `--reset-config` | delete the saved config first |

## Limitations

- Single conversation per run; there is no session persistence yet.
- Responses are not streamed: you see the answer when the model finishes that step.
- The message box edits at the end of the line only (no cursor movement within the line).
- Tier data is a static table for Gemini plus whatever the API reports; if Google changes
  tiers, update `FREE_PATTERNS` / `PAID_PATTERNS` in `cobalt/providers/google.py`.

## Building a distributable bundle

```bash
python build.py                 # writes dist/cobalt.pyz
python dist/cobalt.pyz          # run the bundle
```

The build parses every module, removes docstrings, unparses (which drops all comments), compiles
to bytecode and zips it into a single `.pyz` with a small launcher. No `.py` source ships inside
the archive except the launcher, and compiled files are named after the module so tracebacks still
read `cobalt/agent.py` rather than a temp path.

Be clear-eyed about what this is worth: Python bytecode can be decompiled, so this raises the
effort of copying the source and keeps comments/internal notes out of the shipped file — it is not
protection against someone determined. The readable source in git stays the source of truth; the
bundle is a distribution artifact (`dist/` is git-ignored).

## Tests

```bash
python -m unittest discover -s tests -v
```

The suite covers tier classification, the static catalogue, every tool (including path-escape
and destructive-command rejection), the agent loop with a scripted provider, both provider
request/response shapes with mocked HTTP, config precedence, and UI frame composition at
several terminal sizes.

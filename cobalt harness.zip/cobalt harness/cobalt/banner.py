"""The start-up banner."""

from __future__ import annotations

import sys

from . import __version__
from .theme import BLUE, BLUE_BRIGHT, BLUE_DEEP, BLUE_MID, BOLD, DIM, GREY, SILVER, WHITE, Theme

# Letters are stored separately so the word can be rebuilt without width maths.
_LETTERS = {
    "C": [
        " \u2588\u2588\u2588\u2588\u2588\u2588\u2557 ",
        "\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255d ",
        "\u2588\u2588\u2551      ",
        "\u2588\u2588\u2551      ",
        "\u255a\u2588\u2588\u2588\u2588\u2588\u2588\u2557 ",
        " \u255a\u2550\u2550\u2550\u2550\u2550\u255d ",
    ],
    "O": [
        " \u2588\u2588\u2588\u2588\u2588\u2588\u2557 ",
        "\u2588\u2588\u2554\u2550\u2550\u2550\u2588\u2588\u2557",
        "\u2588\u2588\u2551   \u2588\u2588\u2551",
        "\u2588\u2588\u2551   \u2588\u2588\u2551",
        "\u255a\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d",
        " \u255a\u2550\u2550\u2550\u2550\u2550\u255d ",
    ],
    "B": [
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2557 ",
        "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557",
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d",
        "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557",
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d",
        " \u255a\u2550\u2550\u2550\u2550\u2550\u255d ",
    ],
    "A": [
        " \u2588\u2588\u2588\u2588\u2588\u2557 ",
        "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557",
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551",
        "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2551",
        "\u2588\u2588\u2551  \u2588\u2588\u2551",
        "\u255a\u2550\u255d  \u255a\u2550\u255d",
    ],
    "L": [
        "\u2588\u2588\u2557     ",
        "\u2588\u2588\u2551     ",
        "\u2588\u2588\u2551     ",
        "\u2588\u2588\u2551     ",
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557",
        "\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u255d",
    ],
    "T": [
        "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557",
        "\u255a\u2550\u2550\u2588\u2588\u2554\u2550\u2550\u255d",
        "   \u2588\u2588\u2551   ",
        "   \u2588\u2588\u2551   ",
        "   \u2588\u2588\u2551   ",
        "   \u255a\u2550\u255d   ",
    ],
}

_WORD = "COBALT"

_ASCII_MAP = {
    "\u2588": "#",
    "\u2554": "+",
    "\u2557": "+",
    "\u255a": "+",
    "\u255d": "+",
    "\u2551": "|",
    "\u2550": "=",
}

TAGLINE = "free terminal coding agent \u00b7 openrouter + google ai studio"


def banner_lines(unicode: bool = True) -> list[str]:
    rows = [""] * 6
    for letter in _WORD:
        for i, piece in enumerate(_LETTERS[letter]):
            rows[i] += piece
    rows = [r.rstrip() for r in rows]
    if unicode:
        return rows
    return ["".join(_ASCII_MAP.get(ch, ch) for ch in row) for row in rows]


def banner(theme: Theme) -> str:
    """Coloured banner block: a blue gradient from top to bottom."""
    shades = (BLUE_BRIGHT, BLUE, BLUE_MID, BLUE_MID, BLUE, BLUE_DEEP)
    art = banner_lines(theme.unicode)
    out = []
    for row, shade in zip(art, shades):
        out.append(theme.paint(row, (shade, BOLD)))
    out.append("")
    out.append(theme.paint("  " + TAGLINE, (SILVER,)))
    out.append(
        theme.paint("  v" + __version__ + "  \u00b7  openrouter + gemini keys  \u00b7  ctrl+c to quit", (GREY, DIM))
    )
    return "\n".join(out)


def splash(theme: Theme) -> None:
    """Print the banner to the terminal, using the full width for a rule."""
    try:
        width = min(78, max(60, shutil_width()))
    except Exception:
        width = 72
    print()
    print(banner(theme))
    print(theme.paint("  " + "\u2500" * (width - 4), (BLUE_DEEP,)))
    print()
    sys.stdout.flush()


def shutil_width() -> int:
    import shutil

    return shutil.get_terminal_size((80, 24)).columns

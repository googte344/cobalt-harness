"""Cross-platform raw terminal handling: alternate screen, key decoding.

POSIX uses termios + select. Windows uses msvcrt with virtual terminal
sequences enabled on the console handle. Both return the same key names:
"up", "down", "left", "right", "enter", "tab", "esc", "backspace", "delete",
"pgup", "pgdn", "home", "end", "ctrl-c", "ctrl-u", "ctrl-r", or a character.
"""

from __future__ import annotations

import os
import sys

IS_WINDOWS = os.name == "nt"

_CSI_KEYS = {
    "A": "up",
    "B": "down",
    "C": "right",
    "D": "left",
    "H": "home",
    "F": "end",
    "Z": "tab",
    "1~": "home",
    "7~": "home",
    "4~": "end",
    "8~": "end",
    "3~": "delete",
    "5~": "pgup",
    "6~": "pgdn",
}

_WIN_KEYS = {
    "H": "up",
    "P": "down",
    "K": "left",
    "M": "right",
    "G": "home",
    "O": "end",
    "S": "delete",
    "I": "pgup",
    "Q": "pgdn",
}


def _enable_windows_vt() -> None:
    """Turn on ANSI escape processing and deliver Ctrl+C as a key, not a signal."""
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        for handle_id in (-11, -10):  # stdout, stdin
            handle = kernel32.GetStdHandle(handle_id)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                value = mode.value | 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
                if handle_id == -10:
                    value &= ~0x0001  # disable ENABLE_PROCESSED_INPUT
                kernel32.SetConsoleMode(handle, value)
    except Exception:
        pass


class KeyReader:
    """Context manager that puts the terminal in raw mode and restores it."""

    def __init__(self, stream=None) -> None:
        self.stream = stream or sys.stdout
        self._posix_saved = None
        self._windows = IS_WINDOWS
        self._pending: list[str] = []

    # -- lifecycle --------------------------------------------------------
    def __enter__(self) -> "KeyReader":
        if self._windows:
            _enable_windows_vt()
        else:
            import termios
            import tty

            fd = sys.stdin.fileno()
            self._posix_saved = termios.tcgetattr(fd)
            tty.setraw(fd)
        self.write("\x1b[?1049h")  # alternate screen
        self.write("\x1b[?25l")  # hide cursor
        self.write("\x1b[2J\x1b[H")
        return self

    def __exit__(self, *exc) -> None:
        self.write("\x1b[?25h")
        self.write("\x1b[?1049l")
        if self._posix_saved is not None:
            import termios

            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self._posix_saved)
            self._posix_saved = None

    def write(self, text: str) -> None:
        try:
            self.stream.write(text)
            self.stream.flush()
        except (OSError, ValueError):
            pass

    # -- reading ----------------------------------------------------------
    def poll(self, timeout: float = 0.1) -> str | None:
        """Return the next decoded key, or None if nothing arrived in time."""
        if self._pending:
            return self._pending.pop(0)
        if self._windows:
            return self._poll_windows(timeout)
        return self._poll_posix(timeout)

    def _poll_posix(self, timeout: float) -> str | None:
        import select

        try:
            ready, _, _ = select.select([sys.stdin], [], [], timeout)
        except (OSError, ValueError):
            return None
        if not ready:
            return None
        byte = os.read(sys.stdin.fileno(), 1)
        if not byte:
            return "ctrl-c"
        return self._decode_posix(byte)

    def _read_more(self, count: int) -> bytes:
        import select

        out = b""
        for _ in range(count):
            ready, _, _ = select.select([sys.stdin], [], [], 0.05)
            if not ready:
                break
            out += os.read(sys.stdin.fileno(), 1)
        return out

    def _decode_posix(self, byte: bytes) -> str:
        if byte == b"\x1b":
            # Escape alone, or the start of a CSI / SS3 sequence.
            more = self._read_more(1)
            if not more:
                return "esc"
            if more in (b"[", b"O"):
                body = b""
                for _ in range(4):
                    nxt = self._read_more(1)
                    if not nxt:
                        break
                    body += nxt
                    if nxt.isalpha() or nxt == b"~":
                        break
                seq = body.decode("latin-1")
                return _CSI_KEYS.get(seq, _CSI_KEYS.get(seq[-1:], "esc"))
            return "esc"

        lead = byte[0]
        if lead < 0x80:
            char = byte.decode("latin-1")
        else:
            extra = 1 if lead >> 5 == 0b110 else 2 if lead >> 4 == 0b1110 else 3
            char = (byte + self._read_more(extra)).decode("utf-8", "replace")

        if char in ("\r", "\n"):
            return "enter"
        if char == "\t":
            return "tab"
        if char in ("\x7f", "\x08"):
            return "backspace"
        if char == "\x03":
            return "ctrl-c"
        if char == "\x15":
            return "ctrl-u"
        if char == "\x12":
            return "ctrl-r"
        if char == "\x04":
            return "ctrl-d"
        return char

    def _poll_windows(self, timeout: float) -> str | None:
        import msvcrt
        import time

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if msvcrt.kbhit():
                return self._decode_windows(msvcrt)
            time.sleep(0.01)
        return None

    @staticmethod
    def _decode_windows(msvcrt) -> str:
        char = msvcrt.getwch()
        if char in ("\x00", "\xe0"):
            return _WIN_KEYS.get(msvcrt.getwch(), "esc")
        if char == "\r":
            return "enter"
        if char == "\t":
            return "tab"
        if char == "\x08":
            return "backspace"
        if char == "\x1b":
            return "esc"
        if char == "\x03":
            return "ctrl-c"
        if char == "\x15":
            return "ctrl-u"
        if char == "\x12":
            return "ctrl-r"
        if char == "\x04":
            return "ctrl-d"
        return char

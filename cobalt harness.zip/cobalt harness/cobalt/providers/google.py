"""Google AI Studio (Gemini API) backend with free/paid tier detection."""

from __future__ import annotations

import json
from typing import Dict, List, Optional, Set, Tuple

from .base import ModelInfo, Provider, ProviderError, ToolCall, Turn, http_json, token_count

BASE = "https://generativelanguage.googleapis.com/v1beta"

# ---------------------------------------------------------------------------
# Tier table for Google AI Studio, as configured by the user.
# Anything not matched here is reported as "unknown" instead of guessed.
# ---------------------------------------------------------------------------
FREE_PATTERNS = (
    "gemini-3.8-flash-tts",
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-2.5-pro",
    "gemini-2.5-flash-lite",
    "gemini-2.5-flash",
    "gemma-4",
)

PAID_PATTERNS = (
    "gemini-4-argon",
    "gemini-3.1-pro-preview",
)

# Listed on both the free and the paid tier, so we keep it usable either way.
BOTH_TIERS = {"gemini-2.5-pro"}

# Used when the API is unreachable so the picker is never empty.
STATIC_MODELS = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3.8-flash-tts",
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemma-4",
    "gemini-4-argon",
    "gemini-3.1-pro-preview",
]

_SPECIAL_WORDS = {
    "tts": "TTS",
    "pro": "Pro",
    "flash": "Flash",
    "lite": "Lite",
    "preview": "Preview",
    "gemma": "Gemma",
    "gemini": "Gemini",
    "argon": "Argon",
    "ultra": "Ultra",
}


def normalize(model_id: str) -> str:
    """Model ids arrive as "models/gemini-2.5-flash" or bare; lowercase them."""
    return model_id.strip().split("/")[-1].lower()


def pretty(model_id: str) -> str:
    name = normalize(model_id)
    words = []
    for part in name.split("-"):
        if part in _SPECIAL_WORDS:
            words.append(_SPECIAL_WORDS[part])
        elif part.isdigit():
            words.append(part)
        elif part.isalpha():
            words.append(part.capitalize())
        else:
            words.append(part.upper())
    return " ".join(words)


def classify(model_id: str) -> Tuple[str, str]:
    """Return (tier, note) for a Google model id."""
    name = normalize(model_id)
    if name in BOTH_TIERS:
        return "free", "free tier and paid tier"
    for pattern in PAID_PATTERNS:
        if name == pattern or name.startswith(pattern):
            return "paid", "paid tier only"
    for pattern in FREE_PATTERNS:
        if name == pattern or name.startswith(pattern):
            return "free", ""
    if name.startswith("gemma"):
        return "free", ""
    return "unknown", "not in the known tier table"


def static_models() -> List[ModelInfo]:
    models = []
    for model_id in STATIC_MODELS:
        tier, note = classify(model_id)
        models.append(ModelInfo(model_id, pretty(model_id), "google", tier, note))
    return sorted(models, key=_sort_key)


def _sort_key(model: ModelInfo) -> tuple:
    rank = {"free": 0, "paid": 1, "unknown": 2}.get(model.tier, 3)
    return (rank, model.name.lower())


def _upper_types(schema):
    """Gemini wants OpenAPI type names in upper case."""
    if isinstance(schema, dict):
        out = {}
        for key, value in schema.items():
            if key == "type" and isinstance(value, str):
                out[key] = value.upper()
            else:
                out[key] = _upper_types(value)
        return out
    if isinstance(schema, list):
        return [_upper_types(item) for item in schema]
    return schema


def _assistant_parts(message: dict) -> list:
    """Replay the model's own parts verbatim so thought signatures survive.

    Gemini 3 rejects a functionCall that comes back without its
    ``thoughtSignature``, so the raw parts from the response are reused
    instead of being rebuilt from text and tool calls.
    """
    raw = message.get("raw_parts")
    if raw:
        return raw
    parts: list = []
    if message.get("text"):
        parts.append({"text": message["text"]})
    for call in message.get("tool_calls") or []:
        part = {"functionCall": {"name": call.name, "args": call.arguments}}
        part.update(call.raw or {})
        parts.append(part)
    return parts


def _contents(messages: list) -> list:
    contents: list = []
    for message in messages:
        role = message.get("role")
        if role == "user":
            contents.append({"role": "user", "parts": [{"text": message.get("text", "")}]})
        elif role == "assistant":
            parts = _assistant_parts(message)
            if parts:
                contents.append({"role": "model", "parts": parts})
        elif role == "tool":
            contents.append(
                {
                    "role": "user",
                    "parts": [
                        {
                            "functionResponse": {
                                "name": message.get("name", "tool"),
                                "response": {"result": message.get("text", "")},
                            }
                        }
                    ],
                }
            )
    return contents


def _contents_flat(messages: list) -> list:
    """Signature-free history: tool traffic as plain text.

    Used as a one-shot retry when a model insists on thought signatures that
    older turns do not carry (for example a conversation started on a
    different model).
    """
    contents: list = []
    for message in messages:
        role = message.get("role")
        if role == "user":
            contents.append({"role": "user", "parts": [{"text": message.get("text", "")}]})
        elif role == "assistant":
            pieces = []
            if message.get("text"):
                pieces.append(message["text"])
            for call in message.get("tool_calls") or []:
                pieces.append(
                    "[called %s with %s]"
                    % (call.name, json.dumps(call.arguments or {}, ensure_ascii=False))
                )
            if pieces:
                contents.append({"role": "model", "parts": [{"text": "\n".join(pieces)}]})
        elif role == "tool":
            contents.append(
                {
                    "role": "user",
                    "parts": [
                        {"text": "[result of %s]\n%s" % (message.get("name", "tool"), message.get("text", ""))}
                    ],
                }
            )
    return contents


def _needs_signature_retry(text: str) -> bool:
    lowered = (text or "").lower()
    return "thought_signature" in lowered or "thought signature" in lowered


class GoogleProvider(Provider):
    name = "google"
    label = "Google AI Studio"

    def __init__(self, api_key: str, timeout: float = 180.0) -> None:
        if not api_key:
            raise ProviderError("no Google AI Studio API key configured")
        self.api_key = api_key
        self.timeout = timeout
        self._available: Optional[Set[str]] = None

    # -- model discovery --------------------------------------------------
    def _headers(self) -> Dict[str, str]:
        return {"x-goog-api-key": self.api_key}

    def list_models(self) -> List[ModelInfo]:
        data = http_json(BASE + "/models?pageSize=200", headers=self._headers(), timeout=30)
        raw_models = data.get("models") or []
        found: List[ModelInfo] = []
        available: Set[str] = set()
        for entry in raw_models:
            if not isinstance(entry, dict):
                continue
            model_id = normalize(str(entry.get("name", "")))
            if not model_id:
                continue
            methods = entry.get("supportedGenerationMethods") or []
            if methods and "generateContent" not in methods:
                continue
            # Embedding and AQA-only models cannot drive the agent.
            if "embedding" in model_id or "aqa" in model_id:
                continue
            available.add(model_id)
            tier, note = classify(model_id)
            found.append(ModelInfo(model_id, pretty(model_id), "google", tier, note))
        self._available = available
        if not found:
            return static_models()
        return sorted(found, key=_sort_key)

    def tier_hint(self, model_id: str) -> str:
        """Cross-check the static table against what this key can actually use."""
        if self._available is None:
            return ""
        if normalize(model_id) in self._available:
            return ""
        return "not listed for this key"

    # -- chat -------------------------------------------------------------
    def chat(self, model: str, system: str, messages: list, tools: list) -> Turn:
        if not model:
            raise ProviderError("no Google model selected")
        payload = {
            "contents": _contents(messages),
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 8192},
        }
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        if tools:
            declarations = [
                {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": _upper_types(tool.get("parameters") or {"type": "object", "properties": {}}),
                }
                for tool in tools
            ]
            payload["tools"] = [{"functionDeclarations": declarations}]

        url = BASE + "/models/" + normalize(model) + ":generateContent"
        try:
            data = http_json(url, payload, headers=self._headers(), timeout=self.timeout)
        except ProviderError as exc:
            if not _needs_signature_retry(str(exc)):
                raise
            # Old turns without signatures: retry once with plain text history.
            payload["contents"] = _contents_flat(messages)
            data = http_json(url, payload, headers=self._headers(), timeout=self.timeout)

        candidates = data.get("candidates") or []
        if not candidates:
            blocked = (data.get("promptFeedback") or {}).get("blockReason")
            raise ProviderError("no response from model" + (" (blocked: %s)" % blocked if blocked else ""))
        candidate = candidates[0]
        parts = ((candidate.get("content") or {}).get("parts")) or []
        text_chunks: List[str] = []
        calls: List[ToolCall] = []
        raw_parts: List[dict] = []
        for index, part in enumerate(parts):
            if not isinstance(part, dict):
                continue
            raw_parts.append(part)
            if isinstance(part.get("text"), str) and not part.get("thought"):
                text_chunks.append(part["text"])
            call = part.get("functionCall")
            if isinstance(call, dict) and call.get("name"):
                signature = part.get("thoughtSignature") or part.get("thought_signature")
                raw = {"thoughtSignature": signature} if signature else {}
                args = call.get("args")
                calls.append(
                    ToolCall(
                        id="gc_%d_%d" % (len(raw_parts), index),
                        name=str(call["name"]),
                        arguments=args if isinstance(args, dict) else {},
                        raw=raw,
                    )
                )
        if not text_chunks and not calls:
            reason = candidate.get("finishReason")
            if reason and reason not in ("STOP", "MAX_TOKENS"):
                raise ProviderError("model stopped with reason %s" % reason)
        meta = data.get("usageMetadata") or {}
        usage = {
            "input": token_count(meta.get("promptTokenCount")),
            "output": token_count(meta.get("candidatesTokenCount")),
        }
        return Turn(text="".join(text_chunks).strip(), tool_calls=calls, raw_parts=raw_parts, usage=usage)

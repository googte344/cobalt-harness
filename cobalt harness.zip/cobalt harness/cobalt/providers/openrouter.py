"""OpenRouter backend (OpenAI-compatible chat completions)."""

from __future__ import annotations

import json
from typing import Dict, List

from .base import ModelInfo, Provider, ProviderError, ToolCall, Turn, http_json, token_count

BASE = "https://openrouter.ai/api/v1"


def _tier(pricing: dict) -> str:
    try:
        prompt = float(str((pricing or {}).get("prompt", "0")))
        completion = float(str((pricing or {}).get("completion", "0")))
    except (TypeError, ValueError):
        return "unknown"
    return "free" if prompt == 0 and completion == 0 else "paid"


def _sort_key(model: ModelInfo) -> tuple:
    rank = {"free": 0, "paid": 1, "unknown": 2}.get(model.tier, 3)
    return (rank, model.name.lower())


class OpenRouterProvider(Provider):
    name = "openrouter"
    label = "OpenRouter"

    def __init__(self, api_key: str, timeout: float = 180.0, referer: str = "") -> None:
        if not api_key:
            raise ProviderError("no OpenRouter API key configured")
        self.api_key = api_key
        self.timeout = timeout
        self.referer = referer

    def _headers(self) -> Dict[str, str]:
        headers = {"Authorization": "Bearer " + self.api_key}
        if self.referer:
            headers["HTTP-Referer"] = self.referer
            headers["X-Title"] = "Cobalt"
        return headers

    # -- model discovery --------------------------------------------------
    def list_models(self) -> List[ModelInfo]:
        data = http_json(BASE + "/models", headers=self._headers(), timeout=30)
        entries = data.get("data") or []
        models: List[ModelInfo] = []
        for entry in entries:
            if not isinstance(entry, dict) or not entry.get("id"):
                continue
            model_id = str(entry["id"])
            tier = _tier(entry.get("pricing") or {})
            note = "zero price on OpenRouter" if tier == "free" else ""
            models.append(
                ModelInfo(
                    id=model_id,
                    name=str(entry.get("name") or model_id),
                    provider="openrouter",
                    tier=tier,
                    note=note,
                )
            )
        return sorted(models, key=_sort_key)

    def check_key(self) -> str:
        """Validate the key itself: /models is public, so it proves nothing."""
        data = http_json(BASE + "/key", headers=self._headers(), timeout=30)
        info = data.get("data") or {}
        label = str(info.get("label") or "key")
        limit = info.get("limit")
        if limit is None:
            return "%s, no spend limit" % label
        return "%s, limit %s" % (label, limit)

    # -- chat -------------------------------------------------------------
    def _messages(self, system: str, messages: list) -> list:
        out = []
        if system:
            out.append({"role": "system", "content": system})
        for message in messages:
            role = message.get("role")
            if role == "user":
                out.append({"role": "user", "content": message.get("text", "")})
            elif role == "assistant":
                entry = {"role": "assistant", "content": message.get("text") or None}
                calls = message.get("tool_calls") or []
                if calls:
                    entry["content"] = message.get("text") or None
                    entry["tool_calls"] = [
                        {
                            "id": call.id,
                            "type": "function",
                            "function": {
                                "name": call.name,
                                "arguments": json.dumps(call.arguments or {}),
                            },
                        }
                        for call in calls
                    ]
                out.append(entry)
            elif role == "tool":
                out.append(
                    {
                        "role": "tool",
                        "tool_call_id": message.get("tool_call_id", ""),
                        "content": message.get("text", ""),
                    }
                )
        return out

    def chat(self, model: str, system: str, messages: list, tools: list) -> Turn:
        if not model:
            raise ProviderError("no OpenRouter model selected")
        payload = {
            "model": model,
            "messages": self._messages(system, messages),
            "temperature": 0.2,
            "max_tokens": 8192,
        }
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool["description"],
                        "parameters": tool.get("parameters") or {"type": "object", "properties": {}},
                    },
                }
                for tool in tools
            ]
            payload["tool_choice"] = "auto"

        data = http_json(BASE + "/chat/completions", payload, headers=self._headers(), timeout=self.timeout)
        choices = data.get("choices") or []
        if not choices:
            message = data.get("error") or "empty response from OpenRouter"
            raise ProviderError(str(message)[:300])
        message = choices[0].get("message") or {}
        text = (message.get("content") or "").strip()
        calls: List[ToolCall] = []
        for index, call in enumerate(message.get("tool_calls") or []):
            function = (call or {}).get("function") or {}
            name = function.get("name")
            if not name:
                continue
            arguments = function.get("arguments")
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments or "{}")
                except json.JSONDecodeError:
                    raise ProviderError("model sent malformed tool arguments for %s" % name) from None
            calls.append(
                ToolCall(
                    id=str(call.get("id") or "tc_%d" % index),
                    name=str(name),
                    arguments=arguments if isinstance(arguments, dict) else {},
                )
            )
        usage_data = data.get("usage") or {}
        usage = {
            "input": token_count(usage_data.get("prompt_tokens")),
            "output": token_count(usage_data.get("completion_tokens")),
        }
        return Turn(text=text, tool_calls=calls, usage=usage)

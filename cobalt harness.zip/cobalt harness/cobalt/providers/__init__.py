"""Provider factory."""

from __future__ import annotations

from typing import List

from ..config import PROVIDER_LABELS, Config
from .base import ModelInfo, Provider, ProviderError, ToolCall, Turn
from .google import GoogleProvider
from .llamacpp import LlamaCppProvider
from .ollama import OllamaProvider
from .openrouter import OpenRouterProvider

__all__ = [
    "ModelInfo",
    "Provider",
    "ProviderError",
    "ToolCall",
    "Turn",
    "GoogleProvider",
    "LlamaCppProvider",
    "OllamaProvider",
    "OpenRouterProvider",
    "build_provider",
    "provider_label",
    "load_models",
]


def build_provider(cfg: Config, name: str | None = None) -> Provider:
    name = name or cfg.provider
    if name == "ollama":
        return OllamaProvider(cfg.ollama_base())
    if name == "llamacpp":
        return LlamaCppProvider(cfg.llamacpp_base(), api_key=cfg.key("llamacpp") or "")
    key = cfg.key(name)
    if name == "google":
        return GoogleProvider(key or "")
    if name == "openrouter":
        return OpenRouterProvider(key or "")
    raise ProviderError("unknown provider: %s" % name)


def provider_label(name: str) -> str:
    return PROVIDER_LABELS.get(name, name)


def load_models(cfg: Config, name: str | None = None) -> List[ModelInfo]:
    """Fetch models for one provider, falling back to the static table."""
    provider = build_provider(cfg, name)
    return provider.list_models()

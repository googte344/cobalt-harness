"""llama.cpp backend: a local ``llama-server`` over its OpenAI-compatible API.

``llama-server -m model.gguf`` loads one model and serves it on port 8080 by
default. The picker is built from ``/v1/models``, so it only ever offers the
model that server actually has loaded.

Local models are just as loose with tool syntax as the ones Ollama serves, so
the normalisation and text-encoded tool call recovery from the Ollama backend
are reused here.
"""

from __future__ import annotations

import json
import re
from typing import List, Optional

from .base import ModelInfo, Provider, ProviderError, ToolCall, Turn, http_json, token_count
from .ollama import (
    canonical_tool_name,
    extract_text_tool_calls,
    normalize_arguments,
    normalize_base,
)

DEFAULT_BASE = "http://localhost:8080"
DEFAULT_TIMEOUT = 300.0


def display_name(model_id: str) -> str:
    """A GGUF path is a poor sidebar label, so keep the file stem."""
    name = re.split(r"[\\/]", str(model_id or "").strip())[-1]
    if name.lower().endswith(".gguf"):
        name = name[:-5]
    return name or str(model_id)


def _params(value) -> str:
    try:
        count = float(value)
    except (TypeError, ValueError):
        return ""
    if count >= 1e9:
        return "%.1fB parameters" % (count / 1e9)
    if count >= 1e6:
        return "%.1fM parameters" % (count / 1e6)
    return ""


def _size(value) -> str:
    try:
        size = float(value)
    except (TypeError, ValueError):
        return ""
    return "%.1f GB" % (size / 1e9) if size > 0 else ""


def model_note(entry: dict) -> str:
    """Describe the loaded model with whatever metadata the server reports."""
    meta = entry.get("meta")
    meta = meta if isinstance(meta, dict) else {}
    details = [part for part in (_params(meta.get("n_params")), _size(meta.get("size"))) if part]
    note = "loaded in llama.cpp, runs locally"
    return note + (", " + ", ".join(details) if details else "")


def rejects_tools(message: str) -> bool:
    """Older llama.cpp builds reject the tools parameter instead of ignoring it."""
    text = (message or "").lower()
    return "tool" in text and any(word in text for word in ("not support", "unsupported", "no support"))


class LlamaCppProvider(Provider):
    name = "llamacpp"
    label = "llama.cpp (local)"

    def __init__(self, base_url: str = "", timeout: float = DEFAULT_TIMEOUT, api_key: str = "") -> None:
        self.base = normalize_base(base_url, DEFAULT_BASE)
        self.timeout = timeout
        self.api_key = api_key

    def _headers(self) -> dict:
        # Only needed when llama-server was started with --api-key.
        return {"Authorization": "Bearer " + self.api_key} if self.api_key else {}

    def _request(self, path: str, payload: Optional[dict] = None, timeout: float = 0.0) -> dict:
        try:
            return http_json(
                self.base + path,
                payload,
                headers=self._headers(),
                timeout=timeout or self.timeout,
            )
        except ProviderError as exc:
            text = str(exc).lower()
            if "network error" in text or "connection" in text or "timed out" in text:
                raise ProviderError(
                    "could not reach llama.cpp at %s (%s). Is `llama-server` running? "
                    "It listens on port 8080 by default." % (self.base, exc)
                ) from None
            raise

    # -- model discovery --------------------------------------------------
    def list_models(self) -> List[ModelInfo]:
        data = self._request("/v1/models", timeout=10)
        models: List[ModelInfo] = []
        for entry in data.get("data") or []:
            if not isinstance(entry, dict):
                continue
            model_id = str(entry.get("id") or "").strip()
            if not model_id:
                continue
            models.append(
                ModelInfo(
                    id=model_id,
                    name=display_name(model_id),
                    provider="llamacpp",
                    tier="free",
                    note=model_note(entry),
                )
            )
        if not models:
            raise ProviderError(
                "llama.cpp is running at %s but has no model loaded. Start it with: "
                "llama-server -m model.gguf" % self.base
            )
        return sorted(models, key=lambda model: model.id.lower())

    # -- chat -------------------------------------------------------------
    def _messages(self, system: str, messages: list) -> list:
        out: list = []
        if system:
            out.append({"role": "system", "content": system})
        for message in messages:
            role = message.get("role")
            if role == "user":
                out.append({"role": "user", "content": message.get("text", "")})
            elif role == "assistant":
                entry = {"role": "assistant", "content": message.get("text") or ""}
                calls = message.get("tool_calls") or []
                if calls:
                    entry["tool_calls"] = [
                        {
                            "id": call.id or "call_%d" % index,
                            "type": "function",
                            "function": {
                                "name": call.name,
                                "arguments": json.dumps(call.arguments or {}),
                            },
                        }
                        for index, call in enumerate(calls)
                    ]
                out.append(entry)
            elif role == "tool":
                out.append(
                    {
                        "role": "tool",
                        "tool_call_id": message.get("tool_call_id", ""),
                        "content": message.get("text", ""),
                    }
                )
        return out

    def _payload(self, model: str, system: str, messages: list, tools: list, include_tools: bool = True) -> dict:
        payload = {
            "model": model,
            "messages": self._messages(system, messages),
            "temperature": 0.2,
            "max_tokens": 8192,
            "stream": False,
        }
        if tools and include_tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool["description"],
                        "parameters": tool.get("parameters") or {"type": "object", "properties": {}},
                    },
                }
                for tool in tools
            ]
        return payload

    def chat(self, model: str, system: str, messages: list, tools: list) -> Turn:
        if not model:
            raise ProviderError("no llama.cpp model selected")
        try:
            data = self._request("/v1/chat/completions", self._payload(model, system, messages, tools))
        except ProviderError as exc:
            if not tools or not rejects_tools(str(exc)):
                raise
            # A template without tool support rejects the parameter outright; send
            # plain chat instead and recover any call the model prints as JSON.
            data = self._request(
                "/v1/chat/completions",
                self._payload(model, system, messages, tools, include_tools=False),
            )

        if data.get("error"):
            raise ProviderError(str(data["error"])[:300])
        choices = data.get("choices") or []
        if not choices or not isinstance(choices[0], dict):
            raise ProviderError("llama.cpp returned no choices for %s; is a model loaded?" % model)
        message = choices[0].get("message") or {}
        content = message.get("content")
        if isinstance(content, list):
            text = "".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
        else:
            text = str(content or "")
        text = text.strip()

        allowed = {tool["name"] for tool in tools}
        calls: List[ToolCall] = []
        for index, call in enumerate(message.get("tool_calls") or []):
            if not isinstance(call, dict):
                continue
            function = call.get("function") or {}
            name = function.get("name")
            if not name:
                continue
            arguments = function.get("arguments")
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments or "{}")
                except json.JSONDecodeError:
                    raise ProviderError("model sent malformed tool arguments for %s" % name) from None
            canonical = canonical_tool_name(str(name), allowed) or str(name)
            calls.append(
                ToolCall(
                    id=str(call.get("id") or "lc_%d" % index),
                    name=canonical,
                    arguments=normalize_arguments(canonical, arguments),
                )
            )
        if not calls and tools and text:
            text, recovered = extract_text_tool_calls(text, allowed)
            for name, arguments in recovered:
                calls.append(ToolCall(id="lc_%d" % len(calls), name=name, arguments=arguments))
        if not text and not calls:
            raise ProviderError("%s stopped without an answer" % model)
        usage = data.get("usage") or {}
        return Turn(
            text=text,
            tool_calls=calls,
            usage={
                "input": token_count(usage.get("prompt_tokens")),
                "output": token_count(usage.get("completion_tokens")),
            },
        )

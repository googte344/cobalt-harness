"""Ollama backend: local models served by the daemon on this machine.

The picker is built from ``/api/tags``, which lists exactly the models that
have been pulled onto this machine, so nothing that cannot run locally is ever
offered.
"""

from __future__ import annotations

import json
import re
from typing import List

from .base import ModelInfo, Provider, ProviderError, ToolCall, Turn, http_json, token_count

DEFAULT_BASE = "http://localhost:11434"
DEFAULT_TIMEOUT = 300.0


def normalize_base(url: str, default: str = DEFAULT_BASE) -> str:
    """Accept "localhost:11434" as well as a full URL."""
    url = (url or default).strip().rstrip("/")
    if "://" not in url:
        url = "http://" + url
    return url


def display_name(model_id: str) -> str:
    """Drop the implicit ":latest" tag so the sidebar stays readable."""
    return model_id[:-7] if model_id.endswith(":latest") else model_id


def human_size(size) -> str:
    try:
        value = float(size)
    except (TypeError, ValueError):
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return ("%d %s" % (value, unit)) if unit == "B" else ("%.1f %s" % (value, unit))
        value /= 1024
    return ""


# Local models rarely reproduce the declared tool names exactly, so the spellings
# they actually emit are mapped onto the canonical ones.
_ALIASES = {
    "write_file": (
        "writefile", "write", "createfile", "create", "newfile", "savefile",
        "filewrite", "writeout", "writecontents", "makefile", "putfile",
    ),
    "read_file": ("readfile", "openfile", "viewfile", "read", "cat", "showfile", "getfile", "loadfile"),
    "edit_file": (
        "editfile", "modifyfile", "replaceinfile", "strreplace", "updatefile",
        "patchfile", "edit", "replace", "applyedit",
    ),
    "list_files": (
        "listfiles", "listfile", "ls", "dir", "listdir", "listdirectory", "lsdir",
        "listfolder", "tree", "list",
    ),
    "search_files": ("searchfiles", "search", "grep", "find", "ripgrep", "findinfiles", "searchinfile"),
    "run_command": (
        "runcommand", "run", "shell", "bash", "exec", "execute", "executecommand",
        "terminal", "cmd", "runterminal",
    ),
}

_PATH_KEYS = ("path", "file", "filename", "file_name", "filepath", "file_path", "fname", "target_file")
_CONTENT_KEYS = ("content", "contents", "text", "code", "body", "data", "file_content", "source", "code_content")
_OLD_KEYS = ("old_string", "old", "old_text", "old_str", "search", "original", "find", "match")
_NEW_KEYS = ("new_string", "new", "new_text", "new_str", "replace", "replacement", "updated")
_COMMAND_KEYS = ("command", "cmd", "script", "shell_command", "command_line")
_PATTERN_KEYS = ("pattern", "regex", "query", "search_term", "term", "needle")
_FILE_TOOLS = ("write_file", "read_file", "edit_file", "list_files", "search_files")


def _key(name) -> str:
    """Compare names ignoring case, spaces, underscores and hyphens."""
    return re.sub(r"[^a-z0-9]", "", str(name or "").lower())


def _alias_lookup() -> dict:
    table = {}
    for canonical, spellings in _ALIASES.items():
        table[_key(canonical)] = canonical
        for spelling in spellings:
            table.setdefault(_key(spelling), canonical)
    return table


_ALIASES_BY_KEY = _alias_lookup()


def canonical_tool_name(name, allowed):
    """Return the declared tool this name means, or None if it is unknown."""
    if not isinstance(name, str) or not allowed:
        return None
    if name in allowed:
        return name
    canonical = _ALIASES_BY_KEY.get(_key(name))
    return canonical if canonical in allowed else None


def clean_path(value):
    """Trim the decoration models wrap filenames in: quotes, backticks, "file:"."""
    if not isinstance(value, str):
        return value
    text = value.strip()
    lowered = text.lower()
    for prefix in ("file path:", "filename:", "file:", "path:"):
        if lowered.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    text = text.strip().strip("`\"'").strip()
    while text.startswith("./"):
        text = text[2:]
    return text.strip()


_FENCE_ONLY = re.compile(r"^```[a-zA-Z0-9_+.-]*[ \t]*\r?\n(?P<body>.*?)\r?\n?```[ \t]*$", re.S)


def strip_code_fence(text):
    """Drop one markdown fence wrapping the whole value."""
    if not isinstance(text, str):
        return text
    match = _FENCE_ONLY.match(text.strip())
    return match.group("body") if match else text


def _pick(arguments: dict, names):
    """Find the key the model used for one logical argument."""
    wanted = {_key(name) for name in names}
    for key in arguments:
        if key in names and arguments[key] not in (None, ""):
            return key
    for key in arguments:
        if _key(key) in wanted and arguments[key] not in (None, ""):
            return key
    return None


def normalize_arguments(name: str, arguments) -> dict:
    """Rewrite the argument spellings local models invent into the tool schema."""
    if not isinstance(arguments, dict):
        return {}
    args = dict(arguments)
    if name in _FILE_TOOLS:
        key = _pick(args, _PATH_KEYS)
        if key is None and name in ("write_file", "read_file", "edit_file"):
            key = _pick(args, ("name",))
        if key is not None and key != "path":
            args["path"] = args.pop(key)
        if "path" in args:
            args["path"] = clean_path(args["path"])
    if name == "write_file":
        key = _pick(args, _CONTENT_KEYS)
        if key is not None and key != "content":
            args["content"] = args.pop(key)
        if isinstance(args.get("content"), str):
            args["content"] = strip_code_fence(args["content"])
    if name == "edit_file":
        for canonical, spellings in (("old_string", _OLD_KEYS), ("new_string", _NEW_KEYS)):
            key = _pick(args, spellings)
            if key is not None and key != canonical:
                args[canonical] = args.pop(key)
            if isinstance(args.get(canonical), str):
                args[canonical] = strip_code_fence(args[canonical])
        if isinstance(args.get("replace_all"), str):
            args["replace_all"] = args["replace_all"].strip().lower() in ("true", "yes", "1", "all")
    if name == "run_command":
        key = _pick(args, _COMMAND_KEYS)
        if key is not None and key != "command":
            args["command"] = args.pop(key)
    if name == "search_files":
        key = _pick(args, _PATTERN_KEYS)
        if key is not None and key != "pattern":
            args["pattern"] = args.pop(key)
    return args


def _call_from_json(value, allowed):
    """Turn a decoded JSON value into tool calls, if it looks like one."""
    if isinstance(value, list):
        found = []
        for item in value:
            found.extend(_call_from_json(item, allowed))
        return found
    if not isinstance(value, dict):
        return []
    if "tool_calls" in value:
        return _call_from_json(value["tool_calls"], allowed)
    function = value.get("function")
    if isinstance(function, str):
        name = function
        arguments = value.get("arguments")
        if arguments is None:
            arguments = value.get("parameters")
    elif isinstance(function, dict):
        name = function.get("name")
        arguments = function.get("arguments")
        if arguments is None:
            arguments = function.get("parameters")
    else:
        name = value.get("name") or value.get("tool") or value.get("tool_name") or value.get("action")
        arguments = value.get("arguments")
        if arguments is None:
            arguments = value.get("parameters")
        if arguments is None:
            arguments = value.get("args")
        if arguments is None:
            arguments = value.get("input")
    canonical = canonical_tool_name(name, allowed)
    if canonical is None:
        return []
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments or "{}")
        except json.JSONDecodeError:
            return []
    if not isinstance(arguments, dict):
        arguments = {}
    return [(canonical, normalize_arguments(canonical, arguments))]


def _json_objects(text: str):
    """Yield every JSON object embedded in plain text, with its span."""
    decoder = json.JSONDecoder()
    index = text.find("{")
    while index != -1:
        try:
            value, end = decoder.raw_decode(text, index)
        except json.JSONDecodeError:
            index = text.find("{", index + 1)
            continue
        yield value, index, end
        index = text.find("{", end)


def _inside_fence(text: str, start: int, end: int) -> bool:
    head = text[:start].rstrip()
    tail = text[end:].lstrip()
    return bool(re.search(r"```[a-zA-Z]*$", head)) and tail.startswith("```")


def _on_own_lines(text: str, start: int, end: int) -> bool:
    """True when the JSON sits on its own line(s), not inside a sentence."""
    before = text[:start].rsplit("\n", 1)[-1].strip()
    after = text[end:].split("\n", 1)[0].strip()
    return not before and (not after or after.startswith("```"))


def _fence_bounds(text: str, start: int, end: int):
    """Widen a span to swallow the ``` fences that wrap it."""
    opening = re.search(r"```[a-zA-Z]*[ \t]*\r?\n?$", text[:start])
    if opening:
        start = opening.start()
    closing = re.match(r"[ \t]*\r?\n?```", text[end:])
    if closing:
        end += closing.end()
    return start, end


def extract_text_tool_calls(text: str, allowed):
    """Recover a tool call the model printed as JSON instead of using `tools`.

    Local models frequently answer with a fenced block such as
    ``{"name": "write_file", "arguments": {...}}`` even when the request
    declared tools. Ignoring it lets the model claim it wrote a file that does
    not exist, so the call is rebuilt and actually run. Only JSON that names
    one of the offered tools is taken; prose that merely mentions JSON is left
    untouched.
    """
    if not allowed:
        return text, []
    calls = []
    spans = []
    for value, start, end in _json_objects(text):
        found = _call_from_json(value, allowed)
        if not found:
            continue
        bare = not text[:start].strip() and not text[end:].strip()
        if not (bare or _inside_fence(text, start, end) or _on_own_lines(text, start, end)):
            continue
        calls.extend(found)
        spans.append(_fence_bounds(text, start, end))
    if not calls:
        return text, []
    cleaned = text
    for start, end in sorted(spans, reverse=True):
        cleaned = cleaned[:start] + cleaned[end:]
    return re.sub(r"\n{3,}", "\n\n", cleaned).strip(), calls


class OllamaProvider(Provider):
    name = "ollama"
    label = "Ollama (local)"

    def __init__(self, base_url: str = "", timeout: float = DEFAULT_TIMEOUT) -> None:
        self.base = normalize_base(base_url)
        self.timeout = timeout

    def _request(self, path: str, payload: dict = None, timeout: float = 0) -> dict:
        try:
            return http_json(self.base + path, payload, timeout=timeout or self.timeout)
        except ProviderError as exc:
            text = str(exc).lower()
            if "network error" in text or "connection" in text or "timed out" in text:
                raise ProviderError(
                    "could not reach Ollama at %s (%s). Is `ollama serve` running?" % (self.base, exc)
                ) from None
            raise

    # -- model discovery --------------------------------------------------
    def list_models(self) -> List[ModelInfo]:
        """Only installed models: /api/tags is the local pull list."""
        data = self._request("/api/tags", timeout=10)
        models: List[ModelInfo] = []
        for entry in data.get("models") or []:
            if not isinstance(entry, dict):
                continue
            model_id = str(entry.get("model") or entry.get("name") or "").strip()
            if not model_id:
                continue
            size = human_size(entry.get("size"))
            note = "installed and runs locally" + (", %s on disk" % size if size else "")
            models.append(
                ModelInfo(
                    id=model_id,
                    name=display_name(model_id),
                    provider="ollama",
                    tier="free",
                    note=note,
                )
            )
        if not models:
            raise ProviderError(
                "Ollama is running at %s but has no models installed. Pull one first, for example: "
                "ollama pull llama3.2" % self.base
            )
        return sorted(models, key=lambda model: model.id.lower())

    # -- chat -------------------------------------------------------------
    def _messages(self, system: str, messages: list) -> list:
        out: list = []
        if system:
            out.append({"role": "system", "content": system})
        for message in messages:
            role = message.get("role")
            if role == "user":
                out.append({"role": "user", "content": message.get("text", "")})
            elif role == "assistant":
                entry = {"role": "assistant", "content": message.get("text") or ""}
                calls = message.get("tool_calls") or []
                if calls:
                    entry["tool_calls"] = [
                        {"function": {"name": call.name, "arguments": call.arguments or {}}}
                        for call in calls
                    ]
                out.append(entry)
            elif role == "tool":
                entry = {"role": "tool", "content": message.get("text", "")}
                if message.get("name"):
                    entry["tool_name"] = message["name"]
                out.append(entry)
        return out

    def chat(self, model: str, system: str, messages: list, tools: list) -> Turn:
        if not model:
            raise ProviderError("no Ollama model selected")
        payload = {
            "model": model,
            "messages": self._messages(system, messages),
            "stream": False,
            "options": {"temperature": 0.2, "num_predict": 8192},
        }
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool["description"],
                        "parameters": tool.get("parameters") or {"type": "object", "properties": {}},
                    },
                }
                for tool in tools
            ]

        data = self._request("/api/chat", payload)
        if data.get("error"):
            raise ProviderError(str(data["error"])[:300])
        message = data.get("message") or {}
        text = (message.get("content") or "").strip()
        allowed = {tool["name"] for tool in tools}
        calls: List[ToolCall] = []
        for index, call in enumerate(message.get("tool_calls") or []):
            function = (call or {}).get("function") or {}
            name = function.get("name")
            if not name:
                continue
            arguments = function.get("arguments")
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments or "{}")
                except json.JSONDecodeError:
                    raise ProviderError("model sent malformed tool arguments for %s" % name) from None
            canonical = canonical_tool_name(str(name), allowed) or str(name)
            calls.append(
                ToolCall(
                    id="ol_%d" % index,
                    name=canonical,
                    arguments=normalize_arguments(canonical, arguments),
                )
            )
        if not calls and tools and text:
            text, recovered = extract_text_tool_calls(text, allowed)
            for name, arguments in recovered:
                calls.append(ToolCall(id="ol_%d" % len(calls), name=name, arguments=arguments))
        if not text and not calls:
            raise ProviderError("%s stopped without an answer" % model)
        usage = {
            "input": token_count(data.get("prompt_eval_count")),
            "output": token_count(data.get("eval_count")),
        }
        return Turn(text=text, tool_calls=calls, usage=usage)

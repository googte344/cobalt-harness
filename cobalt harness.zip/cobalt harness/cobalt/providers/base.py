"""Shared provider types: model metadata, tool calls, HTTP helper."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Dict, List, Optional


class ProviderError(Exception):
    """Anything the user can act on: bad key, rate limit, no network."""


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict = field(default_factory=dict)
    # Provider-specific data that must be echoed back (Gemini thought signatures).
    raw: dict = field(default_factory=dict)


@dataclass
class Turn:
    text: str = ""
    tool_calls: List[ToolCall] = field(default_factory=list)
    # Verbatim response parts, replayed so signatures are never dropped.
    raw_parts: list = field(default_factory=list)
    # Token counts for this turn: {"input": int, "output": int}.
    usage: dict = field(default_factory=dict)


def token_count(value) -> int:
    """Provider token counts arrive as ints or numeric strings."""
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


@dataclass(frozen=True)
class ModelInfo:
    id: str
    name: str
    provider: str
    tier: str = "unknown"  # "free" | "paid" | "unknown"
    note: str = ""

    @property
    def badge(self) -> str:
        return {"free": "FREE", "paid": "PAID"}.get(self.tier, "?")


def _error_detail(raw: str) -> str:
    """Pull the useful sentence out of a provider error body."""
    raw = raw.strip()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return raw[:300]
    if isinstance(data, dict):
        err = data.get("error")
        if isinstance(err, dict):
            message = err.get("message") or err.get("status")
            if message:
                return str(message)[:300]
        if isinstance(err, str):
            return err[:300]
        if isinstance(data.get("message"), str):
            return data["message"][:300]
    return raw[:300]


_HINTS = (
    (
        ("401", "api key not valid", "api_key_invalid", "unauthenticated", "invalid api key", "no auth credentials"),
        "the provider rejected this key. Copy it again from the dashboard - partial pastes and stray quotes are the usual cause.",
    ),
    (
        ("403", "permission_denied", "forbidden"),
        "the key is valid but is not allowed to do this. Check the key's permissions or the model's tier.",
    ),
    (
        ("404", "not found", "not_found"),
        "the request reached the provider but this model is not available to your key. Pick another model in the sidebar.",
    ),
    (
        ("429", "quota", "rate limit", "resource_exhausted"),
        "rate limit or quota reached. Free tiers have small per-minute limits - wait a minute or pick a lighter model.",
    ),
    (
        ("getaddrinfo", "nodename nor servname", "connection refused", "ssl", "proxy", "network error"),
        "the request never reached the provider. Check your connection, VPN or proxy.",
    ),
    (
        ("timed out", "timeout"),
        "the provider did not answer in time. Try again or pick a faster model.",
    ),
)


def explain_error(message: str, provider: str = "") -> str:
    """Attach a concrete next step to a provider error string."""
    text = (message or "").lower()
    for needles, hint in _HINTS:
        if any(needle in text for needle in needles):
            return "%s\n  -> %s" % ((message or "unknown error").strip(), hint)
    return (message or "unknown error").strip()


def http_json(
    url: str,
    payload: Optional[dict] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 120.0,
) -> dict:
    """GET (no payload) or POST JSON, returning the decoded response."""
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=body, method="GET" if body is None else "POST")
    request.add_header("Content-Type", "application/json")
    request.add_header("Accept", "application/json")
    request.add_header("User-Agent", "cobalt-agent/0.1")
    for name, value in (headers or {}).items():
        request.add_header(name, value)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        raise ProviderError("HTTP %s: %s" % (exc.code, _error_detail(detail))) from None
    except urllib.error.URLError as exc:
        raise ProviderError("network error: %s" % (exc.reason,)) from None
    except TimeoutError:
        raise ProviderError("request timed out after %ss" % timeout) from None
    except OSError as exc:
        raise ProviderError("connection failed: %s" % (exc,)) from None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise ProviderError("provider returned non-JSON: " + raw[:200]) from None
    if not isinstance(data, dict):
        raise ProviderError("unexpected response shape from provider")
    return data


class Provider:
    """Interface all backends implement."""

    name = "base"
    label = "Provider"

    def list_models(self) -> List[ModelInfo]:  # pragma: no cover - interface
        raise NotImplementedError

    def chat(self, model: str, system: str, messages: list, tools: list) -> Turn:
        raise NotImplementedError

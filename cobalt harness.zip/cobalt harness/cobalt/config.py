"""Config file, API key storage and environment overrides.

Stored at ``~/.cobalt/config.json`` (override the folder with ``COBALT_HOME``).
Keys typed into the app are written there with 0600 permissions on POSIX, but
environment variables always win so you never have to store them at all.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

PROVIDER_LABELS = {
    "google": "Google AI Studio",
    "openrouter": "OpenRouter",
    "ollama": "Ollama (local)",
    "llamacpp": "llama.cpp (local)",
}

# Order used in menus, the model sidebar and --check.
PROVIDER_ORDER = ("google", "openrouter", "ollama", "llamacpp")

# Providers that need no API key because they talk to a local daemon.
KEYLESS_PROVIDERS = ("ollama", "llamacpp")

ENV_KEYS = {
    "google": ("COBALT_GOOGLE_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEY"),
    "openrouter": ("COBALT_OPENROUTER_KEY", "OPENROUTER_API_KEY"),
    # Optional: only needed when llama-server was started with --api-key.
    "llamacpp": ("COBALT_LLAMACPP_KEY",),
}

OLLAMA_URL_ENV = "COBALT_OLLAMA_URL"
DEFAULT_OLLAMA_URL = "http://localhost:11434"
LLAMACPP_URL_ENV = "COBALT_LLAMACPP_URL"
DEFAULT_LLAMACPP_URL = "http://localhost:8080"

# How hard the agent works on a request (/effort). The step budget scales with it.
EFFORT_LEVELS = ("low", "medium", "high", "extra")
DEFAULT_EFFORT = "medium"
EFFORT_STEPS = {"low": 15, "medium": 40, "high": 60, "extra": 90}
EFFORT_GUIDANCE = {
    "low": "Do the minimum that satisfies the request: answer directly or make the smallest working change, with a couple of tool calls at most and no unrequested tests or polish.",
    "medium": "Use normal care: read what you touch, make a complete change, and run the obvious check when the project has one.",
    "high": "Be thorough: inspect the related files, cover edge cases, run the project's tests or build, and fix what fails before reporting.",
    "extra": "Use maximum effort: plan briefly, weigh alternatives, cover edge cases, run and re-run the checks, verify the behaviour yourself, and say what remains unverified.",
}

_EFFORT_ALIASES = {"min": "low", "minimum": "low", "med": "medium", "mid": "medium", "normal": "medium", "max": "extra", "maximum": "extra", "x": "extra"}


def normalize_effort(value) -> Optional[str]:
    """Accept "High" or "max"; return None when the level is unknown."""
    text = str(value or "").strip().lower()
    if text in EFFORT_LEVELS:
        return text
    return _EFFORT_ALIASES.get(text)


def parse_context_window(value) -> Optional[int]:
    """Parse a context window such as 8192, '128k', '1.5m' or 'off'.

    Returns the token count, or None for unlimited. Raises ValueError when the
    text is not a positive number of tokens.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("expected a token count")
    if isinstance(value, (int, float)):
        number = int(value)
    else:
        text = str(value).strip().lower().replace("_", "").replace(",", "")
        for suffix in ("tokens", "token"):
            if text.endswith(suffix):
                text = text[: -len(suffix)].strip()
                break
        if text in ("", "off", "none", "auto", "unlimited", "0"):
            return None
        multiplier = 1
        if text.endswith("k"):
            multiplier, text = 1_000, text[:-1].strip()
        elif text.endswith("m"):
            multiplier, text = 1_000_000, text[:-1].strip()
        try:
            number = int(float(text) * multiplier)
        except ValueError:
            raise ValueError("expected a token count like 8192, 128k or 1m") from None
    if number < 0:
        raise ValueError("the context window must be a positive number of tokens")
    return number or None


def home() -> Path:
    override = os.environ.get("COBALT_HOME")
    return Path(override).expanduser() if override else Path.home() / ".cobalt"


def config_path() -> Path:
    override = os.environ.get("COBALT_CONFIG")
    return Path(override).expanduser() if override else home() / "config.json"


@dataclass
class Config:
    project_dir: Optional[str] = None
    provider: str = "google"
    model: Optional[str] = None
    stored_keys: Dict[str, str] = field(default_factory=dict)
    unicode: Optional[bool] = None
    ollama_url: Optional[str] = None
    llamacpp_url: Optional[str] = None
    effort: str = DEFAULT_EFFORT

    # -- keys -------------------------------------------------------------
    def key(self, provider: str) -> Optional[str]:
        for name in ENV_KEYS.get(provider, ()):
            value = os.environ.get(name)
            if value:
                return value.strip()
        value = self.stored_keys.get(provider)
        return value.strip() if value else None

    def key_source(self, provider: str) -> Optional[str]:
        for name in ENV_KEYS.get(provider, ()):
            if os.environ.get(name):
                return "env:" + name
        return "config" if self.stored_keys.get(provider) else None

    def has_key(self, provider: str) -> bool:
        if provider in KEYLESS_PROVIDERS:
            return True
        return bool(self.key(provider))

    def set_key(self, provider: str, key: str) -> None:
        key = clean_key(key)
        if key:
            self.stored_keys[provider] = key
        else:
            self.stored_keys.pop(provider, None)

    def providers_with_keys(self) -> list[str]:
        return [p for p in ("google", "openrouter") if self.has_key(p)]

    def catalogue_providers(self) -> list[str]:
        """Providers to fetch models from: keyed ones plus the local servers."""
        return self.providers_with_keys() + [p for p in KEYLESS_PROVIDERS if self.has_key(p)]

    def ollama_base(self) -> str:
        url = (os.environ.get(OLLAMA_URL_ENV) or self.ollama_url or DEFAULT_OLLAMA_URL).strip()
        return url or DEFAULT_OLLAMA_URL

    def llamacpp_base(self) -> str:
        url = (os.environ.get(LLAMACPP_URL_ENV) or self.llamacpp_url or DEFAULT_LLAMACPP_URL).strip()
        return url or DEFAULT_LLAMACPP_URL

    def local_base(self, provider: str) -> str:
        """Server URL for a keyless provider, for menus and --check."""
        return self.llamacpp_base() if provider == "llamacpp" else self.ollama_base()

    def label(self, provider: Optional[str] = None) -> str:
        return PROVIDER_LABELS.get(provider or self.provider, provider or self.provider)

    # -- serialisation ----------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "project_dir": self.project_dir,
            "provider": self.provider,
            "model": self.model,
            "keys": dict(self.stored_keys),
            "unicode": self.unicode,
            "ollama_url": self.ollama_url,
            "llamacpp_url": self.llamacpp_url,
            "effort": self.effort,
            "version": 1,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        keys = data.get("keys") or {}
        if not isinstance(keys, dict):
            keys = {}
        return cls(
            project_dir=data.get("project_dir"),
            provider=data.get("provider") or "google",
            model=data.get("model"),
            stored_keys={str(k): str(v) for k, v in keys.items() if v},
            unicode=data.get("unicode"),
            ollama_url=data.get("ollama_url"),
            llamacpp_url=data.get("llamacpp_url"),
            effort=normalize_effort(data.get("effort")) or DEFAULT_EFFORT,
        )


def load(path: Optional[Path] = None) -> Config:
    target = Path(path) if path else config_path()
    try:
        raw = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return Config()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return Config()
    if not isinstance(data, dict):
        return Config()
    return Config.from_dict(data)


def save(cfg: Config, path: Optional[Path] = None) -> Path:
    target = Path(path) if path else config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg.to_dict(), indent=2), encoding="utf-8")
    os.replace(tmp, target)
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


def reset(path: Optional[Path] = None) -> bool:
    target = Path(path) if path else config_path()
    try:
        target.unlink()
        return True
    except FileNotFoundError:
        return False


def clean_key(raw: Optional[str]) -> str:
    """Normalise a pasted key: drop wrapping quotes, stray whitespace and Bearer."""
    if not raw:
        return ""
    key = str(raw).strip()
    if len(key) >= 2 and key[0] == key[-1] and key[0] in ("'", '"'):
        key = key[1:-1]
    key = "".join(key.split())
    if key.lower().startswith("bearer"):
        key = key[6:].lstrip(": ")
    return key


def key_conflicts(cfg: Config) -> list[str]:
    """Warn when an environment variable silently overrides a saved key."""
    problems = []
    for provider in ("google", "openrouter"):
        stored = cfg.stored_keys.get(provider)
        if not stored:
            continue
        for name in ENV_KEYS.get(provider, ()):
            value = os.environ.get(name)
            if value and clean_key(value) != clean_key(stored):
                problems.append(
                    "%s is set in your environment and overrides the saved %s key"
                    % (name, PROVIDER_LABELS.get(provider, provider))
                )
                break
    return problems


def mask(key: Optional[str]) -> str:
    if not key:
        return "not set"
    if len(key) <= 8:
        return key[:2] + "\u2026"
    return key[:4] + "\u2026" + key[-4:]

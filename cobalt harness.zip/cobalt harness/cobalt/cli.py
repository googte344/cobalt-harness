"""Command line entry point: onboarding, config checks, launching the UI."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import List, Optional, Tuple

from . import __version__
from .banner import splash
from .config import (
    KEYLESS_PROVIDERS,
    PROVIDER_ORDER,
    Config,
    clean_key,
    config_path,
    key_conflicts,
    load,
    mask,
    normalize_effort,
    reset,
    save,
)
from .providers import build_provider, load_models
from .providers.base import ModelInfo, ProviderError, explain_error
from .providers.google import GoogleProvider, static_models
from .providers.openrouter import OpenRouterProvider
from .theme import AMBER, BLUE_BRIGHT, BOLD, GREEN, GREY, RED, SILVER, WHITE, Theme
from .ui import CobaltUI


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cobalt",
        description="Free terminal AI coding agent for OpenRouter, Google AI Studio and Ollama.",
    )
    parser.add_argument("--project", help="project folder (asked for on first run)")
    parser.add_argument("--provider", choices=["google", "openrouter", "ollama"], help="provider to use")
    parser.add_argument("--model", help="model id to preselect")
    parser.add_argument("--key", help="API key for the chosen provider (saved to the config file)")
    parser.add_argument(
        "--ollama-url",
        help="Ollama server URL (default http://localhost:11434, saved to the config file)",
    )
    parser.add_argument("--check", action="store_true", help="verify configuration and list available models")
    parser.add_argument("--list-models", action="store_true", help="print the model catalogue and exit")
    parser.add_argument("--reset-config", action="store_true", help="delete the saved config before starting")
    parser.add_argument("--ascii", action="store_true", help="use ASCII instead of box-drawing characters")
    parser.add_argument("--no-color", action="store_true", help="disable colour")
    parser.add_argument("--quiet", action="store_true", help="skip the banner")
    parser.add_argument("--version", action="version", version="cobalt " + __version__)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.reset_config:
        reset()
    cfg = load()
    theme = Theme(color=_color_enabled(args), unicode=_unicode_enabled(args, cfg))

    if not args.quiet:
        splash(theme)

    try:
        if args.check:
            return _check(cfg, args, theme)
        _onboard(cfg, args, theme)
        project = _project_folder(cfg, args, theme)
        models, warnings = _catalogue(cfg, theme)
        for warning in warnings:
            print(theme.paint("  ! " + warning, (AMBER,)))
        if not models:
            print(theme.paint("  No models available. Fix your key or network and run again.", (RED,)))
            return 2
        if args.list_models:
            _print_models(models, theme)
            return 0
        return _run_ui(cfg, args, theme, project, models, warnings)
    except KeyboardInterrupt:
        print()
        return 130
    except ProviderError as exc:
        print(theme.paint("error: " + explain_error(str(exc)), (RED,)))
        return 2


# --- configuration ---------------------------------------------------------
def _color_enabled(args) -> bool:
    if args.no_color or os.environ.get("NO_COLOR"):
        return False
    return sys.stdout.isatty()


def _unicode_enabled(args, cfg: Config) -> bool:
    if args.ascii:
        return False
    if cfg.unicode is not None:
        return cfg.unicode
    encoding = (getattr(sys.stdout, "encoding", "") or "").lower()
    if "utf" in encoding:
        return True
    if os.name == "nt":
        return bool(os.environ.get("WT_SESSION") or os.environ.get("TERM"))
    return True


def _verify_key(provider_name: str, key: str) -> Tuple[bool, str]:
    """Ask the provider whether this key works. Returns (ok, detail)."""
    key = clean_key(key)
    if not key:
        return False, "the key is empty"
    try:
        provider = GoogleProvider(key) if provider_name == "google" else OpenRouterProvider(key)
        if provider_name == "openrouter":
            # The model list is public, so only /key proves the key is real.
            provider.check_key()
        models = provider.list_models()
    except ProviderError as exc:
        return False, explain_error(str(exc), provider_name)
    if not models:
        return False, "the provider accepted the key but returned no usable models"
    free = sum(1 for model in models if model.tier == "free")
    return True, "%d models available (%d free)" % (len(models), free)


def _format_warning(provider_name: str, key: str) -> str:
    """Cheap sanity check for keys that clearly came from somewhere else."""
    key = clean_key(key)
    if provider_name == "google" and not key.startswith("AIza"):
        return "Google AI Studio keys start with 'AIza'; this does not, so it may be a different kind of key"
    if provider_name == "openrouter" and not key.startswith("sk-or-"):
        return "OpenRouter keys start with 'sk-or-'; check the whole key was copied"
    return ""


def _onboard(cfg: Config, args, theme: Theme) -> None:
    if args.provider:
        cfg.provider = args.provider
    if args.ollama_url:
        cfg.ollama_url = args.ollama_url
        save(cfg)

    if args.key and cfg.provider in KEYLESS_PROVIDERS:
        print(theme.paint("  ! %s needs no API key - --key is ignored" % cfg.label(), (AMBER,)))
    elif args.key:
        cfg.set_key(cfg.provider, args.key)
        save(cfg)
        key = clean_key(args.key)
        warning = _format_warning(cfg.provider, key)
        if warning:
            print(theme.paint("  ! " + warning, (AMBER,)))
        print(theme.paint("  checking the key you passed ...", (GREY,)))
        ok, detail = _verify_key(cfg.provider, key)
        style = (GREEN,) if ok else (AMBER,)
        prefix = "  " + theme.glyph("check") + " key works: " if ok else "  ! key check failed: "
        print(theme.paint(prefix + detail, style))
        print()

    interactive = sys.stdin.isatty()

    if not cfg.has_key(cfg.provider):
        choices = [p for p in ("google", "openrouter") if cfg.has_key(p)]
        if choices and not args.provider:
            cfg.provider = choices[0]
        elif interactive:
            cfg.provider = _ask_provider(cfg, theme)

    while not cfg.has_key(cfg.provider):
        if not interactive:
            raise ProviderError(
                "no API key for %s. Run interactively, or set COBALT_GOOGLE_KEY / "
                "COBALT_OPENROUTER_KEY, or pass --key. For local models use "
                "--provider ollama." % cfg.label()
            )
        key = _ask_key(cfg, theme)
        if key is None:
            cfg.provider = "openrouter" if cfg.provider == "google" else "google"
            print(theme.paint("  switching to %s" % cfg.label(), (SILVER,)))
            continue
        cfg.set_key(cfg.provider, key)
        save(cfg)
        print(theme.paint("  key saved to " + str(config_path()), (GREY,)))
        print()

    conflicts = key_conflicts(cfg)
    for problem in conflicts:
        print(theme.paint("  ! " + problem, (AMBER,)))
    if conflicts:
        print(theme.paint("  Unset those variables (or delete the saved key) so the key you want is the one used.", (GREY,)))
        print()


def _ask_provider(cfg: Config, theme: Theme) -> str:
    print(theme.paint("  Connect a provider", (WHITE, BOLD)))
    print(theme.paint("  1  Google AI Studio   free tier: Gemini Flash / Flash-Lite, 2.5 Pro, Gemma 4", (SILVER,)))
    print(theme.paint("  2  OpenRouter         free and paid models from one key", (SILVER,)))
    print(theme.paint("  3  Ollama             local models you have already pulled", (SILVER,)))
    print(theme.paint("                        no key, server at %s" % cfg.ollama_base(), (GREY,)))
    print()
    while True:
        answer = input(theme.paint("  Choose [1/2/3]: ", (BLUE_BRIGHT,))).strip() or "1"
        if answer in ("1", "google"):
            return "google"
        if answer in ("2", "openrouter"):
            return "openrouter"
        if answer in ("3", "ollama"):
            return "ollama"
        print(theme.paint("  enter 1, 2 or 3", (RED,)))


def _ask_key(cfg: Config, theme: Theme) -> Optional[str]:
    """Prompt for a key, test it, and let the user retry or switch providers."""
    import getpass

    label = cfg.label()
    url = "https://aistudio.google.com/apikey" if cfg.provider == "google" else "https://openrouter.ai/keys"
    print(theme.paint("  Paste your %s API key (%s)" % (label, url), (SILVER,)))
    while True:
        try:
            raw = getpass.getpass(theme.paint("  paste key (hidden): ", (BLUE_BRIGHT,)))
        except (EOFError, KeyboardInterrupt):
            raise KeyboardInterrupt
        if not raw.strip():
            print(theme.paint("  a key is required", (RED,)))
            continue

        key = clean_key(raw)
        warning = _format_warning(cfg.provider, key)
        if warning:
            print(theme.paint("  ! " + warning, (AMBER,)))

        print(theme.paint("  checking key with %s ..." % label, (GREY,)))
        ok, detail = _verify_key(cfg.provider, key)
        if ok:
            print(theme.paint("  " + theme.glyph("check") + " key works: " + detail, (GREEN,)))
            return key

        print(theme.paint("  key check failed: " + detail, (RED,)))
        answer = input(
            theme.paint("  [r]etry the key, [k]eep it anyway, [s]witch provider [r]: ", (BLUE_BRIGHT,))
        ).strip().lower()
        if answer.startswith("k"):
            return key
        if answer.startswith("s"):
            return None
        print()


def _project_folder(cfg: Config, args, theme: Theme) -> Path:
    raw = args.project or cfg.project_dir
    if not raw:
        if sys.stdin.isatty():
            print(theme.paint("  Project folder", (WHITE, BOLD)))
            raw = input(theme.paint("  folder [.]: ", (BLUE_BRIGHT,))).strip() or "."
        else:
            raw = "."
    path = Path(raw).expanduser().resolve()
    if not path.exists():
        if path.is_file():
            raise ProviderError("%s exists and is not a folder" % path)
        if sys.stdin.isatty():
            answer = input(theme.paint("  %s does not exist. Create it? [Y/n]: " % path, (SILVER,))).strip().lower()
            if answer in ("n", "no"):
                raise ProviderError("project folder does not exist: %s" % path)
        path.mkdir(parents=True, exist_ok=True)
    if not path.is_dir():
        raise ProviderError("not a folder: %s" % path)
    cfg.project_dir = str(path)
    save(cfg)
    print(theme.paint("  project: " + str(path), (GREY,)))
    print()
    return path


def _catalogue(cfg: Config, theme: Theme) -> Tuple[List[ModelInfo], List[str]]:
    models: List[ModelInfo] = []
    warnings: List[str] = []
    for provider_name in cfg.catalogue_providers():
        try:
            found = load_models(cfg, provider_name)
        except ProviderError as exc:
            # Ollama is optional: only complain when it is the provider in use.
            if provider_name in KEYLESS_PROVIDERS and cfg.provider != provider_name:
                continue
            warnings.append("%s: %s" % (cfg.label(provider_name), explain_error(str(exc), provider_name)))
            if provider_name == "google":
                found = static_models()
                warnings.append("using the built-in Gemini table (tiers still detected offline)")
            else:
                found = []
        models.extend(found)
    return models, warnings


def _print_models(models: List[ModelInfo], theme: Theme) -> None:
    current_provider = None
    for model in models:
        if model.provider != current_provider:
            current_provider = model.provider
            print()
            print(theme.paint(current_provider.upper(), (BLUE_BRIGHT, BOLD)))
        tier_style = (GREEN,) if model.tier == "free" else (AMBER,) if model.tier == "paid" else (GREY,)
        print("  %-34s %-18s %s" % (model.id, theme.paint(model.badge, tier_style), model.name))


# --- running ---------------------------------------------------------------
def _run_ui(
    cfg: Config,
    args,
    theme: Theme,
    project: Path,
    models: List[ModelInfo],
    warnings: Optional[List[str]] = None,
) -> int:
    from .agent import Agent

    # Providers are switched with /api inside the app, so startup never wanders off
    # the configured one just because another provider's model was requested.
    active = cfg.provider
    candidates = [(index, model) for index, model in enumerate(models) if model.provider == active]
    if not candidates:
        print(
            theme.paint(
                "error: no models available for %s. Fix that provider, or start with "
                "--provider <name>." % cfg.label(active),
                (RED,),
            )
        )
        return 2

    wanted = args.model or cfg.model
    selected = candidates[0][0]
    if wanted:
        for index, model in candidates:
            if model.id == wanted:
                selected = index
                break
        else:
            for model in models:
                if model.id == wanted and model.provider != active:
                    print(
                        theme.paint(
                            "  ! %s belongs to %s; staying on %s (use /api %s to switch)"
                            % (wanted, cfg.label(model.provider), cfg.label(active), model.provider),
                            (AMBER,),
                        )
                    )
                    break
    else:
        for index, model in candidates:
            if model.tier == "free":
                selected = index
                break

    chosen = models[selected]
    try:
        provider = build_provider(cfg, chosen.provider)
    except ProviderError as exc:
        print(theme.paint("error: " + explain_error(str(exc)), (RED,)))
        return 2

    agent = Agent(provider, chosen.id, project, effort=cfg.effort)
    cfg.provider = chosen.provider
    cfg.model = chosen.id
    save(cfg)

    def switch(model: ModelInfo) -> Optional[str]:
        try:
            agent.provider = build_provider(cfg, model.provider)
        except ProviderError as exc:
            return "could not switch provider: %s" % explain_error(str(exc), model.provider)
        agent.model = model.id
        cfg.provider = model.provider
        cfg.model = model.id
        try:
            save(cfg)
        except OSError:
            pass
        return None

    def connect_provider(provider_name: str, key: Optional[str]):
        """Used by /api: save an optional new key and load that provider's models."""
        if key and provider_name not in KEYLESS_PROVIDERS:
            cfg.set_key(provider_name, key)
            try:
                save(cfg)
            except OSError:
                pass
        try:
            provider = build_provider(cfg, provider_name)
            found = provider.list_models()
        except ProviderError as exc:
            return [], explain_error(str(exc), provider_name)
        if not found:
            return [], "%s returned no usable models" % cfg.label(provider_name)
        agent.provider = provider
        cfg.provider = provider_name
        try:
            save(cfg)
        except OSError:
            pass
        return found, None

    def provider_status():
        return [(name, cfg.label(name), cfg.has_key(name)) for name in PROVIDER_ORDER]

    def change_folder(raw: str):
        """/folder: move the workspace without restarting the app."""
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = Path(cfg.project_dir or project) / path
        path = path.resolve()
        if path.exists() and not path.is_dir():
            return None, "%s is a file, not a folder" % path
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return None, "could not create %s: %s" % (path, exc)
        agent.root = path
        cfg.project_dir = str(path)
        try:
            save(cfg)
        except OSError:
            pass
        return path, None

    def change_effort(level: str):
        """/effort: remember how hard the agent should try."""
        resolved = normalize_effort(level)
        if resolved is None:
            return "unknown effort %r (use low, medium, high or extra)" % level
        agent.set_effort(resolved)
        cfg.effort = resolved
        try:
            save(cfg)
        except OSError:
            pass
        return None

    ui = CobaltUI(
        agent=agent,
        models=models,
        project=project,
        theme=theme,
        provider_label=cfg.label(chosen.provider),
        provider=chosen.provider,
        on_model=switch,
        selected=selected,
        startup_notes=warnings or [],
        on_provider=connect_provider,
        provider_status=provider_status,
        on_folder=change_folder,
        on_effort=change_effort,
        effort=cfg.effort,
    )
    ui.run()
    return 0


def _check(cfg: Config, args, theme: Theme) -> int:
    print(theme.paint("  Configuration check", (WHITE, BOLD)))
    project = cfg.project_dir
    print("  config file : %s" % config_path())
    print("  project     : %s" % (project or "(not set)"))
    ok = bool(project) and Path(project).is_dir()
    if project and not ok:
        print(theme.paint("  ! project folder is missing", (AMBER,)))

    for problem in key_conflicts(cfg):
        print(theme.paint("  ! " + problem, (AMBER,)))

    for provider_name in PROVIDER_ORDER:
        if provider_name in KEYLESS_PROVIDERS:
            print("  %-11s : %s (local, no key)" % (provider_name, cfg.ollama_base()))
            try:
                models = load_models(cfg, provider_name)
            except ProviderError as exc:
                print(theme.paint("  ! " + explain_error(str(exc), provider_name), (RED,)))
                continue
            print(theme.paint("                %d models installed" % len(models), (GREEN,)))
            for model in models[:5]:
                print("                  - %-30s %s" % (model.id, model.badge))
            if len(models) > 5:
                print("                  - ...")
            ok = True
            continue
        key = cfg.key(provider_name)
        if not key:
            print("  %-11s : no key" % provider_name)
            continue
        source = cfg.key_source(provider_name) or "config"
        print("  %-11s : %s (%s)" % (provider_name, mask(key), source))
        warning = _format_warning(provider_name, key)
        if warning:
            print(theme.paint("  ! " + warning, (AMBER,)))
        try:
            models = load_models(cfg, provider_name)
        except ProviderError as exc:
            print(theme.paint("  ! " + explain_error(str(exc), provider_name), (RED,)))
            continue
        free = sum(1 for m in models if m.tier == "free")
        paid = sum(1 for m in models if m.tier == "paid")
        print(theme.paint("                %d models (%d free, %d paid)" % (len(models), free, paid), (GREEN,)))
        for model in models[:5]:
            print("                  - %-30s %s" % (model.id, model.badge))
        if len(models) > 5:
            print("                  - ...")
        ok = True

    if args.list_models and ok:
        models, _ = _catalogue(cfg, theme)
        _print_models(models, theme)
    return 0 if ok else 1


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

"""Full-screen terminal UI: model sidebar, transcript, message box.

Layout (blue on navy/white):

    <top bar: app, project, provider>
    +-------- MODELS --------+  transcript
    |  Gemini 3.8 Flash FREE |  ...
    |  ...                   |  +------- MESSAGE -------+
    +------------------------+  | > build me a snake game |
                                +-------------------------+
    <status bar: hints, model, tier>

`/api` switches between Google AI Studio, OpenRouter and the local Ollama and
llama.cpp servers from inside the app, prompting for a key (hidden) when a keyed
provider is not connected yet. It is the only way to change provider: the sidebar lists models
from the active provider only, so picking a model can never switch backends.

If stdin is not a terminal the UI falls back to a plain line REPL so the agent
still works in pipes and CI.
"""

from __future__ import annotations

import queue
import shutil
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple

from . import __version__
from .agent import Agent, format_call
from .config import (
    DEFAULT_EFFORT,
    EFFORT_GUIDANCE,
    KEYLESS_PROVIDERS,
    normalize_effort,
    parse_context_window,
)
from .providers.base import ModelInfo
from .term import KeyReader
from .theme import (
    AMBER,
    BLUE,
    BLUE_BG,
    BLUE_BG_BRIGHT,
    BLUE_BRIGHT,
    BLUE_DEEP,
    BLUE_MID,
    BOLD,
    DIM,
    GREEN,
    GREY,
    GREY_DIM,
    RED,
    SILVER,
    WHITE,
    Theme,
    clip,
    visible_width,
    wrap,
)

Segment = Tuple[str, Tuple[str, ...]]

# Slash commands carry a "/"; plain keys do not. Both are listed on the bottom bar.
STATUS_COMMANDS = "/api /folder /effort /context /yolo /cancel /clear /help /exit"
STATUS_HOTKEYS = "tab models   enter send   ctrl+c quit"
STATUS_HOTKEYS_COMPACT = "tab models   ctrl+c quit"
STATUS_TEXT = STATUS_COMMANDS + "   " + STATUS_HOTKEYS


def seg(text: str, *styles: str) -> Segment:
    return (text, tuple(styles))


def render_row(theme: Theme, segments: Sequence[Segment], width: int, fill: Sequence[str] = ()) -> str:
    """Render one full-width row, padding the remainder so backgrounds line up."""
    out: List[str] = []
    used = 0
    for text, styles in segments:
        remaining = width - used
        if remaining <= 0:
            break
        piece = clip(text, remaining)
        if not piece:
            continue
        used += visible_width(piece)
        out.append(theme.paint(piece, styles))
    if used < width:
        out.append(theme.paint(" " * (width - used), tuple(fill)))
    return "".join(out)


@dataclass
class Entry:
    kind: str  # user | agent | tool | result | error | notice
    text: str = ""
    name: str = ""
    arguments: dict = None

    def __post_init__(self) -> None:
        if self.arguments is None:
            self.arguments = {}


@dataclass
class Approval:
    """A file change waiting for the user's yes/no (/yolo off)."""

    name: str
    arguments: dict
    event: threading.Event = field(default_factory=threading.Event)
    approved: bool = False


class CobaltUI:
    def __init__(
        self,
        agent: Agent,
        models: Sequence[ModelInfo],
        project: Path,
        theme: Theme,
        provider_label: str = "Google AI Studio",
        provider: str = "",
        on_model: Optional[Callable[[ModelInfo], Optional[str]]] = None,
        selected: int = 0,
        startup_notes: Optional[Sequence[str]] = None,
        on_provider: Optional[Callable[[str, Optional[str]], Tuple[List[ModelInfo], Optional[str]]]] = None,
        provider_status: Optional[Callable[[], List[Tuple[str, str, bool]]]] = None,
        on_folder: Optional[Callable[[str], Tuple[Optional[Path], Optional[str]]]] = None,
        on_effort: Optional[Callable[[str], Optional[str]]] = None,
        effort: str = "",
        yolo: bool = True,
    ) -> None:
        self.agent = agent
        self.models: List[ModelInfo] = list(models)
        self.project = Path(project)
        self.theme = theme
        self.provider_label = provider_label
        self.on_model = on_model
        self.on_provider = on_provider
        self.on_folder = on_folder
        self.on_effort = on_effort
        self.effort = normalize_effort(effort or getattr(agent, "effort", "")) or DEFAULT_EFFORT
        # /yolo off routes file changes through request_approval() first.
        self.yolo = bool(getattr(agent, "yolo", yolo))
        self.context_window = int(getattr(agent, "context_window", 0) or 0) or None
        self.pending_approval: Optional[Approval] = None
        self.cancel_requested = False
        self.plain = False
        if hasattr(agent, "approve"):
            agent.approve = self.request_approval
        set_yolo = getattr(agent, "set_yolo", None)
        if callable(set_yolo):
            set_yolo(self.yolo)
        self.provider_status = provider_status or _default_status
        self.selected = max(0, min(selected, len(self.models) - 1)) if self.models else 0
        # The active provider is fixed for the session: only /api may change it.
        self.provider_filter: Optional[str] = provider or (self.models[0].provider if self.models else None)
        visible = self._visible()
        if visible and self.selected not in visible:
            self.selected = visible[0]
        self.entries: List[Entry] = [Entry("notice", note) for note in (startup_notes or [])]
        self.input = ""
        self.focus = "input"
        self.scroll = 0
        self.sidebar_offset = 0
        self.busy = False
        self.running = True
        self.dirty = True
        self.tick = 0
        self.started_at = 0.0
        self.events: "queue.Queue[tuple]" = queue.Queue()
        self._last_draw = 0.0
        # /api state
        self.picker: Optional[str] = None
        self.provider_index = 0
        self.key_for: Optional[str] = None
        self.key_buffer = ""

    # -- model selection --------------------------------------------------
    @property
    def current(self) -> Optional[ModelInfo]:
        return self.models[self.selected] if self.models else None

    def _visible(self) -> List[int]:
        if self.provider_filter is None:
            return list(range(len(self.models)))
        return [index for index, model in enumerate(self.models) if model.provider == self.provider_filter]

    def apply_selection(self) -> None:
        model = self.current
        if model is None:
            return
        message = None
        if self.on_model is not None:
            message = self.on_model(model)
        self.provider_label = _provider_label(model.provider)
        if message:
            self.entries.append(Entry("notice", message))
        else:
            self.entries.append(
                Entry("notice", "model set to %s (%s, %s tier)" % (model.name, self.provider_label, model.tier))
            )
        self.scroll = 0

    # -- provider switching (/api) ----------------------------------------
    def _provider_choices(self) -> List[Tuple[str, str, bool]]:
        try:
            return list(self.provider_status())
        except Exception:
            return _default_status()

    def _select_provider(self, name: str) -> None:
        name = name.lower()
        labels = {choice[0]: choice for choice in self._provider_choices()}
        if name not in labels:
            self.entries.append(
                Entry("notice", "unknown provider %r (try %s)" % (name, ", ".join(sorted(labels))))
            )
            return
        self.picker = None
        has_key = labels[name][2]
        if not has_key:
            self._start_key(name)
            return
        if not any(model.provider == name for model in self.models):
            self._connect(name, None)
            return
        self.provider_filter = name
        self._focus_provider_model(name)

    def _start_key(self, provider: str) -> None:
        self.key_for = provider
        self.key_buffer = ""
        self.focus = "input"
        self.entries.append(
            Entry("notice", "paste your %s API key and press enter (input is hidden, esc cancels)" % _provider_label(provider))
        )

    def _connect(self, provider: str, key: Optional[str]) -> None:
        if self.on_provider is None:
            self.entries.append(Entry("notice", "provider switching is not available in this session"))
            return
        self.key_for = None
        self.key_buffer = ""
        self.busy = True
        self.started_at = time.monotonic()
        threading.Thread(target=self._connect_work, args=(provider, key), daemon=True).start()

    def _connect_work(self, provider: str, key: Optional[str]) -> None:
        try:
            models, error = self.on_provider(provider, key)
        except Exception as exc:  # never let a provider switch kill the UI
            models, error = [], "%s: %s" % (type(exc).__name__, exc)
        if error or not models:
            self.events.put(("provider_error", provider, error or "no models returned"))
        else:
            self.events.put(("provider_ready", provider, models))
        self.events.put(("done",))

    def _merge_models(self, models: Sequence[ModelInfo]) -> None:
        if not models:
            return
        provider = models[0].provider
        others = [model for model in self.models if model.provider != provider]
        self.models = others + list(models)
        self.models.sort(
            key=lambda model: (
                0 if model.provider == "google" else 1,
                {"google": 0, "openrouter": 1, "ollama": 2, "llamacpp": 3}.get(model.provider, 4),
                {"free": 0, "paid": 1}.get(model.tier, 2),
                model.name.lower(),
            )
        )
        self.selected = max(0, min(self.selected, len(self.models) - 1))

    def _focus_provider_model(self, provider: str) -> None:
        for index, model in enumerate(self.models):
            if model.provider == provider:
                self.selected = index
                break
        self.focus = "input"
        self.apply_selection()

    # -- events -----------------------------------------------------------
    def _work(self, text: str) -> None:
        try:
            for event in self.agent.run_turn(text):
                self.events.put(event)
        except Exception as exc:  # surfaced in the transcript, never crashes the UI
            self.events.put(("error", "%s: %s" % (type(exc).__name__, exc)))
        finally:
            self.events.put(("done",))

    def submit(self) -> None:
        text = self.input.strip()
        if not text:
            return
        if self.busy:
            # /cancel must work while the model is running; everything else waits.
            first = text.split()[0].lower()
            if first == "/cancel":
                self.input = ""
                self._cancel_command()
            elif first in ("/exit", "/quit", "/q"):
                self.input = ""
                self.running = False
            else:
                self.entries.append(Entry("notice", "still working on the previous request"))
            return
        self.input = ""
        self.scroll = 0
        if text.startswith("/"):
            self._command(text)
            return
        self.entries.append(Entry("user", text))
        self.busy = True
        self.started_at = time.monotonic()
        threading.Thread(target=self._work, args=(text,), daemon=True).start()

    def _command(self, text: str) -> None:
        parts = text.split()
        name = parts[0].lower()
        arg = parts[1].lower() if len(parts) > 1 else ""
        raw_arg = text.split(None, 1)[1].strip() if len(parts) > 1 else ""
        if name in ("/exit", "/quit", "/q"):
            self.running = False
        elif name in ("/context", "/conteext"):
            self._context_command(raw_arg)
        elif name == "/yolo":
            self._yolo_command(arg)
        elif name == "/cancel":
            self._cancel_command()
        elif name == "/clear":
            self.entries = []
            self.agent.reset()
            self.entries.append(Entry("notice", "conversation cleared"))
        elif name in ("/api", "/provider", "/providers"):
            self._api_command(arg)
        elif name == "/folder":
            self._folder_command(raw_arg)
        elif name == "/effort":
            self._effort_command(arg)
        elif name == "/help":
            self.entries.append(
                Entry(
                    "notice",
                    "/api  switch provider (google, openrouter, ollama, llamacpp, key)\n"
                    "/folder <path>  change the project folder\n"
                    "/effort low|medium|high|extra  set how hard the model tries\n"
                    "/context <tokens>  limit how much conversation is sent (8192, 128k, 1m, off)\n"
                    "/yolo [on|off]  ask before creating or editing files when off\n"
                    "/cancel  stop the model after the current step\n"
                    "/clear  reset the conversation     /help  show this help     /exit  quit\n"
                    "keys: tab models   enter send   ctrl+c quit",
                )
            )
        else:
            self.entries.append(Entry("notice", "unknown command %s (try /help)" % name))

    def _folder_command(self, raw: str) -> None:
        if not raw:
            self.entries.append(
                Entry("notice", "project folder: %s\nuse /folder <path> to change it" % self.project)
            )
            return
        if self.on_folder is None:
            self.entries.append(Entry("notice", "changing the project folder is not available in this session"))
            return
        path, error = self.on_folder(raw)
        if error or path is None:
            self.entries.append(Entry("error", error or "could not change the project folder"))
            return
        self.project = Path(path)
        # Paths in the old history belong to the previous project.
        self.agent.reset()
        self.entries.append(Entry("notice", "project folder is now %s (conversation cleared)" % self.project))

    def _effort_command(self, level: str) -> None:
        if not level:
            self.entries.append(
                Entry(
                    "notice",
                    "effort: %s - %s\nuse /effort low|medium|high|extra"
                    % (self.effort, EFFORT_GUIDANCE[self.effort]),
                )
            )
            return
        resolved = normalize_effort(level)
        if resolved is None:
            self.entries.append(Entry("notice", "usage: /effort low|medium|high|extra (got %r)" % level))
            return
        self.effort = resolved
        setter = getattr(self.agent, "set_effort", None)
        if callable(setter):
            setter(resolved)
        message = self.on_effort(resolved) if self.on_effort is not None else None
        if message:
            self.entries.append(Entry("error", message))
        else:
            self.entries.append(Entry("notice", "effort set to %s - %s" % (resolved, EFFORT_GUIDANCE[resolved])))

    def _context_command(self, raw: str) -> None:
        if not raw:
            used = int(getattr(self.agent, "context_used", 0) or 0)
            if self.context_window:
                detail = "context window: {:,} tokens".format(self.context_window)
                if used:
                    detail += "\nlast request used {:,} tokens".format(used)
            else:
                detail = "context window: not set - the whole conversation is sent"
            self.entries.append(
                Entry("notice", detail + "\nuse /context 128k to set one, or /context off to send everything")
            )
            return
        try:
            value = parse_context_window(raw)
        except ValueError:
            self.entries.append(
                Entry("notice", "usage: /context <tokens> (8192, 128k, 1m, off) (got %r)" % raw)
            )
            return
        self.context_window = value
        setter = getattr(self.agent, "set_context_window", None)
        if callable(setter):
            setter(value)
        else:
            try:
                self.agent.context_window = value
            except Exception:
                pass
        if value is None:
            self.entries.append(Entry("notice", "context window cleared - the whole conversation is sent"))
        else:
            self.entries.append(
                Entry(
                    "notice",
                    "context window set to {:,} tokens - older turns are dropped from requests, "
                    "and the current turn is always kept.".format(value),
                )
            )

    def _yolo_command(self, value: str) -> None:
        if value in ("on", "yes", "true", "1"):
            enabled = True
        elif value in ("off", "no", "false", "0"):
            enabled = False
        elif value in ("", "toggle"):
            enabled = not self.yolo
        else:
            self.entries.append(Entry("notice", "usage: /yolo [on|off]"))
            return
        self.yolo = enabled
        setter = getattr(self.agent, "set_yolo", None)
        if callable(setter):
            setter(enabled)
        else:
            try:
                self.agent.yolo = enabled
            except Exception:
                pass
        if enabled:
            self.entries.append(Entry("notice", "YOLO on - file changes are applied without asking"))
        else:
            self.entries.append(
                Entry(
                    "notice",
                    "YOLO off - Cobalt asks before creating or editing files "
                    "(y approve, n skip, c cancel the run)",
                )
            )

    def _cancel_command(self) -> None:
        if self.pending_approval is not None:
            self._resolve_approval(False, cancel=True)
        if not self.busy:
            self.entries.append(Entry("notice", "nothing is running"))
            return
        self._request_cancel()
        self.entries.append(
            Entry("notice", "cancelling - the model stops after the current request or tool call")
        )

    # -- file-change approval (/yolo off) ----------------------------------
    def request_approval(self, name: str, arguments: dict) -> bool:
        """Block the agent thread until the user approves or skips a file change."""
        args = dict(arguments or {})
        if self.plain:
            path = str(args.get("path") or "file")
            verb = "edit" if name == "edit_file" else "create"
            try:
                answer = input("  %s %s? [y/N] " % (verb, path)).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return False
            return answer in ("y", "yes")
        request = Approval(name, args)
        self.pending_approval = request
        self.dirty = True
        request.event.wait()
        if self.pending_approval is request:
            self.pending_approval = None
        return request.approved

    def _resolve_approval(self, approved: bool, cancel: bool = False) -> None:
        request = self.pending_approval
        if request is None:
            return
        request.approved = approved
        self.pending_approval = None
        request.event.set()
        self.dirty = True
        if cancel:
            self._request_cancel()

    def _request_cancel(self) -> None:
        cancel = getattr(self.agent, "cancel", None)
        if callable(cancel):
            cancel()
        if self.busy:
            self.cancel_requested = True

    def _api_command(self, arg: str) -> None:
        if arg in ("llama.cpp", "llama-cpp", "llama_cpp"):
            arg = "llamacpp"
        if arg in ("google", "openrouter", "ollama", "llamacpp"):
            self._select_provider(arg)
        elif arg == "key":
            provider = self.provider_filter or (self.current.provider if self.current else "google")
            if provider in KEYLESS_PROVIDERS:
                self.entries.append(
                    Entry("notice", "%s needs no API key because it runs on this machine" % _provider_label(provider))
                )
                return
            self._start_key(provider)
        elif arg:
            self.entries.append(Entry("notice", "usage: /api [google|openrouter|ollama|llamacpp|key]"))
        else:
            self.picker = "providers"
            self.provider_index = 0
            self.focus = "models"
            self.entries.append(
                Entry(
                    "notice",
                    "choose a provider: up/down then enter, or /api google|openrouter|ollama|llamacpp|key",
                )
            )

    def pump(self) -> bool:
        changed = False
        while True:
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            changed = True
            kind = event[0]
            if kind == "text":
                self._agent_text(event[1])
            elif kind == "tool_call":
                self.entries.append(Entry("tool", name=event[1], arguments=event[2]))
            elif kind == "tool_result":
                self.entries.append(Entry("result", event[2], name=event[1]))
            elif kind == "error":
                self.entries.append(Entry("error", event[1]))
            elif kind == "notice":
                self.entries.append(Entry("notice", event[1]))
            elif kind == "provider_ready":
                self._merge_models(event[2])
                self.provider_filter = event[1]
                self._focus_provider_model(event[1])
                self.entries.append(
                    Entry(
                        "notice",
                        "connected to %s: %d models" % (_provider_label(event[1]), len(event[2])),
                    )
                )
            elif kind == "provider_error":
                self.entries.append(Entry("error", "%s: %s" % (_provider_label(event[1]), event[2])))
            elif kind == "done":
                self.busy = False
                self.cancel_requested = False
        if changed:
            self.scroll = 0
        return changed

    def _agent_text(self, text: str) -> None:
        last = self.entries[-1] if self.entries else None
        if last is not None and last.kind == "agent":
            last.text = (last.text + "\n\n" + text).strip()
        else:
            self.entries.append(Entry("agent", text))

    # -- drawing ----------------------------------------------------------
    def draw(self) -> None:
        size = shutil.get_terminal_size((100, 30))
        cols = max(56, size.columns)
        rows = max(14, size.lines)
        frame = self.compose(cols, rows)
        sys.stdout.write("\x1b[H" + "\r\n".join(frame) + "\x1b[J")
        sys.stdout.flush()
        self._last_draw = time.monotonic()

    def compose(self, cols: int, rows: int) -> List[str]:
        self.tick += 1
        body = rows - 2
        side_w = min(36, max(26, cols // 3))
        main_w = cols - side_w - 2
        if main_w < 40:
            side_w = max(22, cols - 42)
            main_w = cols - side_w - 2
        sidebar = self._sidebar(side_w, body)
        main = self._main(main_w, body)
        out = [self._top_bar(cols)]
        for index in range(body):
            out.append(sidebar[index] + "  " + main[index])
        out.append(self._status_bar(cols))
        return out

    def _tokens_used(self) -> int:
        usage = getattr(self.agent, "usage", None) or {}
        try:
            return int(usage.get("input", 0) or 0) + int(usage.get("output", 0) or 0)
        except (TypeError, ValueError, AttributeError):
            return 0

    def _top_bar(self, cols: int) -> str:
        th = self.theme
        left = [seg(" " + th.glyph("dot") + " ", WHITE, BOLD, BLUE_BG), seg("COBALT", BLUE_BRIGHT, BOLD, BLUE_BG)]
        left.append(seg(" v" + __version__, GREY, BLUE_BG))
        left.append(seg("   " + _short_path(self.project), SILVER, BLUE_BG))
        right_text = "%s  \u00b7  %s  \u00b7  %s" % (
            self.provider_label,
            self.effort,
            _tokens(self._tokens_used()),
        )
        left_width = sum(visible_width(t) for t, _ in left)
        gap = cols - left_width - visible_width(right_text) - 1
        row: List[Segment] = list(left)
        row.append(seg(" " * max(1, gap), BLUE_BG))
        row.append(seg(right_text + " ", WHITE, BLUE_BG))
        return render_row(th, row, cols, (BLUE_BG,))

    def _command_segments(self, cols: int) -> List[Segment]:
        """Slash commands first, then plain hotkeys. Active caps show in amber."""
        parts: List[Segment] = []
        for command in STATUS_COMMANDS.split():
            active = (command == "/yolo" and not self.yolo) or (
                command == "/context" and bool(self.context_window)
            )
            style = (AMBER, BOLD, BLUE_BG) if active else (SILVER, BLUE_BG)
            parts.append(seg(" " + command, *style))
        hotkeys = STATUS_HOTKEYS
        used = sum(visible_width(text) for text, _ in parts) + 3
        if used + visible_width(hotkeys) > cols:
            hotkeys = STATUS_HOTKEYS_COMPACT
        parts.append(seg("   " + hotkeys, SILVER, BLUE_BG))
        return parts

    def _status_bar(self, cols: int) -> str:
        th = self.theme
        if self.pending_approval is not None:
            parts = [seg(" y approve   n skip   c cancel", WHITE, BOLD, BLUE_BG)]
        elif self.cancel_requested:
            parts = [seg(" cancelling - stops after the current step", AMBER, BOLD, BLUE_BG)]
        elif self.busy:
            elapsed = int(time.monotonic() - self.started_at)
            parts = [
                seg(
                    " %s working%s   /cancel stops"
                    % (th.spinner(self.tick), " %ds" % elapsed if elapsed else ""),
                    WHITE,
                    BOLD,
                    BLUE_BG,
                )
            ]
        elif self.key_for is not None:
            parts = [seg(" paste key   enter connect   esc cancel", WHITE, BOLD, BLUE_BG)]
        elif self.picker == "providers":
            parts = [seg(" \u2191\u2193 provider   enter connect   esc cancel", SILVER, BLUE_BG)]
        elif self.focus == "models":
            parts = [seg(" \u2191\u2193 choose   enter use   tab back   ctrl+c quit", SILVER, BLUE_BG)]
        else:
            parts = self._command_segments(cols)
        model = self.current
        if model is None:
            right_text = "no model"
        else:
            right_text = "%s %s" % (model.name, "[" + model.badge + "]")
        # Commands and hotkeys come first; the model badge (already highlighted in
        # the sidebar) only appears when the row has room for it.
        left_width = sum(visible_width(text) for text, _ in parts)
        if cols - left_width - visible_width(right_text) - 2 < 1:
            right_text = ""
        gap = cols - left_width - visible_width(right_text) - 2
        row: List[Segment] = list(parts)
        row.append(seg(" " * max(1, gap), BLUE_BG))
        if right_text:
            row.append(seg(right_text + " ", WHITE, BOLD, BLUE_BG))
        return render_row(th, row, cols, (BLUE_BG,))

    # -- sidebar ----------------------------------------------------------
    def _sidebar(self, width: int, height: int) -> List[str]:
        th = self.theme
        inner_w = width - 2
        inner_h = height - 2
        rows = self._sidebar_rows()
        self._clamp_sidebar(rows, inner_h)
        title = "PROVIDERS" if self.picker == "providers" else "MODELS"
        out = [_box_top(th, width, title, (BLUE, BOLD))]
        visible = rows[self.sidebar_offset:self.sidebar_offset + inner_h]
        for row in visible:
            if row[0] == "header":
                out.append(_box_row(th, [seg(" " + row[1].upper(), BLUE_MID, BOLD)], width, (BLUE,)))
            elif row[0] == "model":
                out.append(_box_row(th, self._model_segments(row[1], row[2], inner_w), width, (BLUE,)))
            elif row[0] == "provider":
                out.append(_box_row(th, self._provider_segments(row[1], row[2], inner_w), width, (BLUE,)))
            else:
                out.append(_box_row(th, [], width, (BLUE,)))
        for _ in range(inner_h - len(visible)):
            out.append(_box_row(th, [], width, (BLUE,)))
        out.append(_box_bottom(th, width, (BLUE,)))
        return out

    def _sidebar_rows(self) -> List[tuple]:
        if self.picker == "providers":
            return [("provider", index, choice) for index, choice in enumerate(self._provider_choices())]
        rows: List[tuple] = []
        last_provider = None
        for index in self._visible():
            model = self.models[index]
            if model.provider != last_provider:
                if rows:
                    rows.append(("blank", ""))
                rows.append(("header", _provider_label(model.provider)))
                last_provider = model.provider
            rows.append(("model", index, model))
        return rows

    def _provider_segments(self, index: int, choice: tuple, inner_w: int) -> List[Segment]:
        th = self.theme
        name, label, has_key = choice[0], choice[1], choice[2]
        selected = index == self.provider_index
        marker = th.glyph("sel") if selected else " "
        if name in KEYLESS_PROVIDERS:
            status, status_style = "local", (GREEN,)
        else:
            status = "key ok" if has_key else "no key"
            status_style = (GREEN,) if has_key else (AMBER,)
        label_w = max(4, inner_w - 9)
        if selected:
            return [
                seg(marker + " ", WHITE, BOLD, BLUE_BG_BRIGHT),
                seg(label[:label_w].ljust(label_w), WHITE, BOLD, BLUE_BG_BRIGHT),
                seg(" ", BLUE_BG_BRIGHT),
                seg(status.ljust(6), WHITE, BOLD, BLUE_BG_BRIGHT),
            ]
        return [
            seg(marker + " ", WHITE),
            seg(label[:label_w].ljust(label_w), SILVER),
            seg(" ",),
            seg(status.ljust(6), *status_style),
        ]

    def _model_segments(self, index: int, model: ModelInfo, inner_w: int) -> List[Segment]:
        th = self.theme
        selected = index == self.selected
        name_w = max(4, inner_w - 7)
        marker = th.glyph("sel") if selected else " "
        badge = model.badge
        if selected:
            return [
                seg(marker + " ", WHITE, BOLD, BLUE_BG_BRIGHT),
                seg(model.name[:name_w].ljust(name_w), WHITE, BOLD, BLUE_BG_BRIGHT),
                seg(" ", BLUE_BG_BRIGHT),
                seg(badge.ljust(4), WHITE, BOLD, BLUE_BG_BRIGHT),
            ]
        badge_style = {"free": (GREEN,), "paid": (AMBER,)}.get(model.tier, (GREY_DIM,))
        return [
            seg(marker + " ", WHITE),
            seg(model.name[:name_w].ljust(name_w), SILVER),
            seg(" ",),
            seg(badge.ljust(4), *badge_style),
        ]

    def _clamp_sidebar(self, rows: List[tuple], inner_h: int) -> None:
        kind, key = ("provider", self.provider_index) if self.picker == "providers" else ("model", self.selected)
        line = 0
        for position, row in enumerate(rows):
            if row[0] == kind and row[1] == key:
                line = position
                break
        max_offset = max(0, len(rows) - inner_h)
        if line < self.sidebar_offset:
            self.sidebar_offset = line
        elif line >= self.sidebar_offset + inner_h:
            self.sidebar_offset = line - inner_h + 1
        self.sidebar_offset = max(0, min(self.sidebar_offset, max_offset))

    # -- main pane --------------------------------------------------------
    def _main(self, width: int, height: int) -> List[str]:
        input_h = 3
        transcript_h = max(3, height - input_h - 1)
        rows = self._transcript(width, transcript_h)
        rows.append(render_row(self.theme, [], width))
        rows.extend(self._input_box(width, input_h))
        return rows[:height]

    def _transcript(self, width: int, height: int) -> List[str]:
        th = self.theme
        lines = self._transcript_segments(width)
        if self.scroll > 0:
            end = max(0, len(lines) - self.scroll)
            start = max(0, end - height)
            window = lines[start:end]
        else:
            window = lines[-height:]
        max_scroll = max(0, len(lines) - height)
        self.scroll = min(self.scroll, max_scroll)
        rows = [render_row(th, [seg(" " + text, *styles)], width) for text, styles in window]
        blank = render_row(th, [], width)
        return [blank] * (height - len(rows)) + rows

    def _transcript_segments(self, width: int) -> List[Segment]:
        if not self.entries:
            return self._welcome(width)
        inner = width - 2
        out: List[Segment] = []
        for entry in self.entries:
            if out:
                out.append(seg(""))
            out.extend(self._entry_segments(entry, inner))
        return out

    def _welcome(self, width: int) -> List[Segment]:
        rows = [
            ("Tell Cobalt what to build.", (WHITE, BOLD)),
            ("", ()),
            ("It reads this folder, writes files and runs commands.", (SILVER,)),
            ("Use it for a new app, a bug fix, a script, or a refactor.", (SILVER,)),
            ("", ()),
            ('Try: "build a snake game in python, then run the tests"', (BLUE_BRIGHT,)),
            ("\u2191\u2193 picks a model \u00b7 tab switches focus \u00b7 /api changes provider", (GREY,)),
        ]
        lines: List[Segment] = []
        for text, styles in rows:
            for piece in wrap(text, width - 2) if text else [""]:
                lines.append(seg("  " + piece if piece else "", *styles))
        return lines

    def _entry_segments(self, entry: Entry, width: int) -> List[Segment]:
        th = self.theme
        out: List[Segment] = []
        if entry.kind == "user":
            out.append(seg("YOU", BLUE_BRIGHT, BOLD))
            for line in wrap(entry.text, width):
                out.append(seg(line, WHITE))
        elif entry.kind == "agent":
            out.append(seg("COBALT", BLUE_BRIGHT, BOLD))
            for line in wrap(entry.text, width):
                out.append(seg(line, SILVER))
        elif entry.kind == "tool":
            out.append(seg("  " + th.glyph("sel") + " " + format_call(entry.name, entry.arguments), BLUE_MID))
        elif entry.kind == "result":
            lines = entry.text.splitlines() or [""]
            if len(lines) > 12:
                lines = lines[:12] + ["\u2026 %d more lines" % (len(lines) - 12)]
            for line in lines:
                for piece in wrap(line, width - 2):
                    out.append(seg("  " + piece, GREY))
        elif entry.kind == "error":
            out.append(seg("ERROR", RED, BOLD))
            for line in wrap(entry.text, width):
                out.append(seg(line, RED))
        else:
            for line in wrap(entry.text, width):
                out.append(seg(line, GREY_DIM, DIM))
        return out

    def _input_box(self, width: int, height: int) -> List[str]:
        th = self.theme
        focused = self.focus == "input" or self.key_for is not None
        border = (BLUE_BRIGHT, BOLD) if focused else (BLUE_DEEP,)
        inner_w = width - 2
        if self.pending_approval is not None:
            request = self.pending_approval
            path = str(request.arguments.get("path") or "file")
            verb = "edit" if request.name == "edit_file" else "create"
            text = "%s %s?   y approve   n skip" % (verb, path)
            title = "CONFIRM"
            focused = True
            border = (AMBER, BOLD)
        elif self.key_for is not None:
            prompt = _provider_label(self.key_for) + " key: "
            text = prompt + "*" * len(self.key_buffer)
            title = "API KEY"
        else:
            prompt = th.glyph("sel") + " "
            text = prompt + self.input
            title = "MESSAGE"
        cursor = th.glyph("cursor") if focused else ""
        pieces: List[Segment] = []
        budget = inner_w - 2
        while visible_width(text) + 1 > budget and text:
            text = text[1:]
        pieces.append(seg(" " + text, WHITE))
        if cursor:
            pieces.append(seg(cursor, BLUE_BRIGHT, BOLD))
        out = [_box_top(th, width, title, border)]
        out.append(_box_row(th, pieces, width, border))
        out.append(_box_bottom(th, width, border))
        return out

    # -- keys -------------------------------------------------------------
    def handle_key(self, key: str) -> None:
        self.dirty = True
        if key == "ctrl-c":
            self.running = False
            return
        if self.pending_approval is not None:
            if key in ("y", "Y", "enter"):
                self._resolve_approval(True)
            elif key in ("n", "N", "esc"):
                self._resolve_approval(False)
            elif key in ("c", "C"):
                self._resolve_approval(False, cancel=True)
            return
        if key == "ctrl-d" and not self.input and self.focus == "input" and self.key_for is None:
            self.running = False
            return
        if key == "tab":
            if self.key_for is not None:
                return
            self.focus = "models" if self.focus == "input" else "input"
            return
        if self.focus == "models":
            self._model_key(key)
        else:
            self._input_key(key)

    def _move(self, delta: int) -> None:
        if self.picker == "providers":
            count = len(self._provider_choices())
            self.provider_index = max(0, min(max(0, count - 1), self.provider_index + delta))
            return
        visible = self._visible()
        if not visible:
            return
        try:
            position = visible.index(self.selected)
        except ValueError:
            position = 0
        position = max(0, min(len(visible) - 1, position + delta))
        self.selected = visible[position]

    def _model_key(self, key: str) -> None:
        if self.picker == "providers":
            if key in ("up", "k"):
                self._move(-1)
            elif key in ("down", "j"):
                self._move(1)
            elif key == "enter":
                choices = self._provider_choices()
                if choices:
                    name = choices[max(0, min(self.provider_index, len(choices) - 1))][0]
                    self.picker = None
                    self._select_provider(name)
            elif key == "esc":
                self.picker = None
            return
        if key in ("up", "k"):
            self._move(-1)
        elif key in ("down", "j"):
            self._move(1)
        elif key == "home":
            visible = self._visible()
            if visible:
                self.selected = visible[0]
        elif key == "end":
            visible = self._visible()
            if visible:
                self.selected = visible[-1]
        elif key == "pgup":
            self._move(-8)
        elif key == "pgdn":
            self._move(8)
        elif key in ("enter", "space", " "):
            self.apply_selection()
            self.focus = "input"
        elif key == "esc":
            self.focus = "input"

    def _input_key(self, key: str) -> None:
        if self.key_for is not None:
            self._key_entry_key(key)
            return
        if key == "enter":
            self.submit()
        elif key == "backspace":
            self.input = self.input[:-1]
        elif key == "ctrl-u":
            self.input = ""
        elif key == "esc":
            self.picker = None
            self.focus = "models"
        elif key == "up":
            self.scroll += 1
        elif key == "down":
            self.scroll = max(0, self.scroll - 1)
        elif key == "pgup":
            self.scroll += 10
        elif key == "pgdn":
            self.scroll = max(0, self.scroll - 10)
        elif len(key) == 1 and key.isprintable():
            self.input += key

    def _key_entry_key(self, key: str) -> None:
        if key == "enter":
            provider = self.key_for
            key_text = self.key_buffer.strip()
            self.key_buffer = ""
            if not key_text:
                self.key_for = None
                self.entries.append(Entry("notice", "no key entered"))
                return
            self._connect(provider or "google", key_text)
        elif key == "backspace":
            self.key_buffer = self.key_buffer[:-1]
        elif key == "esc":
            self.key_for = None
            self.key_buffer = ""
            self.entries.append(Entry("notice", "key entry cancelled"))
        elif len(key) == 1 and key.isprintable():
            self.key_buffer += key

    # -- loops ------------------------------------------------------------
    def run(self) -> None:
        if not (sys.stdin.isatty() and sys.stdout.isatty()):
            return self.run_plain()
        with KeyReader() as reader:
            while self.running:
                if self.pump():
                    self.dirty = True
                if self.busy and time.monotonic() - self._last_draw > 0.1:
                    self.dirty = True
                if self.dirty:
                    self.draw()
                    self.dirty = False
                key = reader.poll(0.06)
                if key is not None:
                    self.handle_key(key)

    def run_plain(self) -> None:
        self.plain = True
        print("Cobalt - type /help for commands, /exit to quit")
        while self.running:
            try:
                line = input("cobalt> ")
            except (EOFError, KeyboardInterrupt):
                break
            self.input = line
            if not line.strip():
                self.input = ""
                continue
            if line.strip().startswith("/"):
                self._command(line.strip())
                self.input = ""
                for entry in self.entries:
                    self._print_entry(entry)
                self.entries = []
                continue
            self.input = ""
            print("YOU: " + line)
            for event in self.agent.run_turn(line):
                if event[0] == "text":
                    print("COBALT: " + event[1])
                elif event[0] == "tool_call":
                    print("  " + format_call(event[1], event[2]))
                elif event[0] == "tool_result":
                    preview = event[2].splitlines()
                    if len(preview) > 6:
                        preview = preview[:6] + ["\u2026"]
                    for piece in preview:
                        print("    " + piece)
                elif event[0] == "error":
                    print("ERROR: " + event[1])
                elif event[0] == "notice":
                    print(event[1])

    def _print_entry(self, entry: Entry) -> None:
        if entry.kind == "notice":
            print(entry.text)
        elif entry.kind == "error":
            print("ERROR: " + entry.text)


# --- box drawing helpers ----------------------------------------------------
def _box_top(theme: Theme, width: int, title: str, style: Sequence[str]) -> str:
    box = theme.box
    inner = width - 2
    label = " " + title + " " if title else ""
    if visible_width(label) > max(0, inner - 2):
        label = clip(label, max(0, inner - 2))
    fill = max(0, inner - 1 - visible_width(label))
    body = box["h"] + label + box["h"] * fill
    return theme.paint(box["tl"], tuple(style)) + theme.paint(body, tuple(style)) + theme.paint(box["tr"], tuple(style))


def _box_bottom(theme: Theme, width: int, style: Sequence[str]) -> str:
    box = theme.box
    return theme.paint(box["bl"], tuple(style)) + theme.paint(box["h"] * (width - 2), tuple(style)) + theme.paint(
        box["br"], tuple(style)
    )


def _box_row(theme: Theme, segments: Sequence[Segment], width: int, style: Sequence[str]) -> str:
    box = theme.box
    inner = render_row(theme, segments, width - 2)
    return theme.paint(box["v"], tuple(style)) + inner + theme.paint(box["v"], tuple(style))


def _provider_label(provider: str) -> str:
    from .config import PROVIDER_LABELS

    return PROVIDER_LABELS.get(provider, provider)


def _default_status() -> List[Tuple[str, str, bool]]:
    return [
        ("google", "Google AI Studio", False),
        ("openrouter", "OpenRouter", False),
        ("ollama", "Ollama (local)", True),
        ("llamacpp", "llama.cpp (local)", True),
    ]


def _tokens(count: int) -> str:
    """Compact token counter for the top bar."""
    if count < 1000:
        return "%d tok" % count
    if count < 1_000_000:
        return "%.1fk tok" % (count / 1000.0)
    return "%.1fM tok" % (count / 1_000_000.0)


def _short_path(path: Path) -> str:
    text = str(path)
    home = str(Path.home())
    if text.startswith(home):
        text = "~" + text[len(home):]
    return text

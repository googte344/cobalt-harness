"""Cobalt - a free terminal AI coding agent for OpenRouter and Google AI Studio."""

__version__ = "0.1.0"
APP_NAME = "Cobalt"

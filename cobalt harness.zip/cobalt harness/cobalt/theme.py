"""Blue and white ANSI theme plus the width/wrapping helpers the UI needs.

Everything here is plain text in, styled text out. No third-party packages, so
the agent runs on a stock Python install on Windows and Linux.
"""

from __future__ import annotations

import re

RESET = "\x1b[0m"
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

# --- palette (256 colour, degrades to the nearest 16 colour slot everywhere) --
BLUE_BRIGHT = "38;5;45"
BLUE = "38;5;39"
BLUE_MID = "38;5;33"
BLUE_DEEP = "38;5;26"
WHITE = "38;5;231"
SILVER = "38;5;253"
GREY = "38;5;245"
GREY_DIM = "38;5;240"
NAVY_BG = "48;5;17"
BLUE_BG = "48;5;25"
BLUE_BG_BRIGHT = "48;5;33"
RED = "38;5;203"
GREEN = "38;5;114"
AMBER = "38;5;179"
BOLD = "1"
DIM = "2"

UNICODE_BOX = {
    "tl": "\u256d",
    "tr": "\u256e",
    "bl": "\u2570",
    "br": "\u256f",
    "h": "\u2500",
    "v": "\u2502",
    "dot": "\u25c6",
    "sel": "\u203a",
    "bullet": "\u25cf",
    "cursor": "\u258c",
    "spinner": "\u280b\u2819\u2839\u2838\u283c\u2834\u2826\u2827\u2807\u280f",
    "check": "\u2713",
}

ASCII_BOX = {
    "tl": "+",
    "tr": "+",
    "bl": "+",
    "br": "+",
    "h": "-",
    "v": "|",
    "dot": "*",
    "sel": ">",
    "bullet": "*",
    "cursor": "|",
    "spinner": "|/-\\",
    "check": "v",
}


def _is_wide(ch: str) -> bool:
    """Rough East-Asian / emoji width test so CJK input cannot break the layout."""
    o = ord(ch)
    return (
        0x1100 <= o <= 0x115F
        or 0x2E80 <= o <= 0xA4CF
        or 0xAC00 <= o <= 0xD7A3
        or 0xF900 <= o <= 0xFAFF
        or 0xFE30 <= o <= 0xFE6F
        or 0xFF00 <= o <= 0xFF60
        or 0xFFE0 <= o <= 0xFFE6
        or 0x1F300 <= o <= 0x1FAFF
        or 0x2600 <= o <= 0x27BF
    )


def visible_width(text: str) -> int:
    """Printable width of a string, ignoring ANSI escapes."""
    return sum(2 if _is_wide(ch) else 1 for ch in ANSI_RE.sub("", text))


def _take(text: str, width: int) -> str:
    """Longest prefix of ``text`` that fits in ``width`` columns."""
    out = []
    used = 0
    for ch in text:
        step = 2 if _is_wide(ch) else 1
        if used + step > width:
            break
        out.append(ch)
        used += step
    return "".join(out)


def clip(text: str, width: int) -> str:
    """Truncate to ``width`` columns, adding an ellipsis when text is dropped."""
    text = ANSI_RE.sub("", text)
    if width <= 0:
        return ""
    if visible_width(text) <= width:
        return text
    if width <= 1:
        return _take(text, width)
    return _take(text, width - 1) + "\u2026"


def wrap(text: str, width: int) -> list[str]:
    """Word wrap that also keeps explicit newlines and hard-breaks long tokens."""
    if width <= 0:
        return [""]
    lines: list[str] = []
    for raw in str(text).replace("\t", "    ").replace("\r\n", "\n").split("\n"):
        line = raw.rstrip()
        if not line.strip():
            lines.append("")
            continue
        current = ""
        for word in line.split(" "):
            while visible_width(word) > width:
                head = _take(word, width)
                if current:
                    lines.append(current)
                    current = ""
                lines.append(head)
                word = word[len(head):]
            if not current:
                current = word
            elif visible_width(current) + 1 + visible_width(word) <= width:
                current = current + " " + word
            else:
                lines.append(current)
                current = word
        lines.append(current.rstrip())
    return lines or [""]


class Theme:
    """Wraps text in ANSI styles, or leaves it alone when colour is off."""

    def __init__(self, color: bool = True, unicode: bool = True) -> None:
        self.color = color
        self.unicode = unicode
        self.box = dict(UNICODE_BOX if unicode else ASCII_BOX)

    def paint(self, text: str, styles=()) -> str:
        if not self.color or not styles:
            return text
        return "\x1b[" + ";".join(styles) + "m" + text + RESET

    def glyph(self, name: str) -> str:
        return self.box[name]

    def spinner(self, tick: int) -> str:
        frames = self.box["spinner"]
        return frames[tick % len(frames)]

"""Filesystem and shell tools the model can call.

Every path is resolved inside the project root; escapes are rejected. Command
output is truncated so a runaway build cannot flood the context window.
"""

from __future__ import annotations

import fnmatch
import os
import re
import subprocess
from pathlib import Path
from typing import Iterator, List, Tuple

MAX_READ_LINES = 1500
MAX_WRITE_CHARS = 1_000_000
MAX_OUTPUT_CHARS = 12_000
MAX_LIST_ENTRIES = 400
MAX_SEARCH_HITS = 60

SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    "env",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
    ".next",
    "target",
    ".idea",
    ".vscode",
}

DANGEROUS = (
    re.compile(r"rm\s+-[a-zA-Z]*r[a-zA-Z]*f?\s+/(\s|$)", re.I),
    re.compile(r"rm\s+-[a-zA-Z]*f[a-zA-Z]*r?\s+/(\s|$)", re.I),
    re.compile(r"\bmkfs(\.|\s)", re.I),
    re.compile(r"\bdd\s+if=.*of=/dev/", re.I),
    re.compile(r"\bformat\s+[a-z]:", re.I),
    re.compile(r"\bdiskpart\b", re.I),
    re.compile(r"\bshutdown\b|\breboot\b", re.I),
    re.compile(r":\(\)\s*\{", re.I),
    re.compile(r"del\s+/[sf]\s+[a-z]:", re.I),
)

TOOLS: List[dict] = [
    {
        "name": "list_files",
        "description": "List files and folders under the project. Skips .git, node_modules, venvs and build output.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Folder relative to the project root. Defaults to '.'"},
            },
            "required": [],
        },
    },
    {
        "name": "read_file",
        "description": "Read a text file from the project. Returns numbered-free raw content with the total line count.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to the project root"},
                "start_line": {"type": "integer", "description": "First line to return (1-based, optional)"},
                "end_line": {"type": "integer", "description": "Last line to return (inclusive, optional)"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Create a file or replace it completely. Parent folders are created automatically. Use this for new files.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to the project root"},
                "content": {"type": "string", "description": "Full file content"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "edit_file",
        "description": "Replace an exact snippet inside an existing file. Prefer this over write_file for small changes.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to the project root"},
                "old_string": {"type": "string", "description": "Exact text to replace, including indentation"},
                "new_string": {"type": "string", "description": "Replacement text"},
                "replace_all": {"type": "boolean", "description": "Replace every occurrence instead of requiring exactly one"},
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
    {
        "name": "search_files",
        "description": "Regex search across project files. Returns path:line: text for each match.",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Python regular expression"},
                "path": {"type": "string", "description": "Folder to search, relative to the project root"},
                "glob": {"type": "string", "description": "Optional filename filter such as '*.py'"},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "run_command",
        "description": "Run a shell command in the project root and return exit code, stdout and stderr. On Windows this uses cmd.exe.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Command line to execute"},
                "timeout": {"type": "integer", "description": "Seconds before the command is killed (default 120, max 600)"},
            },
            "required": ["command"],
        },
    },
]


class ToolError(Exception):
    """A tool was called with bad arguments; the message goes back to the model."""


def resolve(root: Path, relative: str) -> Path:
    """Resolve a model-supplied path, refusing anything outside the project."""
    raw = (relative or ".").strip() or "."
    root = Path(root).resolve()
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = root / candidate
    try:
        resolved = candidate.resolve()
    except OSError as exc:
        raise ToolError("invalid path %r: %s" % (relative, exc)) from None
    if resolved != root and root not in resolved.parents:
        raise ToolError("path escapes the project folder: %s" % relative)
    return resolved


def rel(root: Path, path: Path) -> str:
    try:
        value = path.resolve().relative_to(Path(root).resolve())
    except ValueError:
        return str(path)
    text = value.as_posix()
    return "." if text in ("", ".") else text


def _iter_files(base: Path) -> Iterator[Path]:
    for current, dirnames, filenames in os.walk(base):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".git"))
        for name in sorted(filenames):
            yield Path(current) / name


def _truncate(text: str, limit: int = MAX_OUTPUT_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\u2026 truncated (%d characters dropped)" % (len(text) - limit)


# --- tool implementations ---------------------------------------------------
def tool_list_files(root: Path, path: str = ".") -> str:
    base = resolve(root, path)
    if not base.exists():
        raise ToolError("no such folder: %s" % path)
    if base.is_file():
        return "%s (%d bytes)" % (rel(root, base), base.stat().st_size)
    lines: List[str] = []
    for entry in sorted(base.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
        if entry.is_dir():
            if entry.name in SKIP_DIRS:
                continue
            lines.append(entry.name + "/")
        else:
            try:
                size = entry.stat().st_size
            except OSError:
                size = 0
            lines.append("%s (%d bytes)" % (entry.name, size))
    if not lines:
        return "(empty folder)"
    extra = ""
    if len(lines) > MAX_LIST_ENTRIES:
        extra = "\n\u2026 %d more entries" % (len(lines) - MAX_LIST_ENTRIES)
        lines = lines[:MAX_LIST_ENTRIES]
    return "\n".join(lines) + extra


def tool_read_file(root: Path, path: str, start_line=None, end_line=None) -> str:
    target = resolve(root, path)
    if not target.exists():
        raise ToolError("no such file: %s" % path)
    if target.is_dir():
        raise ToolError("%s is a folder; use list_files" % path)
    try:
        text = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise ToolError("%s is binary or not UTF-8; cannot read as text" % path) from None
    except OSError as exc:
        raise ToolError("could not read %s: %s" % (path, exc)) from None
    lines = text.splitlines()
    total = len(lines)
    start = max(1, int(start_line)) if start_line else 1
    end = min(total, int(end_line)) if end_line else total
    if start > total:
        raise ToolError("start_line %d is past the end of the file (%d lines)" % (start, total))
    body = "\n".join(lines[start - 1:end])
    header = "%s (%d lines total, showing %d-%d):\n" % (rel(root, target), total, start, end)
    if end - start + 1 > MAX_READ_LINES:
        body = "\n".join(lines[start - 1:start - 1 + MAX_READ_LINES])
        header += "(capped at %d lines; request start_line/end_line for more)\n" % MAX_READ_LINES
    return header + body


def tool_write_file(root: Path, path: str, content: str) -> str:
    if len(content) > MAX_WRITE_CHARS:
        raise ToolError("content is too large (%d chars, limit %d)" % (len(content), MAX_WRITE_CHARS))
    target = resolve(root, path)
    if target.is_dir():
        raise ToolError("%s is a folder" % path)
    existed = target.exists()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    except OSError as exc:
        raise ToolError("could not write %s: %s" % (path, exc)) from None
    lines = content.count("\n") + (0 if content.endswith("\n") or not content else 1)
    return "%s %s (%d lines, %d bytes)" % (
        "updated" if existed else "created",
        rel(root, target),
        lines,
        len(content.encode("utf-8")),
    )


def tool_edit_file(root: Path, path: str, old_string: str, new_string: str, replace_all: bool = False) -> str:
    target = resolve(root, path)
    if not target.exists():
        raise ToolError("no such file: %s (use write_file to create it)" % path)
    if not old_string:
        raise ToolError("old_string must not be empty")
    try:
        text = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise ToolError("%s is not UTF-8 text" % path) from None
    count = text.count(old_string)
    if count == 0:
        raise ToolError("old_string not found in %s; read the file and copy the exact text" % path)
    if count > 1 and not replace_all:
        raise ToolError(
            "old_string appears %d times in %s; add surrounding context or pass replace_all" % (count, path)
        )
    updated = text.replace(old_string, new_string) if replace_all else text.replace(old_string, new_string, 1)
    if updated == text:
        return "no change needed in %s" % path
    try:
        target.write_text(updated, encoding="utf-8")
    except OSError as exc:
        raise ToolError("could not write %s: %s" % (path, exc)) from None
    return "edited %s (%d replacement%s)" % (rel(root, target), count if replace_all else 1, "s" if replace_all and count > 1 else "")


def tool_search_files(root: Path, pattern: str, path: str = ".", glob: str = "") -> str:
    try:
        regex = re.compile(pattern)
    except re.error as exc:
        raise ToolError("invalid regex: %s" % exc) from None
    base = resolve(root, path)
    if not base.exists():
        raise ToolError("no such folder: %s" % path)
    hits: List[str] = []
    scanned = 0
    for file_path in _iter_files(base):
        if glob and not fnmatch.fnmatch(file_path.name, glob):
            continue
        try:
            if file_path.stat().st_size > 512 * 1024:
                continue
            text = file_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        scanned += 1
        for number, line in enumerate(text.splitlines(), 1):
            if regex.search(line):
                hits.append("%s:%d: %s" % (rel(root, file_path), number, line.strip()[:200]))
                if len(hits) >= MAX_SEARCH_HITS:
                    return "\n".join(hits) + "\n\u2026 stopped after %d matches" % MAX_SEARCH_HITS
    if not hits:
        return "no matches for %r in %d files" % (pattern, scanned)
    return "\n".join(hits)


def tool_run_command(root: Path, command: str, timeout=120) -> str:
    command = (command or "").strip()
    if not command:
        raise ToolError("command must not be empty")
    for pattern in DANGEROUS:
        if pattern.search(command):
            raise ToolError("refused to run a destructive command: %s" % command)
    try:
        seconds = max(1, min(600, int(timeout or 120)))
    except (TypeError, ValueError):
        seconds = 120
    try:
        completed = subprocess.run(
            command,
            shell=True,
            cwd=str(root),
            capture_output=True,
            text=True,
            timeout=seconds,
            errors="replace",
        )
    except subprocess.TimeoutExpired:
        return "command timed out after %ds: %s" % (seconds, command)
    except OSError as exc:
        raise ToolError("could not run command: %s" % exc) from None
    parts = ["exit code: %d" % completed.returncode]
    if completed.stdout.strip():
        parts.append("stdout:\n" + completed.stdout.rstrip())
    if completed.stderr.strip():
        parts.append("stderr:\n" + completed.stderr.rstrip())
    if len(parts) == 1:
        parts.append("(no output)")
    return _truncate("\n".join(parts))


def dispatch(name: str, arguments: dict, root: Path) -> str:
    """Run one tool call, converting errors into text the model can read."""
    args = arguments or {}
    handlers = {
        "list_files": tool_list_files,
        "read_file": tool_read_file,
        "write_file": tool_write_file,
        "edit_file": tool_edit_file,
        "search_files": tool_search_files,
        "run_command": tool_run_command,
    }
    handler = handlers.get(name)
    if handler is None:
        return "error: unknown tool %r. Available: %s" % (name, ", ".join(sorted(handlers)))
    try:
        return handler(root, **args)
    except ToolError as exc:
        return "error: %s" % exc
    except TypeError as exc:
        return "error: bad arguments for %s: %s" % (name, exc)
    except Exception as exc:  # keep the agent alive on unexpected failures
        return "error: %s failed: %s" % (name, exc)

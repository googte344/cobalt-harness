"""The agent loop: ask the model, run tools, repeat until it stops."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator, List, Tuple

from .config import DEFAULT_EFFORT, EFFORT_GUIDANCE, EFFORT_STEPS, normalize_effort
from .providers.base import Provider, ProviderError, ToolCall, explain_error
from .tools import TOOLS, dispatch

MAX_STEPS = 40
TOOL_OUTPUT_LIMIT = 12_000

SYSTEM_PROMPT = """You are Cobalt, a coding agent running in the user's terminal.

You work inside the project folder: {root}

You have tools for listing and reading files, writing files, editing files, searching with regex, and running shell commands. Use them instead of guessing. Never claim you changed a file unless a tool call reported success.

How to work:
- Inspect the project before writing: list_files, then read the files you will touch.
- Write real, complete, runnable code. No placeholders, no "TODO: implement".
- Create files with write_file and change them with edit_file. Paths are relative to the project root.
- Run the project's own checks (tests, build, lint, formatter) when they exist. Report failures and fix them.
- Prefer small steps over one giant edit when the task is big.
- Match the existing conventions of the project: language, formatting, file layout.
- If the request is genuinely ambiguous in a way that changes what you build, ask one short question and stop instead of guessing.
- Keep prose short. Say what you changed and how you verified it.
- Call tools by name. Never print a tool call as JSON in your reply: it only runs when you actually call it.

Effort: {effort}. {guidance}

Platform: {platform}. Shell commands run in {shell}.{extra}"""


class Agent:
    """Owns the conversation, the tool loop and the token budget."""

    def __init__(
        self,
        provider: Provider,
        model: str,
        root: Path,
        max_steps: int = None,
        effort: str = DEFAULT_EFFORT,
    ) -> None:
        self.provider = provider
        self.model = model
        self.root = Path(root).resolve()
        self.effort = normalize_effort(effort) or DEFAULT_EFFORT
        # An explicit budget wins; otherwise /effort decides how many steps to allow.
        self._fixed_steps = max_steps
        self.max_steps = max_steps if max_steps is not None else EFFORT_STEPS[self.effort]
        self.messages: List[dict] = []
        self.usage = {"input": 0, "output": 0, "turns": 0}

    # -- session ----------------------------------------------------------
    def reset(self) -> None:
        self.messages = []
        self.usage = {"input": 0, "output": 0, "turns": 0}

    def set_effort(self, value: str) -> bool:
        """Change how hard the agent tries. Returns False for unknown levels."""
        level = normalize_effort(value)
        if level is None:
            return False
        self.effort = level
        if self._fixed_steps is None:
            self.max_steps = EFFORT_STEPS[level]
        return True

    def system_prompt(self) -> str:
        import platform

        is_windows = platform.system() == "Windows"
        return SYSTEM_PROMPT.format(
            root=self.root,
            effort=self.effort,
            guidance=EFFORT_GUIDANCE[self.effort],
            platform=platform.system() + " " + platform.release(),
            shell="cmd.exe" if is_windows else "the POSIX shell",
            extra=" Use Windows paths (backslashes are fine)." if is_windows else "",
        )

    # -- one user turn ----------------------------------------------------
    def run_turn(self, text: str) -> Iterator[Tuple]:
        """Yield ("text"|"tool_call"|"tool_result"|"error"|"notice", ...) events."""
        text = text.strip()
        if not text:
            return
        self.messages.append({"role": "user", "text": text})

        for step in range(self.max_steps):
            try:
                turn = self.provider.chat(self.model, self.system_prompt(), self.messages, TOOLS)
            except ProviderError as exc:
                yield ("error", "request to %s failed: %s" % (self.model, explain_error(str(exc))))
                return

            self._record_usage(turn.usage)
            if turn.text:
                yield ("text", turn.text)
            self.messages.append(
                {
                    "role": "assistant",
                    "text": turn.text,
                    "tool_calls": list(turn.tool_calls),
                    "raw_parts": list(turn.raw_parts),
                }
            )

            if not turn.tool_calls:
                return

            for call in turn.tool_calls:
                yield ("tool_call", call.name, call.arguments)
                output = dispatch(call.name, call.arguments, self.root)
                output = _cap(output)
                yield ("tool_result", call.name, output)
                self.messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "name": call.name,
                        "text": output,
                    }
                )

            if step == self.max_steps - 1:
                yield ("notice", "stopped after %d steps; tell me to continue" % self.max_steps)
                return

    def _record_usage(self, usage: dict) -> None:
        try:
            self.usage["input"] += int((usage or {}).get("input", 0) or 0)
            self.usage["output"] += int((usage or {}).get("output", 0) or 0)
            self.usage["turns"] += 1
        except (TypeError, ValueError):
            pass


def _cap(text: str, limit: int = TOOL_OUTPUT_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\u2026 output truncated at %d characters" % limit


def format_call(name: str, arguments: dict) -> str:
    """One-line rendering of a tool call for the transcript."""
    try:
        args = json.dumps(arguments or {}, ensure_ascii=False)
    except (TypeError, ValueError):
        args = str(arguments)
    if len(args) > 120:
        args = args[:117] + "\u2026"
    return "%s %s" % (name, args)

"""The agent loop: ask the model, run tools, repeat until it stops."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Callable, Iterator, List, Optional, Tuple

from .config import DEFAULT_EFFORT, EFFORT_GUIDANCE, EFFORT_STEPS, normalize_effort, parse_context_window
from .providers.base import Provider, ProviderError, ToolCall, explain_error
from .tools import TOOLS, dispatch

MAX_STEPS = 40
TOOL_OUTPUT_LIMIT = 12_000

# Tools that change files on disk. /yolo confirms these when it is turned off.
FILE_TOOLS = ("write_file", "edit_file")

SYSTEM_PROMPT = """You are Cobalt, a senior software engineer working as a coding agent in the user's terminal.

Workspace: {root}
Every path you pass to a tool is relative to that folder, and everything you write lands on the user's real machine.

# Ground rules
- The project is the source of truth. Read before you write: list_files to orient, search_files to locate code, read_file before editing. Never guess an API, a signature or existing behaviour when you can check it.
- Make the smallest change that solves the problem, in the project's own style: its language, formatting, naming, file layout, dependencies and error handling.
- Write complete, runnable code. No placeholders, no "TODO", no invented imports, no half-finished functions. If a new file is long, write all of it in one call.
- Use edit_file for changes to existing files, with an exact snippet copied from the file you just read. Use write_file for new files or full rewrites.
- Never claim something you have not observed. A file exists only when write_file reports success; a check passes only when run_command shows a zero exit status.
- Make commands non-interactive so they cannot hang waiting for input, and prefer the project's own test, build and lint commands.

# How to work
1. Understand the request, then inspect only the files the change needs.
2. For anything spanning several files, state the plan in a sentence or two before editing.
3. Make the edit, then run the narrowest check that exercises it: a focused test, a typecheck, a build, or the program itself.
4. If a check fails, read the actual error, fix the cause and re-run. Never weaken a test, swallow an error or add a suppression just to make it pass.
5. Finish with a short report: what changed, how you verified it, and what remains unverified.

# Communication
- Ask one short question only when a decision genuinely changes what you build; otherwise pick the obvious option and state the assumption.
- Keep prose tight and concrete. No filler, no restating the request, no long explanations unless asked for.
- Call tools through the tool interface. A tool call printed as JSON or fenced text does nothing.
- Respect the user's work: do not delete or rewrite unrelated code, do not commit or push unless asked, and keep secrets out of files.

Effort: {effort}. {guidance}

Platform: {platform}. Shell commands run in {shell}.{extra}"""


# Rough token accounting for context trimming: about four characters per token.
# The provider still reports the real count, which the UI shows after a request.
CONTEXT_RESERVE_MAX = 2048
CONTEXT_RESERVE_RATIO = 10


def estimate_tokens(value) -> int:
    if isinstance(value, str):
        return (len(value) + 3) // 4
    if isinstance(value, (dict, list, tuple)):
        try:
            return (len(json.dumps(value, ensure_ascii=False, default=str)) + 3) // 4
        except (TypeError, ValueError):
            return 0
    return 0


def _message_tokens(message: dict) -> int:
    total = 4 + estimate_tokens(message.get("text") or "")
    for call in message.get("tool_calls") or []:
        if isinstance(call, dict):
            name = call.get("name", "")
            arguments = call.get("arguments") or {}
        else:
            name = getattr(call, "name", "")
            arguments = getattr(call, "arguments", {}) or {}
        total += 8 + estimate_tokens(name) + estimate_tokens(arguments)
    return total


def _turn_groups(messages: List[dict]) -> List[List[dict]]:
    """Split history into whole user turns so tool calls stay with their results."""
    groups: List[List[dict]] = []
    for message in messages:
        if message.get("role") == "user" or not groups:
            groups.append([message])
        else:
            groups[-1].append(message)
    return groups


class Agent:
    """Owns the conversation, the tool loop and the token budget."""

    def __init__(
        self,
        provider: Provider,
        model: str,
        root: Path,
        max_steps: int = None,
        effort: str = DEFAULT_EFFORT,
        yolo: bool = True,
        approve: Optional[Callable[[str, dict], bool]] = None,
        context_window: Optional[int] = None,
    ) -> None:
        self.provider = provider
        self.model = model
        self.root = Path(root).resolve()
        self.effort = normalize_effort(effort) or DEFAULT_EFFORT
        # An explicit budget wins; otherwise /effort decides how many steps to allow.
        self._fixed_steps = max_steps
        self.max_steps = max_steps if max_steps is not None else EFFORT_STEPS[self.effort]
        self.messages: List[dict] = []
        self.usage = {"input": 0, "output": 0, "turns": 0}
        # With yolo on, file changes happen immediately; with it off, approve decides.
        self.yolo = bool(yolo)
        self.approve = approve
        self._cancel = threading.Event()
        self.context_window: Optional[int] = None
        self.context_used = 0
        self.set_context_window(context_window)

    # -- session ----------------------------------------------------------
    def reset(self) -> None:
        self.messages = []
        self.usage = {"input": 0, "output": 0, "turns": 0}
        self.context_used = 0

    def set_yolo(self, enabled: bool) -> None:
        """Ask before file changes when yolo is off."""
        self.yolo = bool(enabled)

    def set_context_window(self, value) -> bool:
        """Set the conversation budget in tokens; None/off sends everything."""
        try:
            self.context_window = parse_context_window(value)
        except ValueError:
            return False
        return True

    @property
    def context_budget(self) -> Optional[int]:
        """Input budget after leaving room for the model's reply."""
        if not self.context_window:
            return None
        reserve = min(CONTEXT_RESERVE_MAX, max(64, self.context_window // CONTEXT_RESERVE_RATIO))
        return max(1, self.context_window - reserve)

    def _context_messages(self, system: str) -> List[dict]:
        """The newest whole turns that fit the configured context window."""
        budget = self.context_budget
        if budget is None:
            return self.messages
        remaining = budget - estimate_tokens(system) - estimate_tokens(TOOLS)
        groups = _turn_groups(self.messages)
        chosen: List[List[dict]] = []
        for group in reversed(groups):
            size = sum(_message_tokens(message) for message in group)
            if chosen and size > remaining:
                break
            chosen.insert(0, group)
            remaining -= size
        return [message for group in chosen for message in group]

    def cancel(self) -> None:
        """Ask the running turn to stop at the next safe point."""
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    def _approved(self, name: str, arguments: dict) -> bool:
        """True when this tool call may run without asking the user."""
        if self.yolo or name not in FILE_TOOLS or self.approve is None:
            return True
        try:
            return bool(self.approve(name, arguments))
        except Exception:  # a broken prompt must never write without consent
            return False

    def set_effort(self, value: str) -> bool:
        """Change how hard the agent tries. Returns False for unknown levels."""
        level = normalize_effort(value)
        if level is None:
            return False
        self.effort = level
        if self._fixed_steps is None:
            self.max_steps = EFFORT_STEPS[level]
        return True

    def system_prompt(self) -> str:
        import platform

        is_windows = platform.system() == "Windows"
        return SYSTEM_PROMPT.format(
            root=self.root,
            effort=self.effort,
            guidance=EFFORT_GUIDANCE[self.effort],
            platform=platform.system() + " " + platform.release(),
            shell="cmd.exe" if is_windows else "the POSIX shell",
            extra=" Use Windows paths (backslashes are fine)." if is_windows else "",
        )

    # -- one user turn ----------------------------------------------------
    def run_turn(self, text: str) -> Iterator[Tuple]:
        """Yield ("text"|"tool_call"|"tool_result"|"error"|"notice", ...) events."""
        text = text.strip()
        if not text:
            return
        self._cancel.clear()
        self.messages.append({"role": "user", "text": text})

        for step in range(self.max_steps):
            if self.cancelled:
                yield ("notice", "cancelled")
                return
            system = self.system_prompt()
            context = self._context_messages(system)
            if step == 0 and self.context_window and len(context) < len(self.messages):
                yield (
                    "notice",
                    "context window {:,}: sending the newest {} of {} messages".format(
                        self.context_window, len(context), len(self.messages)
                    ),
                )
            try:
                turn = self.provider.chat(self.model, system, context, TOOLS)
            except ProviderError as exc:
                yield ("error", "request to %s failed: %s" % (self.model, explain_error(str(exc))))
                return
            if self.cancelled:
                yield ("notice", "cancelled")
                return

            self._record_usage(turn.usage)
            if turn.text:
                yield ("text", turn.text)
            self.messages.append(
                {
                    "role": "assistant",
                    "text": turn.text,
                    "tool_calls": list(turn.tool_calls),
                    "raw_parts": list(turn.raw_parts),
                }
            )

            if not turn.tool_calls:
                return

            for call in turn.tool_calls:
                if self.cancelled:
                    yield ("notice", "cancelled")
                    return
                yield ("tool_call", call.name, call.arguments)
                if self._approved(call.name, call.arguments):
                    output = _cap(dispatch(call.name, call.arguments, self.root))
                else:
                    output = (
                        "error: the user declined this file change, so nothing was written. "
                        "Do not retry it; ask what they want changed instead."
                    )
                    yield ("notice", "skipped %s: you declined the change" % (call.arguments.get("path") or call.name))
                yield ("tool_result", call.name, output)
                self.messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "name": call.name,
                        "text": output,
                    }
                )

            if step == self.max_steps - 1:
                yield ("notice", "stopped after %d steps; tell me to continue" % self.max_steps)
                return

    def _record_usage(self, usage: dict) -> None:
        try:
            self.usage["input"] += int((usage or {}).get("input", 0) or 0)
            self.usage["output"] += int((usage or {}).get("output", 0) or 0)
            self.usage["turns"] += 1
            sent = int((usage or {}).get("input", 0) or 0)
            if sent:
                self.context_used = sent
        except (TypeError, ValueError):
            pass


def _cap(text: str, limit: int = TOOL_OUTPUT_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\u2026 output truncated at %d characters" % limit


def format_call(name: str, arguments: dict) -> str:
    """One-line rendering of a tool call for the transcript."""
    try:
        args = json.dumps(arguments or {}, ensure_ascii=False)
    except (TypeError, ValueError):
        args = str(arguments)
    if len(args) > 120:
        args = args[:117] + "\u2026"
    return "%s %s" % (name, args)

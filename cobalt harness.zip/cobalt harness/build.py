"""Build a distributable Cobalt bundle with light obfuscation.

What it does, in order:
  1. parses each module and drops docstrings, then unparses it (comments vanish)
  2. compiles to bytecode only - no .py sources go into the archive
  3. stages a tiny launcher and zips everything into a runnable .pyz

Usage:
    python build.py                 # -> dist/cobalt.pyz
    python build.py --out x.pyz     # custom location

Run it with:  python dist/cobalt.pyz

Honest limitation: Python bytecode can be decompiled. This stops casual copying
of the source (and strips every comment and docstring), not a determined
reader. The readable source stays in git either way.
"""

from __future__ import annotations

import argparse
import ast
import py_compile
import tempfile
import zipapp
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE = "cobalt"
LAUNCHER = "import sys\n\nfrom cobalt.cli import main\n\nsys.exit(main())\n"
DOCSTRING_HOLDERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def strip_source(text: str, filename: str = "<module>") -> str:
    """Remove docstrings and comments by round-tripping through the AST."""
    tree = ast.parse(text, filename=filename)
    for node in ast.walk(tree):
        if not isinstance(node, DOCSTRING_HOLDERS) or not node.body:
            continue
        first = node.body[0]
        is_docstring = (
            isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)
        )
        if not is_docstring:
            continue
        node.body = node.body[1:]
        if not node.body:
            node.body = [ast.Pass()]
    return ast.unparse(tree)


def compile_module(source: Path, target: Path, display: str) -> None:
    """Compile one module to a sourceless .pyc at ``target``."""
    stripped = strip_source(source.read_text(encoding="utf-8"), filename=display)
    with tempfile.TemporaryDirectory() as tmp:
        staged = Path(tmp) / "module.py"
        staged.write_text(stripped, encoding="utf-8")
        target.parent.mkdir(parents=True, exist_ok=True)
        py_compile.compile(
            str(staged),
            cfile=str(target),
            dfile=display,
            doraise=True,
            invalidation_mode=py_compile.PycInvalidationMode.UNCHECKED_HASH,
        )


def sources() -> list:
    return sorted(path for path in (ROOT / PACKAGE).rglob("*.py") if "__pycache__" not in path.parts)


def build(out: Path) -> tuple:
    files = sources()
    if not files:
        raise SystemExit("no sources found under %s" % (ROOT / PACKAGE))
    original = sum(path.stat().st_size for path in files)
    with tempfile.TemporaryDirectory() as tmp:
        stage = Path(tmp) / "app"
        stage.mkdir()
        for source in files:
            relative = source.relative_to(ROOT)
            compile_module(source, stage / relative.with_suffix(".pyc"), relative.as_posix())
        (stage / "__main__.py").write_text(LAUNCHER, encoding="utf-8")
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            out.unlink()
        zipapp.create_archive(stage, target=out, interpreter="/usr/bin/env python3", compressed=True)
    return len(files), original, out.stat().st_size


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Build an obfuscated Cobalt bundle (.pyz).")
    parser.add_argument("--out", default="dist/cobalt.pyz", help="output archive (default: dist/cobalt.pyz)")
    args = parser.parse_args(argv)

    out = Path(args.out)
    if not out.is_absolute():
        out = ROOT / out
    count, original, size = build(out)
    print("compiled %d modules" % count)
    print("source %d bytes -> bundle %d bytes" % (original, size))
    print("wrote %s" % out)
    print("run it with: python %s" % out)
    print("note: bytecode is decompilable; this deters casual copying only.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
